export type UserRole = 'buyer' | 'seller' | 'admin';

export type CurrencyCode = 'BDT' | 'USD' | 'EUR' | 'GBP';

export type LanguageCode = 'bn' | 'en';

export interface User {
  id: string;
  name: string;
  username: string;
  email: string;
  role: UserRole;
  avatar: string;
  bio?: string;
  skills?: string[];
  isVerified: boolean;
  phone?: string;
  preferredLanguage: LanguageCode;
  preferredCurrency: CurrencyCode;
  createdAt: string;
  rating?: number;
  completedOrdersCount?: number;
  balance?: number; // Available seller earnings
  pendingBalance?: number; // Escrow balance
}

export interface Category {
  id: string;
  nameEn: string;
  nameBn: string;
  slug: string;
  iconName: string;
  descriptionEn: string;
  descriptionBn: string;
  subcategories: { id: string; nameEn: string; nameBn: string; slug: string }[];
}

export interface GigExtra {
  id: string;
  title: string;
  price: number;
  deliveryDays: number;
}

export interface GigFaq {
  question: string;
  answer: string;
}

export interface Gig {
  id: string;
  sellerId: string;
  sellerName: string;
  sellerAvatar: string;
  sellerRating: number;
  sellerCompletedOrders: number;
  title: string;
  titleBn?: string;
  slug: string;
  categoryId: string;
  subcategoryId?: string;
  description: string;
  descriptionBn?: string;
  searchTags: string[];
  price: number; // in BDT base
  deliveryDays: number;
  revisionLimit: number; // e.g. -1 for unlimited, or 2, 3
  includedWork: string[];
  extras: GigExtra[];
  faqs: GigFaq[];
  mainImage: string;
  galleryImages: string[];
  status: 'published' | 'paused' | 'pending_approval' | 'draft' | 'archived';
  isFeatured?: boolean;
  metaTitle?: string;
  metaDescription?: string;
  canonicalUrl?: string;
  imageAlt?: string;
  rating: number;
  reviewsCount: number;
  salesCount: number;
  createdAt: string;
  updatedAt: string;
}

export type OrderStatus =
  | 'awaiting_payment'
  | 'payment_submitted'
  | 'payment_under_review'
  | 'payment_confirmed'
  | 'in_progress'
  | 'work_submitted'
  | 'revision_requested'
  | 'completed'
  | 'cancelled'
  | 'disputed'
  | 'refunded';

export type PaymentMethod = 'bkash' | 'nagad' | 'rocket' | 'balance';

export type PaymentStatus = 'pending_verification' | 'verified' | 'rejected' | 'refunded';

export interface PaymentSubmission {
  id: string;
  orderId: string;
  buyerId: string;
  buyerName: string;
  method: PaymentMethod;
  senderNumber: string;
  transactionId: string;
  amountBDT: number;
  currencyCharged: CurrencyCode;
  amountCharged: number;
  screenshotUrl?: string;
  paymentDate: string;
  status: PaymentStatus;
  adminNotes?: string;
  verifiedAt?: string;
  verifiedBy?: string;
  rejectionReason?: string;
  createdAt: string;
}

export interface OrderDelivery {
  id: string;
  orderId: string;
  sellerId: string;
  notes: string;
  workFiles: { name: string; url: string; size?: string }[];
  deliveredAt: string;
}

export interface OrderStatusHistory {
  status: OrderStatus;
  timestamp: string;
  note?: string;
  actor: 'buyer' | 'seller' | 'admin' | 'system';
}

export interface Order {
  id: string;
  orderNumber: string; // e.g. ORD-2026-8941
  gigId: string;
  gigTitle: string;
  gigImage: string;
  buyerId: string;
  buyerName: string;
  buyerAvatar: string;
  sellerId: string;
  sellerName: string;
  sellerAvatar: string;
  priceBDT: number;
  selectedExtras: GigExtra[];
  totalAmountBDT: number;
  platformFeeBDT: number;
  sellerNetBDT: number;
  status: OrderStatus;
  requirements: string;
  deliveryDays: number;
  dueDate: string;
  paymentSubmission?: PaymentSubmission;
  deliveries: OrderDelivery[];
  revisionRequests: { note: string; requestedAt: string }[];
  statusHistory: OrderStatusHistory[];
  isReviewed?: boolean;
  disputeId?: string;
  createdAt: string;
  updatedAt: string;
}

export interface Message {
  id: string;
  conversationId: string;
  senderId: string;
  senderName: string;
  senderAvatar: string;
  senderRole: UserRole;
  text: string;
  attachments?: { name: string; url: string; size?: string }[];
  orderId?: string;
  isRead: boolean;
  createdAt: string;
}

export interface Conversation {
  id: string;
  participants: { id: string; name: string; avatar: string; role: UserRole }[];
  lastMessage: string;
  lastMessageAt: string;
  orderId?: string;
  unreadCountForBuyer: number;
  unreadCountForSeller: number;
}

export interface Review {
  id: string;
  orderId: string;
  gigId: string;
  sellerId: string;
  buyerId: string;
  buyerName: string;
  buyerAvatar: string;
  rating: number; // 1 to 5
  comment: string;
  sellerResponse?: string;
  createdAt: string;
}

export interface Dispute {
  id: string;
  orderId: string;
  orderNumber: string;
  openedById: string;
  openedByName: string;
  openedByRole: 'buyer' | 'seller';
  againstId: string;
  againstName: string;
  reasonCategory: string;
  description: string;
  evidenceFiles: { name: string; url: string }[];
  requestedResolution: 'refund' | 'cancel' | 'release_payment' | 'revision';
  status: 'open' | 'under_review' | 'resolved' | 'closed';
  adminDecision?: {
    action: 'release_payment' | 'refund' | 'cancel' | 'revision';
    notes: string;
    decidedBy: string;
    decidedAt: string;
  };
  createdAt: string;
  updatedAt: string;
}

export interface Notification {
  id: string;
  userId: string;
  titleEn: string;
  titleBn: string;
  messageEn: string;
  messageBn: string;
  type: 'order' | 'payment' | 'message' | 'dispute' | 'system';
  link?: string;
  isRead: boolean;
  createdAt: string;
}

export interface LedgerEntry {
  id: string;
  orderId?: string;
  type: 'order_payment' | 'commission_deduction' | 'seller_release' | 'refund' | 'adjustment';
  amountBDT: number;
  platformFeeBDT: number;
  sellerAmountBDT: number;
  status: 'held_in_escrow' | 'released' | 'refunded';
  notes: string;
  createdAt: string;
}

export interface AdminAuditLog {
  id: string;
  adminId: string;
  adminUsername: string;
  action: string;
  targetType: 'user' | 'gig' | 'order' | 'payment' | 'dispute' | 'settings';
  targetId: string;
  details: string;
  ipAddress?: string;
  createdAt: string;
}

export interface PlatformSettings {
  websiteName: string;
  domain: string;
  contactEmail: string;
  adminAlertEmail: string;
  contactPhone: string;
  bkashNumber: string;
  nagadNumber: string;
  rocketNumber: string;
  commissionPercentage: number;
  minGigPriceBDT: number;
  maxGigPriceBDT: number;
  requireGigApproval: boolean;
  maintenanceMode: boolean;
  defaultLanguage: LanguageCode;
  defaultCurrency: CurrencyCode;
}
