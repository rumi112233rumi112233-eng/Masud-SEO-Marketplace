import React, { useState } from 'react';
import {
  AlertCircle,
  Check,
  Globe,
  Image as ImageIcon,
  Plus,
  Trash2,
  Upload,
  X,
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { useMarketplace } from '../../context/MarketplaceContext';
import { useLanguage } from '../../i18n/LanguageContext';
import { Gig, GigExtra, GigFaq } from '../../types';

interface CreateEditGigModalProps {
  gigToEdit?: Gig | null;
  isOpen: boolean;
  onClose: () => void;
  onSuccess: (gig: Gig) => void;
}

export const CreateEditGigModal: React.FC<CreateEditGigModalProps> = ({
  gigToEdit,
  isOpen,
  onClose,
  onSuccess,
}) => {
  const { language, t } = useLanguage();
  const { categories, settings, createGig, updateGig } = useMarketplace();
  const { currentUser } = useAuth();

  const [title, setTitle] = useState(gigToEdit?.title || 'I will ');
  const [titleBn, setTitleBn] = useState(gigToEdit?.titleBn || '');
  const [categoryId, setCategoryId] = useState(gigToEdit?.categoryId || categories[0]?.id || 'cat-backlinks');
  const [subcategoryId, setSubcategoryId] = useState(gigToEdit?.subcategoryId || '');
  const [description, setDescription] = useState(gigToEdit?.description || '');
  const [descriptionBn, setDescriptionBn] = useState(gigToEdit?.descriptionBn || '');
  const [price, setPrice] = useState<number>(gigToEdit?.price || 1000);
  const [deliveryDays, setDeliveryDays] = useState<number>(gigToEdit?.deliveryDays || 3);
  const [revisionLimit, setRevisionLimit] = useState<number>(gigToEdit?.revisionLimit ?? -1);
  const [searchTagsInput, setSearchTagsInput] = useState(gigToEdit?.searchTags.join(', ') || 'seo, backlinks');
  const [includedWorkInput, setIncludedWorkInput] = useState(gigToEdit?.includedWork.join('\n') || '50 High DA Backlinks\nDetailed Excel Report');

  // Images state
  const [mainImage, setMainImage] = useState<string>(
    gigToEdit?.mainImage || 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=800'
  );
  const [galleryImages, setGalleryImages] = useState<string[]>(gigToEdit?.galleryImages || []);

  // Extras state
  const [extras, setExtras] = useState<GigExtra[]>(
    gigToEdit?.extras || [
      { id: 'ext-demo-1', title: 'Express Fast 2-Day Delivery', price: 500, deliveryDays: 2 },
    ]
  );
  const [newExtraTitle, setNewExtraTitle] = useState('');
  const [newExtraPrice, setNewExtraPrice] = useState<number>(500);

  // FAQs state
  const [faqs, setFaqs] = useState<GigFaq[]>(
    gigToEdit?.faqs || [
      { question: 'What details do you need?', answer: 'Please send your target Website URL and keywords.' },
    ]
  );
  const [newFaqQ, setNewFaqQ] = useState('');
  const [newFaqA, setNewFaqA] = useState('');

  // SEO metadata
  const [metaTitle, setMetaTitle] = useState(gigToEdit?.metaTitle || '');
  const [metaDescription, setMetaDescription] = useState(gigToEdit?.metaDescription || '');
  const [imageAlt, setImageAlt] = useState(gigToEdit?.imageAlt || '');

  const [error, setError] = useState('');
  const [uploadFeedback, setUploadFeedback] = useState('');

  if (!isOpen) return null;

  // Handle local computer image upload
  const handleMainImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      // Validate MIME type
      const allowedTypes = ['image/jpeg', 'image/png', 'image/webp'];
      if (!allowedTypes.includes(file.type)) {
        setError('Only JPG, PNG, and WebP images are supported.');
        return;
      }
      // Validate Size (5MB limit)
      if (file.size > 5 * 1024 * 1024) {
        setError('Image file size must be less than 5MB.');
        return;
      }

      const reader = new FileReader();
      reader.onload = () => {
        setMainImage(reader.result as string);
        setUploadFeedback(`Uploaded: ${file.name} (${(file.size / 1024).toFixed(0)} KB)`);
        setError('');
      };
      reader.readAsDataURL(file);
    }
  };

  const handleAddExtra = () => {
    if (!newExtraTitle.trim()) return;
    setExtras([
      ...extras,
      {
        id: `ext-${Date.now()}`,
        title: newExtraTitle.trim(),
        price: Number(newExtraPrice) || 300,
        deliveryDays: 0,
      },
    ]);
    setNewExtraTitle('');
    setNewExtraPrice(500);
  };

  const handleRemoveExtra = (id: string) => {
    setExtras(extras.filter((e) => e.id !== id));
  };

  const handleAddFaq = () => {
    if (!newFaqQ.trim() || !newFaqA.trim()) return;
    setFaqs([...faqs, { question: newFaqQ.trim(), answer: newFaqA.trim() }]);
    setNewFaqQ('');
    setNewFaqA('');
  };

  const handleRemoveFaq = (index: number) => {
    setFaqs(faqs.filter((_, i) => i !== index));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!title.trim() || title.trim().length < 10) {
      setError('Title must be at least 10 characters long.');
      return;
    }

    if (!description.trim() || description.trim().length < 50) {
      setError('Please write a detailed service description (at least 50 characters).');
      return;
    }

    const tags = searchTagsInput
      .split(',')
      .map((t) => t.trim().toLowerCase())
      .filter(Boolean);

    const includedItems = includedWorkInput
      .split('\n')
      .map((i) => i.trim())
      .filter(Boolean);

    const payload: Partial<Gig> = {
      title: title.trim(),
      titleBn: titleBn.trim() || undefined,
      categoryId,
      subcategoryId: subcategoryId || undefined,
      description: description.trim(),
      descriptionBn: descriptionBn.trim() || undefined,
      price: Math.max(Number(price) || 500, settings.minGigPriceBDT),
      deliveryDays: Number(deliveryDays) || 3,
      revisionLimit: Number(revisionLimit) ?? -1,
      searchTags: tags,
      includedWork: includedItems,
      extras,
      faqs,
      mainImage,
      galleryImages,
      metaTitle: metaTitle.trim() || title.trim(),
      metaDescription: metaDescription.trim() || description.trim().slice(0, 150),
      imageAlt: imageAlt.trim() || title.trim(),
    };

    if (gigToEdit) {
      updateGig(gigToEdit.id, payload);
      onSuccess({ ...gigToEdit, ...payload } as Gig);
    } else {
      const created = createGig(payload);
      onSuccess(created);
    }

    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/75 backdrop-blur-sm overflow-y-auto animate-in fade-in">
      <div className="relative w-full max-w-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-2xl p-6 my-8 max-h-[90vh] overflow-y-auto">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-1 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800"
        >
          <X className="w-5 h-5" />
        </button>

        <h2 className="text-lg sm:text-xl font-bold text-slate-900 dark:text-white mb-1">
          {gigToEdit ? t('updateGig') : t('createGig')}
        </h2>
        <p className="text-xs text-slate-500 mb-6">
          {language === 'bn'
            ? 'আপনার এসইও সার্ভিসের বিস্তারিত তথ্য ও মূল্য নির্ধারণ করুন।'
            : 'Fill in your SEO gig details, pricing, extras, and upload an attractive cover photo.'}
        </p>

        {error && (
          <div className="mb-4 p-3 rounded-lg bg-rose-50 dark:bg-rose-950/50 border border-rose-200 dark:border-rose-800 text-rose-700 dark:text-rose-300 text-xs flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{error}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* 1. Title & Bangla Title */}
          <div className="space-y-3">
            <div>
              <label className="block text-xs font-bold text-slate-800 dark:text-slate-200 mb-1">
                {t('gigTitleLabel')} *
              </label>
              <input
                type="text"
                required
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder={t('gigTitlePlaceholder')}
                className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-xs text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-1 focus:ring-sky-500 font-medium"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-800 dark:text-slate-200 mb-1">
                বাংলা শিরোনাম (ঐচ্ছিক)
              </label>
              <input
                type="text"
                value={titleBn}
                onChange={(e) => setTitleBn(e.target.value)}
                placeholder="যেমন: আমি ৫০টি হাই ডিএ ডুফলো ব্যাকলিংক তৈরি করব..."
                className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-xs text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-1 focus:ring-sky-500"
              />
            </div>
          </div>

          {/* 2. Category & Subcategory */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-bold text-slate-800 dark:text-slate-200 mb-1">
                {t('gigCategoryLabel')} *
              </label>
              <select
                value={categoryId}
                onChange={(e) => {
                  setCategoryId(e.target.value);
                  setSubcategoryId('');
                }}
                className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-xs text-slate-800 dark:text-slate-100"
              >
                {categories.map((c) => (
                  <option key={c.id} value={c.id}>
                    {language === 'bn' ? c.nameBn : c.nameEn}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-800 dark:text-slate-200 mb-1">
                {t('gigSubcategoryLabel')}
              </label>
              <select
                value={subcategoryId}
                onChange={(e) => setSubcategoryId(e.target.value)}
                className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-xs text-slate-800 dark:text-slate-100"
              >
                <option value="">Select Subcategory</option>
                {categories
                  .find((c) => c.id === categoryId)
                  ?.subcategories.map((sub) => (
                    <option key={sub.id} value={sub.id}>
                      {language === 'bn' ? sub.nameBn : sub.nameEn}
                    </option>
                  ))}
              </select>
            </div>
          </div>

          {/* 3. Computer Image Upload */}
          <div className="p-4 bg-slate-50 dark:bg-slate-800/60 rounded-xl border border-slate-200 dark:border-slate-700/60 space-y-3">
            <div className="flex items-center justify-between">
              <div>
                <label className="block text-xs font-bold text-slate-800 dark:text-slate-200">
                  {t('mainImageUpload')} *
                </label>
                <p className="text-[11px] text-slate-400">{t('fileHelpText')}</p>
              </div>
              <label className="flex items-center gap-1.5 px-3 py-1.5 bg-sky-600 hover:bg-sky-700 text-white rounded-lg text-xs font-semibold cursor-pointer shadow-sm transition">
                <Upload className="w-3.5 h-3.5" />
                <span>{t('browseComputer')}</span>
                <input
                  type="file"
                  accept="image/jpeg, image/png, image/webp"
                  onChange={handleMainImageUpload}
                  className="hidden"
                />
              </label>
            </div>

            {uploadFeedback && (
              <div className="text-[11px] text-emerald-600 dark:text-emerald-400 font-medium flex items-center gap-1">
                <Check className="w-3.5 h-3.5" />
                <span>{uploadFeedback}</span>
              </div>
            )}

            {/* Preview */}
            <div className="flex items-center gap-4">
              <div className="w-40 aspect-[16/10] rounded-lg overflow-hidden border border-slate-300 dark:border-slate-700 bg-slate-200 dark:bg-slate-800">
                <img src={mainImage} alt="Preview" className="w-full h-full object-cover" />
              </div>
              <div className="text-xs text-slate-500">
                <span className="font-semibold block text-slate-700 dark:text-slate-300">
                  Cover Photo Preview
                </span>
                <span>Shows up on search results and homepage cards.</span>
              </div>
            </div>
          </div>

          {/* 4. Description */}
          <div>
            <label className="block text-xs font-bold text-slate-800 dark:text-slate-200 mb-1">
              {t('gigDescriptionLabel')} *
            </label>
            <textarea
              required
              rows={5}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Explain exactly what you will deliver, methodology, authority metrics, tools used, and safety guarantees..."
              className="w-full p-3 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-xs font-mono"
            />
          </div>

          {/* 5. Pricing & Delivery Days */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="block text-xs font-bold text-slate-800 dark:text-slate-200 mb-1">
                {t('gigPriceLabel')} *
              </label>
              <div className="relative">
                <span className="absolute left-3 top-2 text-xs font-bold text-slate-400">৳</span>
                <input
                  type="number"
                  min={settings.minGigPriceBDT}
                  max={settings.maxGigPriceBDT}
                  value={price}
                  onChange={(e) => setPrice(Number(e.target.value))}
                  className="w-full pl-7 pr-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-xs font-bold text-slate-900 dark:text-white"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-800 dark:text-slate-200 mb-1">
                {t('gigDeliveryDaysLabel')} *
              </label>
              <input
                type="number"
                min={1}
                max={30}
                value={deliveryDays}
                onChange={(e) => setDeliveryDays(Number(e.target.value))}
                className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-xs text-slate-800 dark:text-slate-100"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-800 dark:text-slate-200 mb-1">
                {t('gigRevisionLimitLabel')}
              </label>
              <input
                type="number"
                min={-1}
                max={20}
                value={revisionLimit}
                onChange={(e) => setRevisionLimit(Number(e.target.value))}
                className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-xs text-slate-800 dark:text-slate-100"
              />
            </div>
          </div>

          {/* 6. Included Work Checklist */}
          <div>
            <label className="block text-xs font-bold text-slate-800 dark:text-slate-200 mb-1">
              {t('includedItemsLabel')}
            </label>
            <textarea
              rows={3}
              value={includedWorkInput}
              onChange={(e) => setIncludedWorkInput(e.target.value)}
              placeholder={t('includedItemsPlaceholder')}
              className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-xs font-mono"
            />
          </div>

          {/* 7. Search Tags */}
          <div>
            <label className="block text-xs font-bold text-slate-800 dark:text-slate-200 mb-1">
              {t('searchTagsLabel')}
            </label>
            <input
              type="text"
              value={searchTagsInput}
              onChange={(e) => setSearchTagsInput(e.target.value)}
              placeholder={t('searchTagsPlaceholder')}
              className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-xs text-slate-800 dark:text-slate-100"
            />
          </div>

          {/* 8. Extras / Add-ons Section */}
          <div className="p-4 bg-slate-50 dark:bg-slate-800/60 rounded-xl border border-slate-200 dark:border-slate-700/60 space-y-3">
            <h4 className="text-xs font-bold text-slate-800 dark:text-slate-200 uppercase tracking-wider">
              {t('serviceAddons')} ({extras.length})
            </h4>

            {extras.map((ex) => (
              <div
                key={ex.id}
                className="flex items-center justify-between p-2 rounded-lg bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs"
              >
                <div>
                  <span className="font-semibold text-slate-800 dark:text-slate-200">{ex.title}</span>
                  <span className="text-[11px] text-sky-600 dark:text-sky-400 font-bold ml-2">+৳{ex.price}</span>
                </div>
                <button
                  type="button"
                  onClick={() => handleRemoveExtra(ex.id)}
                  className="text-rose-500 hover:text-rose-700 p-1"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            ))}

            <div className="flex items-center gap-2 pt-1">
              <input
                type="text"
                placeholder="Extra title (e.g. Add 2 High DA Guest Posts)"
                value={newExtraTitle}
                onChange={(e) => setNewExtraTitle(e.target.value)}
                className="flex-1 px-3 py-1.5 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-xs"
              />
              <input
                type="number"
                placeholder="Price"
                value={newExtraPrice}
                onChange={(e) => setNewExtraPrice(Number(e.target.value))}
                className="w-24 px-3 py-1.5 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-xs"
              />
              <button
                type="button"
                onClick={handleAddExtra}
                className="px-3 py-1.5 bg-sky-600 hover:bg-sky-700 text-white rounded-lg text-xs font-semibold"
              >
                + Add
              </button>
            </div>
          </div>

          {/* 9. SEO Metadata Optimization Section */}
          <div className="p-4 bg-sky-50/50 dark:bg-sky-950/20 rounded-xl border border-sky-200 dark:border-sky-900 space-y-3">
            <h4 className="text-xs font-bold text-sky-900 dark:text-sky-300 uppercase tracking-wider flex items-center gap-1.5">
              <Globe className="w-3.5 h-3.5" />
              <span>{t('seoMetaSection')}</span>
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-[11px] font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  {t('metaTitle')}
                </label>
                <input
                  type="text"
                  value={metaTitle}
                  onChange={(e) => setMetaTitle(e.target.value)}
                  placeholder="Optimized page title for search engines"
                  className="w-full px-3 py-1.5 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-xs"
                />
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  {t('imageAlt')}
                </label>
                <input
                  type="text"
                  value={imageAlt}
                  onChange={(e) => setImageAlt(e.target.value)}
                  placeholder="Descriptive image alternative text"
                  className="w-full px-3 py-1.5 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-xs"
                />
              </div>
            </div>
          </div>

          {/* Submit & Cancel Buttons */}
          <div className="flex items-center justify-between pt-4 border-t border-slate-100 dark:border-slate-800">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-semibold text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-6 py-2.5 bg-gradient-to-r from-sky-600 to-indigo-600 hover:from-sky-700 hover:to-indigo-700 text-white rounded-xl text-xs font-bold shadow-md transition"
            >
              {gigToEdit ? t('updateGig') : t('saveGig')}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
