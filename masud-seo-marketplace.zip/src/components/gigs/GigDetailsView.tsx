import React, { useState } from 'react';
import {
  ArrowLeft,
  Check,
  ChevronDown,
  ChevronUp,
  Clock,
  HelpCircle,
  MessageCircle,
  RotateCcw,
  ShieldCheck,
  Star,
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { useMarketplace } from '../../context/MarketplaceContext';
import { useLanguage } from '../../i18n/LanguageContext';
import { Gig, GigExtra } from '../../types';

interface GigDetailsViewProps {
  gig: Gig;
  onBack: () => void;
  onOrderNow: (gig: Gig, selectedExtras: GigExtra[]) => void;
  onContactSeller: (sellerId: string) => void;
}

export const GigDetailsView: React.FC<GigDetailsViewProps> = ({
  gig,
  onBack,
  onOrderNow,
  onContactSeller,
}) => {
  const { language, formatPrice, t } = useLanguage();
  const { reviews } = useMarketplace();
  const { currentUser } = useAuth();

  const [selectedExtras, setSelectedExtras] = useState<GigExtra[]>([]);
  const [openFaqIndex, setOpenFaqIndex] = useState<number | null>(0);
  const [activeImage, setActiveImage] = useState<string>(gig.mainImage);

  const gigReviews = reviews.filter((r) => r.gigId === gig.id);

  const toggleExtra = (extra: GigExtra) => {
    if (selectedExtras.some((e) => e.id === extra.id)) {
      setSelectedExtras(selectedExtras.filter((e) => e.id !== extra.id));
    } else {
      setSelectedExtras([...selectedExtras, extra]);
    }
  };

  const extrasSum = selectedExtras.reduce((sum, e) => sum + e.price, 0);
  const totalAmountBDT = gig.price + extrasSum;
  const totalDeliveryDays =
    gig.deliveryDays + selectedExtras.reduce((sum, e) => sum + e.deliveryDays, 0);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 animate-in fade-in">
      {/* Back button */}
      <button
        onClick={onBack}
        className="inline-flex items-center gap-1.5 text-xs font-semibold text-slate-600 dark:text-slate-400 hover:text-sky-600 dark:hover:text-sky-400 mb-6 transition"
      >
        <ArrowLeft className="w-4 h-4" />
        <span>{language === 'bn' ? 'সকল সার্ভিসে ফিরে যান' : 'Back to Browse'}</span>
      </button>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Left Column: Gig Media, Description, Included, FAQs, Reviews */}
        <div className="lg:col-span-2 space-y-8">
          {/* Header & Title */}
          <div>
            <div className="flex items-center gap-2 text-xs text-slate-500 mb-2">
              <span className="font-semibold text-sky-600 dark:text-sky-400 uppercase tracking-wider text-[11px]">
                {gig.categoryId.replace('cat-', '').toUpperCase()}
              </span>
              <span>·</span>
              <span>{gig.deliveryDays} Days Delivery</span>
              <span>·</span>
              <span>{gig.salesCount} Completed</span>
            </div>

            <h1 className="text-xl sm:text-2xl font-bold text-slate-900 dark:text-white leading-tight">
              {language === 'bn' && gig.titleBn ? gig.titleBn : gig.title}
            </h1>

            {/* Seller Info Bar */}
            <div className="flex items-center gap-3 mt-4 pt-3 border-t border-slate-100 dark:border-slate-800">
              <img
                src={gig.sellerAvatar}
                alt={gig.sellerName}
                className="w-10 h-10 rounded-full object-cover border border-slate-200 dark:border-slate-700"
              />
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-sm font-bold text-slate-900 dark:text-slate-100">
                    {gig.sellerName}
                  </span>
                  <span className="text-[10px] bg-emerald-100 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-400 font-bold px-1.5 py-0.5 rounded">
                    Level 2 Seller
                  </span>
                </div>
                <div className="flex items-center gap-2 text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                  <div className="flex items-center text-amber-500 font-semibold gap-1">
                    <Star className="w-3.5 h-3.5 fill-amber-400 stroke-amber-400" />
                    <span>{gig.rating.toFixed(1)}</span>
                  </div>
                  <span>({gig.reviewsCount} reviews)</span>
                  <span>·</span>
                  <span>{gig.sellerCompletedOrders} total orders</span>
                </div>
              </div>
            </div>
          </div>

          {/* Main Photo & Gallery */}
          <div className="space-y-3">
            <div className="aspect-[16/9] rounded-2xl overflow-hidden bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 shadow-sm">
              <img
                src={activeImage}
                alt={gig.imageAlt || gig.title}
                className="w-full h-full object-cover"
              />
            </div>

            {gig.galleryImages && gig.galleryImages.length > 0 && (
              <div className="flex items-center gap-2 overflow-x-auto pb-1">
                <button
                  onClick={() => setActiveImage(gig.mainImage)}
                  className={`w-20 h-14 rounded-lg overflow-hidden border-2 transition ${
                    activeImage === gig.mainImage
                      ? 'border-sky-600 scale-105'
                      : 'border-transparent opacity-70 hover:opacity-100'
                  }`}
                >
                  <img src={gig.mainImage} alt="" className="w-full h-full object-cover" />
                </button>
                {gig.galleryImages.map((img, idx) => (
                  <button
                    key={idx}
                    onClick={() => setActiveImage(img)}
                    className={`w-20 h-14 rounded-lg overflow-hidden border-2 transition ${
                      activeImage === img
                        ? 'border-sky-600 scale-105'
                        : 'border-transparent opacity-70 hover:opacity-100'
                    }`}
                  >
                    <img src={img} alt="" className="w-full h-full object-cover" />
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Description Section */}
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-sm">
            <h2 className="text-base font-bold text-slate-900 dark:text-white mb-4">
              {t('aboutGig')}
            </h2>
            <div className="text-sm text-slate-700 dark:text-slate-300 leading-relaxed whitespace-pre-line space-y-4 font-normal">
              {language === 'bn' && gig.descriptionBn ? gig.descriptionBn : gig.description}
            </div>

            {/* Search Tags */}
            {gig.searchTags && gig.searchTags.length > 0 && (
              <div className="mt-6 pt-4 border-t border-slate-100 dark:border-slate-800 flex flex-wrap gap-2 items-center">
                <span className="text-xs text-slate-400 font-medium">Tags:</span>
                {gig.searchTags.map((tag, i) => (
                  <span
                    key={i}
                    className="text-xs text-slate-600 dark:text-slate-400 bg-slate-100 dark:bg-slate-800 px-2 py-0.5 rounded font-mono"
                  >
                    #{tag}
                  </span>
                ))}
              </div>
            )}
          </div>

          {/* Included Features Checklist */}
          {gig.includedWork && gig.includedWork.length > 0 && (
            <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-sm">
              <h2 className="text-base font-bold text-slate-900 dark:text-white mb-4">
                {t('whatIsIncluded')}
              </h2>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {gig.includedWork.map((item, idx) => (
                  <div key={idx} className="flex items-start gap-2.5 text-xs text-slate-700 dark:text-slate-300">
                    <div className="w-4 h-4 rounded-full bg-emerald-100 dark:bg-emerald-950 text-emerald-600 dark:text-emerald-400 flex items-center justify-center shrink-0 mt-0.5">
                      <Check className="w-3 h-3 stroke-[3]" />
                    </div>
                    <span>{item}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* FAQs Accordion */}
          {gig.faqs && gig.faqs.length > 0 && (
            <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-sm">
              <h2 className="text-base font-bold text-slate-900 dark:text-white mb-4 flex items-center gap-2">
                <HelpCircle className="w-4 h-4 text-sky-500" />
                <span>{t('frequentlyAskedQuestions')}</span>
              </h2>
              <div className="divide-y divide-slate-100 dark:divide-slate-800">
                {gig.faqs.map((faq, idx) => (
                  <div key={idx} className="py-3">
                    <button
                      onClick={() => setOpenFaqIndex(openFaqIndex === idx ? null : idx)}
                      className="w-full text-left flex items-center justify-between text-xs sm:text-sm font-semibold text-slate-800 dark:text-slate-200 hover:text-sky-600"
                    >
                      <span>{faq.question}</span>
                      {openFaqIndex === idx ? (
                        <ChevronUp className="w-4 h-4 text-slate-400 shrink-0" />
                      ) : (
                        <ChevronDown className="w-4 h-4 text-slate-400 shrink-0" />
                      )}
                    </button>
                    {openFaqIndex === idx && (
                      <p className="mt-2 text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
                        {faq.answer}
                      </p>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Verified Customer Reviews */}
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-sm">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-base font-bold text-slate-900 dark:text-white">
                {language === 'bn' ? 'বায়ারদের ভেরিফাইড রিভিউ' : 'Verified Buyer Reviews'} ({gigReviews.length})
              </h2>
              <div className="flex items-center gap-1.5 text-xs font-bold text-amber-500">
                <Star className="w-4 h-4 fill-amber-400 stroke-amber-400" />
                <span>{gig.rating.toFixed(1)} / 5.0</span>
              </div>
            </div>

            {gigReviews.length > 0 ? (
              <div className="divide-y divide-slate-100 dark:divide-slate-800">
                {gigReviews.map((rev) => (
                  <div key={rev.id} className="py-4 space-y-2">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2.5">
                        <img
                          src={rev.buyerAvatar}
                          alt={rev.buyerName}
                          className="w-8 h-8 rounded-full object-cover"
                        />
                        <div>
                          <div className="text-xs font-bold text-slate-900 dark:text-slate-100">
                            {rev.buyerName}
                          </div>
                          <div className="text-[10px] text-slate-400">
                            {new Date(rev.createdAt).toLocaleDateString()}
                          </div>
                        </div>
                      </div>
                      <div className="flex items-center gap-0.5">
                        {Array.from({ length: 5 }).map((_, i) => (
                          <Star
                            key={i}
                            className={`w-3 h-3 ${
                              i < rev.rating
                                ? 'fill-amber-400 stroke-amber-400'
                                : 'text-slate-300 dark:text-slate-700'
                            }`}
                          />
                        ))}
                      </div>
                    </div>
                    <p className="text-xs text-slate-700 dark:text-slate-300 leading-relaxed">
                      "{rev.comment}"
                    </p>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-xs text-slate-400 py-4 text-center">
                {language === 'bn'
                  ? 'এই গিগে এখনও কোনো রিভিউ জমা পড়েনি। অর্ডার সম্পন্নকারী বায়াররাই কেবল রিভিউ দিতে পারেন।'
                  : 'No reviews yet for this specific gig. Only buyers with completed orders can submit verified feedback.'}
              </p>
            )}
          </div>
        </div>

        {/* Right Sidebar: Order Checkout & Pricing Card */}
        <div className="space-y-6">
          <div className="sticky top-24 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-xl space-y-5">
            {/* Header / Price */}
            <div>
              <div className="flex items-baseline justify-between">
                <span className="text-xs text-slate-500 font-medium uppercase tracking-wider">
                  {t('serviceBasePrice')}
                </span>
                <span className="text-2xl font-black text-slate-900 dark:text-white">
                  {formatPrice(gig.price)}
                </span>
              </div>
              <div className="flex items-center gap-4 text-xs text-slate-500 mt-2">
                <div className="flex items-center gap-1">
                  <Clock className="w-3.5 h-3.5 text-sky-500" />
                  <span>{totalDeliveryDays} Days Delivery</span>
                </div>
                <div className="flex items-center gap-1">
                  <RotateCcw className="w-3.5 h-3.5 text-emerald-500" />
                  <span>{gig.revisionLimit === -1 ? 'Unlimited' : gig.revisionLimit} Revisions</span>
                </div>
              </div>
            </div>

            {/* Extras / Add-ons Checklist */}
            {gig.extras && gig.extras.length > 0 && (
              <div className="pt-4 border-t border-slate-100 dark:border-slate-800 space-y-2.5">
                <h4 className="text-xs font-bold text-slate-900 dark:text-slate-200 uppercase tracking-wider">
                  {t('serviceAddons')}
                </h4>
                {gig.extras.map((extra) => {
                  const isChecked = selectedExtras.some((e) => e.id === extra.id);
                  return (
                    <label
                      key={extra.id}
                      className={`flex items-start gap-2.5 p-2.5 rounded-xl border text-xs cursor-pointer transition ${
                        isChecked
                          ? 'border-sky-500 bg-sky-50/50 dark:bg-sky-950/20'
                          : 'border-slate-200 dark:border-slate-800 hover:border-slate-300'
                      }`}
                    >
                      <input
                        type="checkbox"
                        checked={isChecked}
                        onChange={() => toggleExtra(extra)}
                        className="mt-0.5 rounded text-sky-600 focus:ring-sky-500"
                      />
                      <div className="flex-1">
                        <div className="font-semibold text-slate-900 dark:text-slate-100">
                          {extra.title}
                        </div>
                        {extra.deliveryDays > 0 && (
                          <div className="text-[10px] text-slate-400">
                            +{extra.deliveryDays} extra day(s)
                          </div>
                        )}
                      </div>
                      <span className="font-bold text-sky-600 dark:text-sky-400 whitespace-nowrap">
                        +{formatPrice(extra.price)}
                      </span>
                    </label>
                  );
                })}
              </div>
            )}

            {/* Total calculation */}
            <div className="pt-4 border-t border-slate-100 dark:border-slate-800 space-y-2">
              <div className="flex items-center justify-between text-xs text-slate-500">
                <span>{t('serviceBasePrice')}</span>
                <span>{formatPrice(gig.price)}</span>
              </div>
              {extrasSum > 0 && (
                <div className="flex items-center justify-between text-xs text-slate-500">
                  <span>{t('extrasTotal')}</span>
                  <span>+{formatPrice(extrasSum)}</span>
                </div>
              )}
              <div className="flex items-center justify-between text-sm font-bold text-slate-900 dark:text-white pt-2 border-t border-slate-100 dark:border-slate-800">
                <span>{t('totalPayable')}</span>
                <span className="text-xl font-extrabold text-sky-600 dark:text-sky-400">
                  {formatPrice(totalAmountBDT)}
                </span>
              </div>
              <div className="text-[10px] text-slate-400 text-right">
                (Base BDT ৳{totalAmountBDT.toLocaleString('en-IN')})
              </div>
            </div>

            {/* Order Action Button */}
            <button
              onClick={() => onOrderNow(gig, selectedExtras)}
              className="w-full py-3 bg-gradient-to-r from-sky-600 to-indigo-600 hover:from-sky-700 hover:to-indigo-700 text-white rounded-xl text-xs sm:text-sm font-bold shadow-lg shadow-sky-600/20 transition active:scale-[0.99] flex items-center justify-center gap-2"
            >
              <span>{t('orderNow')}</span>
              <span>({formatPrice(totalAmountBDT)})</span>
            </button>

            {/* Contact Seller Button */}
            <button
              onClick={() => onContactSeller(gig.sellerId)}
              className="w-full py-2.5 border border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-300 rounded-xl text-xs font-semibold transition flex items-center justify-center gap-2"
            >
              <MessageCircle className="w-3.5 h-3.5 text-sky-500" />
              <span>{language === 'bn' ? 'সেলারকে মেসেজ পাঠান' : 'Contact Seller'}</span>
            </button>

            {/* Escrow Guarantee banner */}
            <div className="p-3 bg-slate-50 dark:bg-slate-800/60 rounded-xl border border-slate-200/80 dark:border-slate-700/60 flex items-start gap-2.5 text-[11px] text-slate-600 dark:text-slate-400">
              <ShieldCheck className="w-4 h-4 text-emerald-500 shrink-0 mt-0.5" />
              <div>
                <span className="font-bold text-slate-800 dark:text-slate-200">
                  100% Escrow Protection
                </span>
                <p className="mt-0.5 leading-snug">
                  {language === 'bn'
                    ? 'আপনার টাকা সম্পূর্ণ নিরাপদ। কাজ বুঝে নিয়ে সন্তুষ্ট হলে তবেই সেলারকে পেমেন্ট রিলিজ হবে।'
                    : 'Funds held securely in escrow until you approve the delivered work.'}
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
