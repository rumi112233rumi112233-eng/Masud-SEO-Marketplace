import React from 'react';
import { Clock, Star } from 'lucide-react';
import { useLanguage } from '../../i18n/LanguageContext';
import { Gig } from '../../types';

interface GigCardProps {
  gig: Gig;
  onClick: (gig: Gig) => void;
}

export const GigCard: React.FC<GigCardProps> = ({ gig, onClick }) => {
  const { language, formatPrice } = useLanguage();

  return (
    <div
      onClick={() => onClick(gig)}
      className="group flex flex-col bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden hover:shadow-lg hover:border-sky-500/50 dark:hover:border-sky-500/50 transition-all duration-200 cursor-pointer"
    >
      {/* Thumbnail Container */}
      <div className="relative aspect-[16/10] overflow-hidden bg-slate-100 dark:bg-slate-800">
        <img
          src={gig.mainImage}
          alt={gig.imageAlt || gig.title}
          loading="lazy"
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
        />
        {gig.isFeatured && (
          <div className="absolute top-2.5 left-2.5 bg-amber-500 text-slate-950 text-[10px] font-extrabold uppercase tracking-wider px-2 py-0.5 rounded shadow-sm">
            Featured
          </div>
        )}
      </div>

      {/* Card Content */}
      <div className="flex flex-col flex-1 p-3.5 sm:p-4">
        {/* Seller Info */}
        <div className="flex items-center gap-2 mb-2">
          <img
            src={gig.sellerAvatar}
            alt={gig.sellerName}
            className="w-6 h-6 rounded-full object-cover border border-slate-200 dark:border-slate-700"
          />
          <span className="text-xs font-semibold text-slate-700 dark:text-slate-300 truncate">
            {gig.sellerName}
          </span>
          <span className="text-slate-300 dark:text-slate-700" aria-hidden="true">·</span>
          <div className="flex items-center gap-1 text-[11px] font-bold text-amber-500">
            <Star className="w-3 h-3 fill-amber-400 stroke-amber-400" />
            <span>{gig.rating.toFixed(1)}</span>
            <span className="text-slate-400 font-normal">({gig.reviewsCount})</span>
          </div>
        </div>

        {/* Gig Title */}
        <h3 className="text-xs sm:text-sm font-semibold text-slate-900 dark:text-slate-100 line-clamp-2 leading-snug group-hover:text-sky-600 dark:group-hover:text-sky-400 transition-colors flex-1 mb-2">
          {language === 'bn' && gig.titleBn ? gig.titleBn : gig.title}
        </h3>

        {/* Metadata info without pills (anti-slop rule) */}
        <div className="flex items-center gap-2 text-[11px] text-slate-500 dark:text-slate-400 mb-3 pt-1 border-t border-slate-100 dark:border-slate-800/80">
          <div className="flex items-center gap-1">
            <Clock className="w-3 h-3 text-slate-400" />
            <span>{gig.deliveryDays}d delivery</span>
          </div>
          <span aria-hidden="true">·</span>
          <span>{gig.salesCount} sold</span>
          <span aria-hidden="true">·</span>
          <span>{gig.revisionLimit === -1 ? 'Unlimited rev' : `${gig.revisionLimit} rev`}</span>
        </div>

        {/* Bottom Price footer */}
        <div className="flex items-baseline justify-between pt-2 border-t border-slate-100 dark:border-slate-800">
          <span className="text-[11px] text-slate-400 uppercase tracking-wider font-medium">
            Starting at
          </span>
          <div className="text-sm sm:text-base font-extrabold text-slate-900 dark:text-white">
            {formatPrice(gig.price)}
          </div>
        </div>
      </div>
    </div>
  );
};
