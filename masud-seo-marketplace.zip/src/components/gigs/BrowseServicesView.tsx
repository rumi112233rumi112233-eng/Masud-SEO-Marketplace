import React, { useMemo, useState } from 'react';
import { Clock, Filter, RotateCcw, Search, SlidersHorizontal, Star } from 'lucide-react';
import { useMarketplace } from '../../context/MarketplaceContext';
import { useLanguage } from '../../i18n/LanguageContext';
import { Gig } from '../../types';
import { GigCard } from './GigCard';

interface BrowseServicesViewProps {
  initialCategoryId?: string;
  initialQuery?: string;
  onSelectGig: (gig: Gig) => void;
}

export const BrowseServicesView: React.FC<BrowseServicesViewProps> = ({
  initialCategoryId,
  initialQuery = '',
  onSelectGig,
}) => {
  const { language, formatPrice, t } = useLanguage();
  const { categories, gigs } = useMarketplace();

  // Filters state
  const [searchQuery, setSearchQuery] = useState(initialQuery);
  const [selectedCategoryId, setSelectedCategoryId] = useState(initialCategoryId || 'all');
  const [minPrice, setMinPrice] = useState<number | ''>('');
  const [maxPrice, setMaxPrice] = useState<number | ''>('');
  const [deliveryFilter, setDeliveryFilter] = useState<'all' | '3' | '7' | 'more'>('all');
  const [ratingFilter, setRatingFilter] = useState<number>(0);
  const [sortBy, setSortBy] = useState<'relevance' | 'newest' | 'price_asc' | 'price_desc' | 'rating'>('relevance');
  const [mobileFilterOpen, setMobileFilterOpen] = useState(false);

  // Filter & sort logic
  const filteredGigs = useMemo(() => {
    return gigs
      .filter((g) => g.status === 'published')
      .filter((g) => {
        // Search query
        if (searchQuery.trim()) {
          const q = searchQuery.toLowerCase().trim();
          const matchTitle = g.title.toLowerCase().includes(q) || (g.titleBn && g.titleBn.toLowerCase().includes(q));
          const matchDesc = g.description.toLowerCase().includes(q);
          const matchTags = g.searchTags.some((t) => t.toLowerCase().includes(q));
          if (!matchTitle && !matchDesc && !matchTags) return false;
        }

        // Category filter
        if (selectedCategoryId !== 'all' && g.categoryId !== selectedCategoryId) {
          return false;
        }

        // Price range
        if (minPrice !== '' && g.price < minPrice) return false;
        if (maxPrice !== '' && g.price > maxPrice) return false;

        // Delivery time
        if (deliveryFilter === '3' && g.deliveryDays > 3) return false;
        if (deliveryFilter === '7' && g.deliveryDays > 7) return false;
        if (deliveryFilter === 'more' && g.deliveryDays <= 7) return false;

        // Rating
        if (ratingFilter > 0 && g.rating < ratingFilter) return false;

        return true;
      })
      .sort((a, b) => {
        if (sortBy === 'newest') return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
        if (sortBy === 'price_asc') return a.price - b.price;
        if (sortBy === 'price_desc') return b.price - a.price;
        if (sortBy === 'rating') return b.rating - a.rating;
        // Relevance: sales count and rating
        return b.salesCount * b.rating - a.salesCount * a.rating;
      });
  }, [gigs, searchQuery, selectedCategoryId, minPrice, maxPrice, deliveryFilter, ratingFilter, sortBy]);

  const handleResetFilters = () => {
    setSearchQuery('');
    setSelectedCategoryId('all');
    setMinPrice('');
    setMaxPrice('');
    setDeliveryFilter('all');
    setRatingFilter(0);
    setSortBy('relevance');
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 animate-in fade-in">
      {/* Search Header */}
      <div className="mb-6">
        <h1 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-white">
          {t('browseServices')}
        </h1>
        <p className="text-xs text-slate-500 mt-0.5">
          {filteredGigs.length} services available with secure bKash, Nagad & Rocket manual escrow protection
        </p>

        {/* Search input bar */}
        <div className="mt-4 flex items-center gap-3">
          <div className="relative flex-1">
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder={t('searchPlaceholder')}
              className="w-full pl-9 pr-4 py-2.5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl text-xs text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-1 focus:ring-sky-500 shadow-sm"
            />
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
          </div>

          <button
            onClick={() => setMobileFilterOpen(!mobileFilterOpen)}
            className="md:hidden flex items-center gap-1.5 px-4 py-2.5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl text-xs font-semibold"
          >
            <Filter className="w-4 h-4" />
            <span>Filters</span>
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
        {/* Sidebar Filters */}
        <div className={`md:block space-y-6 ${mobileFilterOpen ? 'block' : 'hidden'}`}>
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 shadow-sm space-y-5">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
              <span className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider flex items-center gap-1.5">
                <SlidersHorizontal className="w-3.5 h-3.5 text-sky-500" />
                <span>{t('filters')}</span>
              </span>
              <button
                onClick={handleResetFilters}
                className="text-[11px] text-sky-600 hover:underline flex items-center gap-1"
              >
                <RotateCcw className="w-3 h-3" />
                <span>{t('resetFilters')}</span>
              </button>
            </div>

            {/* Category Filter */}
            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-2">
                {t('category')}
              </label>
              <div className="space-y-1 text-xs">
                <button
                  onClick={() => setSelectedCategoryId('all')}
                  className={`w-full text-left px-2.5 py-1.5 rounded-lg transition ${
                    selectedCategoryId === 'all'
                      ? 'bg-sky-50 dark:bg-sky-950/40 text-sky-600 dark:text-sky-400 font-bold'
                      : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
                  }`}
                >
                  All Categories
                </button>
                {categories.map((cat) => (
                  <button
                    key={cat.id}
                    onClick={() => setSelectedCategoryId(cat.id)}
                    className={`w-full text-left px-2.5 py-1.5 rounded-lg transition truncate ${
                      selectedCategoryId === cat.id
                        ? 'bg-sky-50 dark:bg-sky-950/40 text-sky-600 dark:text-sky-400 font-bold'
                        : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
                    }`}
                  >
                    {language === 'bn' ? cat.nameBn : cat.nameEn}
                  </button>
                ))}
              </div>
            </div>

            {/* Price Range (BDT) */}
            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-2">
                {t('priceRange')}
              </label>
              <div className="grid grid-cols-2 gap-2">
                <input
                  type="number"
                  placeholder={t('minPrice')}
                  value={minPrice}
                  onChange={(e) => setMinPrice(e.target.value ? Number(e.target.value) : '')}
                  className="px-2.5 py-1.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-xs"
                />
                <input
                  type="number"
                  placeholder={t('maxPrice')}
                  value={maxPrice}
                  onChange={(e) => setMaxPrice(e.target.value ? Number(e.target.value) : '')}
                  className="px-2.5 py-1.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-xs"
                />
              </div>
            </div>

            {/* Delivery Time */}
            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-2">
                {t('deliveryTime')}
              </label>
              <div className="space-y-1.5 text-xs text-slate-600 dark:text-slate-400">
                {[
                  { id: 'all', label: t('anyTime') },
                  { id: '3', label: t('upTo3Days') },
                  { id: '7', label: t('upTo7Days') },
                  { id: 'more', label: t('moreThan7Days') },
                ].map((item) => (
                  <label key={item.id} className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="radio"
                      name="delivery"
                      checked={deliveryFilter === item.id}
                      onChange={() => setDeliveryFilter(item.id as any)}
                      className="text-sky-600 focus:ring-sky-500"
                    />
                    <span>{item.label}</span>
                  </label>
                ))}
              </div>
            </div>

            {/* Seller Rating Filter */}
            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-2">
                {t('sellerRating')}
              </label>
              <div className="space-y-1.5 text-xs text-slate-600 dark:text-slate-400">
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="radio"
                    name="rating"
                    checked={ratingFilter === 0}
                    onChange={() => setRatingFilter(0)}
                    className="text-sky-600 focus:ring-sky-500"
                  />
                  <span>{t('anyRating')}</span>
                </label>
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="radio"
                    name="rating"
                    checked={ratingFilter === 4}
                    onChange={() => setRatingFilter(4)}
                    className="text-sky-600 focus:ring-sky-500"
                  />
                  <span className="flex items-center gap-1 text-amber-500 font-semibold">
                    <Star className="w-3.5 h-3.5 fill-amber-400 stroke-amber-400" />
                    <span>{t('fourStarsAndAbove')}</span>
                  </span>
                </label>
              </div>
            </div>
          </div>
        </div>

        {/* Services Grid */}
        <div className="md:col-span-3 space-y-4">
          {/* Top Sort By Dropdown */}
          <div className="flex items-center justify-between pb-3 border-b border-slate-200 dark:border-slate-800">
            <span className="text-xs text-slate-500 font-medium">
              Showing <span className="font-bold text-slate-900 dark:text-white">{filteredGigs.length}</span> results
            </span>
            <div className="flex items-center gap-2 text-xs">
              <span className="text-slate-400">{t('sortBy')}:</span>
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value as any)}
                className="bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg px-2.5 py-1 text-xs font-semibold text-slate-800 dark:text-slate-200 focus:outline-none"
              >
                <option value="relevance">{t('sortRelevance')}</option>
                <option value="newest">{t('sortNewest')}</option>
                <option value="price_asc">{t('sortPriceLowHigh')}</option>
                <option value="price_desc">{t('sortPriceHighLow')}</option>
                <option value="rating">{t('sortRating')}</option>
              </select>
            </div>
          </div>

          {/* Gigs List */}
          {filteredGigs.length > 0 ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
              {filteredGigs.map((gig) => (
                <GigCard key={gig.id} gig={gig} onClick={onSelectGig} />
              ))}
            </div>
          ) : (
            <div className="py-16 text-center bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-8">
              <p className="text-xs text-slate-400 max-w-sm mx-auto">{t('noGigsFound')}</p>
              <button
                onClick={handleResetFilters}
                className="mt-4 px-4 py-2 bg-sky-600 hover:bg-sky-700 text-white rounded-xl text-xs font-bold transition shadow-sm"
              >
                {t('resetFilters')}
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
