import React from 'react';
import {
  ArrowRight,
  CheckCircle2,
  Code,
  FileText,
  Flame,
  Globe,
  Layers,
  Link2,
  Lock,
  MapPin,
  Search,
  Shield,
  ShieldCheck,
  Sparkles,
  TrendingUp,
  Users,
  Zap,
} from 'lucide-react';
import { useMarketplace } from '../../context/MarketplaceContext';
import { useLanguage } from '../../i18n/LanguageContext';
import { Gig } from '../../types';
import { GigCard } from '../gigs/GigCard';

interface HomeViewProps {
  onNavigateToBrowse: (categoryId?: string) => void;
  onSelectGig: (gig: Gig) => void;
  onOpenCreateGig: () => void;
  onOpenDeploy: () => void;
}

export const HomeView: React.FC<HomeViewProps> = ({
  onNavigateToBrowse,
  onSelectGig,
  onOpenCreateGig,
  onOpenDeploy,
}) => {
  const { language, t } = useLanguage();
  const { categories, gigs } = useMarketplace();

  const featuredGigs = gigs.filter((g) => g.status === 'published' && g.isFeatured);
  const trendingGigs = gigs.filter((g) => g.status === 'published').slice(0, 6);

  const getCategoryIcon = (iconName: string) => {
    switch (iconName) {
      case 'Link2':
        return <Link2 className="w-5 h-5 text-sky-500" />;
      case 'Code':
        return <Code className="w-5 h-5 text-indigo-500" />;
      case 'Zap':
        return <Zap className="w-5 h-5 text-amber-500" />;
      case 'FileText':
        return <FileText className="w-5 h-5 text-emerald-500" />;
      case 'MapPin':
        return <MapPin className="w-5 h-5 text-rose-500" />;
      default:
        return <Layers className="w-5 h-5 text-sky-500" />;
    }
  };

  return (
    <div className="space-y-12 sm:space-y-16 animate-in fade-in pb-12">
      {/* ==================================================== */}
      {/* 1. HERO SECTION */}
      {/* ==================================================== */}
      <section className="relative overflow-hidden bg-gradient-to-b from-sky-950 via-slate-900 to-slate-950 text-white py-16 sm:py-24 px-4 sm:px-6 lg:px-8">
        <div className="absolute inset-0 opacity-10 bg-[radial-gradient(#38bdf8_1px,transparent_1px)] [background-size:16px_16px]"></div>
        
        <div className="max-w-4xl mx-auto text-center relative z-10 space-y-6">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-sky-500/10 border border-sky-400/20 text-sky-300 text-xs font-semibold backdrop-blur-sm">
            <Sparkles className="w-3.5 h-3.5 text-sky-400" />
            <span>{language === 'bn' ? 'বিশ্বস্ত এসইও সার্ভিস মার্কেটপ্লেস' : 'Inspired by SEOClerks · Freelance SEO Marketplace'}</span>
          </div>

          <h1 className="text-3xl sm:text-5xl lg:text-6xl font-black tracking-tight leading-tight">
            {language === 'bn' ? (
              <>
                টপ এসইও বিশেষজ্ঞদের দিয়ে <br className="hidden sm:inline" />
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-sky-400 to-indigo-300">
                  গুগল র‍্যাংকিং বৃদ্ধি করুন
                </span>
              </>
            ) : (
              <>
                Hire Verified SEO Experts & <br className="hidden sm:inline" />
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-sky-400 to-indigo-300">
                  Dominate Google Search
                </span>
              </>
            )}
          </h1>

          <p className="text-sm sm:text-base text-slate-300 max-w-2xl mx-auto leading-relaxed">
            {t('heroSubtitle')}
          </p>

          {/* Quick CTA Actions */}
          <div className="flex flex-wrap items-center justify-center gap-3 pt-4">
            <button
              onClick={() => onNavigateToBrowse()}
              className="px-6 py-3 bg-gradient-to-r from-sky-500 to-indigo-600 hover:from-sky-600 hover:to-indigo-700 text-white rounded-xl text-xs sm:text-sm font-bold shadow-lg shadow-sky-500/25 transition active:scale-95 flex items-center gap-2"
            >
              <span>{t('exploreCategories')}</span>
              <ArrowRight className="w-4 h-4" />
            </button>

            <button
              onClick={onOpenCreateGig}
              className="px-6 py-3 bg-white/10 hover:bg-white/20 text-white rounded-xl text-xs sm:text-sm font-bold backdrop-blur-sm border border-white/15 transition active:scale-95"
            >
              {t('postServiceNow')}
            </button>
          </div>

          {/* Live Trust Metrics */}
          <div className="pt-8 border-t border-slate-800/80 grid grid-cols-2 sm:grid-cols-4 gap-4 text-left max-w-3xl mx-auto">
            <div>
              <div className="text-lg sm:text-xl font-black text-white">৳৫০০+</div>
              <div className="text-[11px] text-slate-400">Starting Service Price</div>
            </div>
            <div>
              <div className="text-lg sm:text-xl font-black text-white">100% Escrow</div>
              <div className="text-[11px] text-slate-400">Manual Payment Protection</div>
            </div>
            <div>
              <div className="text-lg sm:text-xl font-black text-white">bKash/Nagad</div>
              <div className="text-[11px] text-slate-400">Fast TrxID Verification</div>
            </div>
            <div>
              <div className="text-lg sm:text-xl font-black text-white">140+ Gigs</div>
              <div className="text-[11px] text-slate-400">Completed Orders</div>
            </div>
          </div>
        </div>
      </section>

      {/* ==================================================== */}
      {/* 2. CATEGORIES GRID */}
      {/* ==================================================== */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h2 className="text-lg sm:text-xl font-bold text-slate-900 dark:text-white">
              {t('allCategories')}
            </h2>
            <p className="text-xs text-slate-500">
              Browse professional search engine optimization specializations
            </p>
          </div>
          <button
            onClick={() => onNavigateToBrowse()}
            className="text-xs font-bold text-sky-600 dark:text-sky-400 hover:underline flex items-center gap-1"
          >
            <span>View All</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
          {categories.map((cat) => (
            <div
              key={cat.id}
              onClick={() => onNavigateToBrowse(cat.id)}
              className="p-4 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl hover:border-sky-500 hover:shadow-md transition cursor-pointer group"
            >
              <div className="w-10 h-10 rounded-xl bg-slate-50 dark:bg-slate-800 flex items-center justify-center mb-3 group-hover:scale-110 transition-transform">
                {getCategoryIcon(cat.iconName)}
              </div>
              <h3 className="text-xs sm:text-sm font-bold text-slate-900 dark:text-slate-100 group-hover:text-sky-600 transition-colors">
                {language === 'bn' ? cat.nameBn : cat.nameEn}
              </h3>
              <p className="text-[11px] text-slate-400 line-clamp-2 mt-1">
                {language === 'bn' ? cat.descriptionBn : cat.descriptionEn}
              </p>
            </div>
          ))}
        </div>
      </section>

      {/* ==================================================== */}
      {/* 3. FEATURED SERVICES CAROUSEL / GRID */}
      {/* ==================================================== */}
      {featuredGigs.length > 0 && (
        <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-2">
              <Flame className="w-5 h-5 text-amber-500" />
              <div>
                <h2 className="text-lg sm:text-xl font-bold text-slate-900 dark:text-white">
                  {t('featuredGigs')}
                </h2>
                <p className="text-xs text-slate-500">
                  Hand-picked high authority SEO services with verified buyer reviews
                </p>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {featuredGigs.map((gig) => (
              <GigCard key={gig.id} gig={gig} onClick={onSelectGig} />
            ))}
          </div>
        </section>
      )}

      {/* ==================================================== */}
      {/* 4. TRENDING SERVICES */}
      {/* ==================================================== */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-2">
            <TrendingUp className="w-5 h-5 text-sky-500" />
            <div>
              <h2 className="text-lg sm:text-xl font-bold text-slate-900 dark:text-white">
                {t('trendingGigs')}
              </h2>
              <p className="text-xs text-slate-500">
                Popular SEO and digital growth gigs trending right now
              </p>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {trendingGigs.map((gig) => (
            <GigCard key={gig.id} gig={gig} onClick={onSelectGig} />
          ))}
        </div>
      </section>

      {/* ==================================================== */}
      {/* 5. WHY CHOOSE MASUD SEO MARKETPLACE */}
      {/* ==================================================== */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="p-8 bg-gradient-to-br from-slate-900 to-sky-950 text-white rounded-3xl border border-slate-800 shadow-xl">
          <div className="text-center max-w-2xl mx-auto mb-10">
            <span className="text-xs font-bold text-sky-400 uppercase tracking-widest">
              Safe & Transparent Freelancing
            </span>
            <h2 className="text-2xl sm:text-3xl font-black mt-1">
              {t('whyChooseUs')}
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <div className="p-5 bg-white/5 border border-white/10 rounded-2xl space-y-2 backdrop-blur-sm">
              <div className="w-9 h-9 rounded-xl bg-sky-500/20 text-sky-400 flex items-center justify-center font-bold">
                ✓
              </div>
              <h4 className="text-sm font-bold text-white">{t('whyReason1Title')}</h4>
              <p className="text-xs text-slate-300 leading-relaxed">{t('whyReason1Desc')}</p>
            </div>

            <div className="p-5 bg-white/5 border border-white/10 rounded-2xl space-y-2 backdrop-blur-sm">
              <div className="w-9 h-9 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-bold">
                ৳
              </div>
              <h4 className="text-sm font-bold text-white">{t('whyReason2Title')}</h4>
              <p className="text-xs text-slate-300 leading-relaxed">{t('whyReason2Desc')}</p>
            </div>

            <div className="p-5 bg-white/5 border border-white/10 rounded-2xl space-y-2 backdrop-blur-sm">
              <div className="w-9 h-9 rounded-xl bg-purple-500/20 text-purple-400 flex items-center justify-center font-bold">
                🛡️
              </div>
              <h4 className="text-sm font-bold text-white">{t('whyReason3Title')}</h4>
              <p className="text-xs text-slate-300 leading-relaxed">{t('whyReason3Desc')}</p>
            </div>

            <div className="p-5 bg-white/5 border border-white/10 rounded-2xl space-y-2 backdrop-blur-sm">
              <div className="w-9 h-9 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center font-bold">
                ⚖️
              </div>
              <h4 className="text-sm font-bold text-white">{t('whyReason4Title')}</h4>
              <p className="text-xs text-slate-300 leading-relaxed">{t('whyReason4Desc')}</p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};
