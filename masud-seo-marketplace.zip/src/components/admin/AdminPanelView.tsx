import React, { useState } from 'react';
import {
  AlertCircle,
  AlertTriangle,
  ArrowUpRight,
  Check,
  CheckCircle2,
  Clock,
  CreditCard,
  DollarSign,
  Download,
  Eye,
  FileCode,
  Layers,
  Lock,
  Mail,
  RefreshCw,
  Search,
  Server,
  Settings,
  ShieldAlert,
  ShieldCheck,
  ShoppingBag,
  Sliders,
  Sparkles,
  Users,
  X,
  XCircle,
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { useMarketplace } from '../../context/MarketplaceContext';
import { useLanguage } from '../../i18n/LanguageContext';
import { AdminAuditLog, Dispute, Order, PaymentSubmission, PlatformSettings, User } from '../../types';

interface AdminPanelViewProps {
  onOpenDeployModal: () => void;
  onViewOrder: (order: Order) => void;
}

export const AdminPanelView: React.FC<AdminPanelViewProps> = ({
  onOpenDeployModal,
  onViewOrder,
}) => {
  const { language, formatPrice, t } = useLanguage();
  const { currentUser, users, mustChangeAdminPasswordNotice, changePassword, dismissAdminPasswordNotice } = useAuth();
  const {
    gigs,
    orders,
    settings,
    disputes,
    ledger,
    auditLogs,
    verifyOrderPayment,
    rejectOrderPayment,
    resolveDispute,
    updateSettings,
    toggleGigStatus,
  } = useMarketplace();

  type AdminTab =
    | 'overview'
    | 'payments'
    | 'orders'
    | 'gigs'
    | 'users'
    | 'disputes'
    | 'settings'
    | 'email'
    | 'audit';

  const [activeTab, setActiveTab] = useState<AdminTab>('overview');

  // Admin password reset modal state
  const [showPasswordChangeModal, setShowPasswordChangeModal] = useState(false);
  const [oldPassword, setOldPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [passwordMsg, setPasswordMsg] = useState({ text: '', isError: false });

  // Payment reject modal state
  const [rejectingOrderId, setRejectingOrderId] = useState<string | null>(null);
  const [rejectReason, setRejectReason] = useState('');

  // Editable settings local state
  const [localSettings, setLocalSettings] = useState<PlatformSettings>({ ...settings });
  const [settingsSavedToast, setSettingsSavedToast] = useState(false);

  // Filter/Search states
  const [searchPaymentQuery, setSearchPaymentQuery] = useState('');

  // Stats calculation
  const totalUsersCount = users.length;
  const buyersCount = users.filter((u) => u.role === 'buyer').length;
  const sellersCount = users.filter((u) => u.role === 'seller').length;
  const totalOrdersCount = orders.length;
  const pendingPayments = orders.filter(
    (o) => o.paymentSubmission?.status === 'pending_verification'
  );
  const verifiedPaymentsCount = orders.filter(
    (o) => o.paymentSubmission?.status === 'verified'
  ).length;
  const openDisputesCount = disputes.filter((d) => d.status === 'open').length;

  const totalPlatformRevenueBDT = ledger
    .filter((l) => l.type === 'order_payment' || l.type === 'seller_release')
    .reduce((sum, l) => sum + (l.platformFeeBDT || 0), 0);

  const totalEscrowHeldBDT = ledger
    .filter((l) => l.status === 'held_in_escrow')
    .reduce((sum, l) => sum + (l.sellerAmountBDT || 0), 0);

  const handlePasswordChangeSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const res = changePassword(oldPassword, newPassword);
    if (res.success) {
      setPasswordMsg({ text: res.message, isError: false });
      setTimeout(() => {
        setShowPasswordChangeModal(false);
        setPasswordMsg({ text: '', isError: false });
      }, 1500);
    } else {
      setPasswordMsg({ text: res.message, isError: true });
    }
  };

  const handleSaveSettings = (e: React.FormEvent) => {
    e.preventDefault();
    updateSettings(localSettings);
    setSettingsSavedToast(true);
    setTimeout(() => setSettingsSavedToast(false), 2500);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 animate-in fade-in">
      {/* Initial Admin Password Warning Banner (Security Hardening Requirement) */}
      {mustChangeAdminPasswordNotice && (
        <div className="mb-6 p-4 rounded-xl bg-amber-500/15 border border-amber-500/30 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-amber-900 dark:text-amber-200 text-xs">
          <div className="flex items-center gap-2">
            <Lock className="w-5 h-5 text-amber-500 shrink-0" />
            <div>
              <span className="font-bold block">
                Security Warning: Default Setup Password in Use (`masud#1234567`)
              </span>
              <span className="text-[11px] text-amber-700 dark:text-amber-300">
                Please change the initial administrator password before deploying into production.
              </span>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => setShowPasswordChangeModal(true)}
              className="px-3 py-1.5 bg-amber-600 hover:bg-amber-700 text-white rounded-lg font-bold shadow-sm"
            >
              Change Admin Password Now
            </button>
            <button
              onClick={dismissAdminPasswordNotice}
              className="p-1 hover:bg-amber-500/20 rounded"
            >
              <X className="w-4 h-4 text-amber-600" />
            </button>
          </div>
        </div>
      )}

      {/* Admin Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8 pb-6 border-b border-slate-200 dark:border-slate-800">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2 py-0.5 rounded bg-amber-500/20 text-amber-600 dark:text-amber-400 font-extrabold text-[10px] tracking-wider uppercase">
              Root Administrator
            </span>
            <span className="text-xs text-slate-400">addminmasud</span>
          </div>
          <h1 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-white mt-1">
            {t('adminDashboardTitle')}
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Official Portal for www.masudseoservice.com · Email: {settings.adminAlertEmail}
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={onOpenDeployModal}
            className="flex items-center gap-1.5 px-3.5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold shadow-md transition"
          >
            <Server className="w-4 h-4" />
            <span>InfinityFree SQL & PHP Pack</span>
          </button>
        </div>
      </div>

      {/* Admin Tabs Bar */}
      <div className="flex items-center gap-1 overflow-x-auto pb-2 border-b border-slate-200 dark:border-slate-800 mb-6">
        {[
          { id: 'overview', label: 'Overview', icon: Sliders },
          { id: 'payments', label: `Payment Verification (${pendingPayments.length})`, icon: CreditCard, badge: pendingPayments.length },
          { id: 'orders', label: 'Orders', icon: ShoppingBag },
          { id: 'gigs', label: 'Gig Moderation', icon: Layers },
          { id: 'users', label: 'Users', icon: Users },
          { id: 'disputes', label: `Disputes (${openDisputesCount})`, icon: AlertTriangle, badge: openDisputesCount },
          { id: 'settings', label: 'Platform Settings', icon: Settings },
          { id: 'email', label: 'Email Alerts', icon: Mail },
          { id: 'audit', label: 'Audit Logs', icon: Clock },
        ].map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as AdminTab)}
              className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition ${
                isActive
                  ? 'bg-slate-900 text-white dark:bg-white dark:text-slate-900 shadow-sm'
                  : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
              }`}
            >
              <Icon className="w-3.5 h-3.5" />
              <span>{tab.label}</span>
              {Boolean(tab.badge) && tab.badge! > 0 && (
                <span className="w-4 h-4 rounded-full bg-rose-500 text-white text-[9px] font-bold flex items-center justify-center">
                  {tab.badge}
                </span>
              )}
            </button>
          );
        })}
      </div>

      {/* ==================================================== */}
      {/* 1. OVERVIEW TAB */}
      {/* ==================================================== */}
      {activeTab === 'overview' && (
        <div className="space-y-6">
          {/* Key Stat Cards */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="p-4 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-sm">
              <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">
                Platform Commission
              </span>
              <div className="text-xl sm:text-2xl font-black text-emerald-600 dark:text-emerald-400 mt-1">
                ৳{totalPlatformRevenueBDT.toLocaleString('en-IN')}
              </div>
              <span className="text-[10px] text-slate-400 mt-0.5 block">10% Fee on completed gigs</span>
            </div>

            <div className="p-4 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-sm">
              <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">
                Held in Escrow
              </span>
              <div className="text-xl sm:text-2xl font-black text-sky-600 dark:text-sky-400 mt-1">
                ৳{totalEscrowHeldBDT.toLocaleString('en-IN')}
              </div>
              <span className="text-[10px] text-slate-400 mt-0.5 block">Safe pending work delivery</span>
            </div>

            <div className="p-4 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-sm">
              <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">
                Pending Verification
              </span>
              <div className="text-xl sm:text-2xl font-black text-amber-500 mt-1">
                {pendingPayments.length} TrxID
              </div>
              <span className="text-[10px] text-slate-400 mt-0.5 block">Requires mobile wallet check</span>
            </div>

            <div className="p-4 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-sm">
              <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">
                Total Orders
              </span>
              <div className="text-xl sm:text-2xl font-black text-slate-900 dark:text-white mt-1">
                {totalOrdersCount}
              </div>
              <span className="text-[10px] text-slate-400 mt-0.5 block">{verifiedPaymentsCount} verified & active</span>
            </div>
          </div>

          {/* Quick Action: Pending Payments Highlight */}
          {pendingPayments.length > 0 && (
            <div className="p-5 bg-gradient-to-r from-amber-500/10 to-orange-500/10 border border-amber-500/30 rounded-2xl space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 text-amber-800 dark:text-amber-200">
                  <ShieldAlert className="w-5 h-5 text-amber-500" />
                  <h3 className="font-bold text-sm">
                    {pendingPayments.length} Bangladesh Payment(s) Awaiting Admin Verification
                  </h3>
                </div>
                <button
                  onClick={() => setActiveTab('payments')}
                  className="px-3 py-1 bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold rounded-lg text-xs"
                >
                  Inspect & Verify →
                </button>
              </div>
            </div>
          )}

          {/* Recent Orders Overview */}
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-sm">
            <h3 className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider mb-4">
              Recent Marketplace Orders
            </h3>
            <div className="overflow-x-auto">
              <table className="w-full text-xs text-left">
                <thead className="bg-slate-50 dark:bg-slate-800 text-slate-500 font-semibold uppercase text-[10px]">
                  <tr>
                    <th className="p-3">Order #</th>
                    <th className="p-3">Service</th>
                    <th className="p-3">Buyer</th>
                    <th className="p-3">Amount</th>
                    <th className="p-3">Status</th>
                    <th className="p-3">Date</th>
                    <th className="p-3">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                  {orders.slice(0, 5).map((ord) => (
                    <tr key={ord.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/50">
                      <td className="p-3 font-mono font-bold text-slate-900 dark:text-white">
                        {ord.orderNumber}
                      </td>
                      <td className="p-3 font-medium text-slate-700 dark:text-slate-300 max-w-xs truncate">
                        {ord.gigTitle}
                      </td>
                      <td className="p-3 text-slate-600 dark:text-slate-400">
                        {ord.buyerName}
                      </td>
                      <td className="p-3 font-bold text-slate-900 dark:text-white">
                        ৳{ord.totalAmountBDT}
                      </td>
                      <td className="p-3">
                        <span className="capitalize px-2 py-0.5 rounded bg-slate-100 dark:bg-slate-800 font-semibold text-[10px]">
                          {ord.status.replace('_', ' ')}
                        </span>
                      </td>
                      <td className="p-3 text-slate-400 text-[11px]">
                        {new Date(ord.createdAt).toLocaleDateString()}
                      </td>
                      <td className="p-3">
                        <button
                          onClick={() => onViewOrder(ord)}
                          className="text-sky-600 hover:underline font-semibold"
                        >
                          View Order
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* ==================================================== */}
      {/* 2. PAYMENT VERIFICATION TAB (bKash, Nagad, Rocket) */}
      {/* ==================================================== */}
      {activeTab === 'payments' && (
        <div className="space-y-6">
          <div className="p-4 bg-sky-50 dark:bg-sky-950/40 border border-sky-200 dark:border-sky-800 rounded-2xl text-xs text-sky-900 dark:text-sky-200 leading-relaxed">
            <span className="font-bold">Official Admin Payment Instructions:</span> Check the incoming transactions in your official personal/merchant accounts:
            <div className="mt-2 grid grid-cols-1 sm:grid-cols-3 gap-2 font-mono font-bold text-[11px]">
              <div className="bg-white/80 dark:bg-slate-800 p-2 rounded">bKash: {settings.bkashNumber}</div>
              <div className="bg-white/80 dark:bg-slate-800 p-2 rounded">Nagad: {settings.nagadNumber}</div>
              <div className="bg-white/80 dark:bg-slate-800 p-2 rounded">Rocket: {settings.rocketNumber}</div>
            </div>
          </div>

          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-sm">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-4">
              <h3 className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider">
                Transaction Submissions Log ({orders.filter((o) => o.paymentSubmission).length})
              </h3>
              <input
                type="text"
                placeholder="Search by TrxID or Sender Number..."
                value={searchPaymentQuery}
                onChange={(e) => setSearchPaymentQuery(e.target.value)}
                className="px-3 py-1.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-xs font-mono"
              />
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-xs text-left">
                <thead className="bg-slate-50 dark:bg-slate-800 text-slate-500 font-semibold uppercase text-[10px]">
                  <tr>
                    <th className="p-3">Order #</th>
                    <th className="p-3">Method</th>
                    <th className="p-3">Sender Number</th>
                    <th className="p-3">TrxID</th>
                    <th className="p-3">Amount</th>
                    <th className="p-3">Date</th>
                    <th className="p-3">Status</th>
                    <th className="p-3">Proof</th>
                    <th className="p-3 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                  {orders
                    .filter((o) => o.paymentSubmission)
                    .filter((o) => {
                      if (!searchPaymentQuery) return true;
                      const q = searchPaymentQuery.toLowerCase();
                      return (
                        o.paymentSubmission?.transactionId.toLowerCase().includes(q) ||
                        o.paymentSubmission?.senderNumber.includes(q) ||
                        o.orderNumber.toLowerCase().includes(q)
                      );
                    })
                    .map((ord) => {
                      const pay = ord.paymentSubmission!;
                      return (
                        <tr key={pay.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/50">
                          <td className="p-3 font-mono font-bold text-slate-900 dark:text-white">
                            {ord.orderNumber}
                          </td>
                          <td className="p-3">
                            <span className="font-bold uppercase text-[10px] px-2 py-0.5 rounded bg-slate-100 dark:bg-slate-800">
                              {pay.method}
                            </span>
                          </td>
                          <td className="p-3 font-mono font-medium text-slate-700 dark:text-slate-300">
                            {pay.senderNumber}
                          </td>
                          <td className="p-3 font-mono font-extrabold text-sky-600 dark:text-sky-400">
                            {pay.transactionId}
                          </td>
                          <td className="p-3 font-bold text-slate-900 dark:text-white">
                            ৳{pay.amountBDT}
                          </td>
                          <td className="p-3 text-slate-400 text-[11px]">
                            {new Date(pay.paymentDate).toLocaleString()}
                          </td>
                          <td className="p-3">
                            <span
                              className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                                pay.status === 'verified'
                                  ? 'bg-emerald-100 text-emerald-700 dark:bg-emerald-950/60 dark:text-emerald-300'
                                  : pay.status === 'rejected'
                                  ? 'bg-rose-100 text-rose-700 dark:bg-rose-950/60 dark:text-rose-300'
                                  : 'bg-amber-100 text-amber-800 dark:bg-amber-950/60 dark:text-amber-300'
                              }`}
                            >
                              {pay.status.replace('_', ' ')}
                            </span>
                          </td>
                          <td className="p-3">
                            {pay.screenshotUrl ? (
                              <a
                                href={pay.screenshotUrl}
                                target="_blank"
                                rel="noreferrer"
                                className="text-sky-600 hover:underline flex items-center gap-1"
                              >
                                <Eye className="w-3 h-3" /> View
                              </a>
                            ) : (
                              <span className="text-slate-400 text-[10px]">None</span>
                            )}
                          </td>
                          <td className="p-3 text-right">
                            {pay.status === 'pending_verification' && (
                              <div className="flex items-center justify-end gap-1.5">
                                <button
                                  onClick={() => verifyOrderPayment(ord.id)}
                                  className="px-2.5 py-1 bg-emerald-600 hover:bg-emerald-700 text-white rounded text-[11px] font-bold"
                                  title="Approve & Release to Escrow"
                                >
                                  ✓ Verify
                                </button>
                                <button
                                  onClick={() => {
                                    setRejectingOrderId(ord.id);
                                    setRejectReason('');
                                  }}
                                  className="px-2 py-1 bg-rose-600 hover:bg-rose-700 text-white rounded text-[11px] font-bold"
                                  title="Reject Submission"
                                >
                                  ✗ Reject
                                </button>
                              </div>
                            )}
                            {pay.status === 'verified' && (
                              <span className="text-emerald-600 text-[11px] font-semibold">
                                ✓ Verified by {pay.verifiedBy || 'Admin'}
                              </span>
                            )}
                            {pay.status === 'rejected' && (
                              <span className="text-rose-500 text-[11px] font-semibold">
                                Reason: {pay.rejectionReason}
                              </span>
                            )}
                          </td>
                        </tr>
                      );
                    })}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* ==================================================== */}
      {/* 3. PLATFORM SETTINGS TAB */}
      {/* ==================================================== */}
      {activeTab === 'settings' && (
        <form onSubmit={handleSaveSettings} className="space-y-6">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-sm space-y-4">
            <h3 className="text-sm font-bold text-slate-900 dark:text-white uppercase tracking-wider">
              General Website & Brand Settings
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
              <div>
                <label className="block font-semibold mb-1">Website Name</label>
                <input
                  type="text"
                  value={localSettings.websiteName}
                  onChange={(e) => setLocalSettings({ ...localSettings, websiteName: e.target.value })}
                  className="w-full p-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg"
                />
              </div>
              <div>
                <label className="block font-semibold mb-1">Website Domain</label>
                <input
                  type="text"
                  value={localSettings.domain}
                  onChange={(e) => setLocalSettings({ ...localSettings, domain: e.target.value })}
                  className="w-full p-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg"
                />
              </div>
              <div>
                <label className="block font-semibold mb-1">Support Email</label>
                <input
                  type="email"
                  value={localSettings.contactEmail}
                  onChange={(e) => setLocalSettings({ ...localSettings, contactEmail: e.target.value })}
                  className="w-full p-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg"
                />
              </div>
              <div>
                <label className="block font-semibold mb-1">Admin Notification Email</label>
                <input
                  type="email"
                  value={localSettings.adminAlertEmail}
                  onChange={(e) => setLocalSettings({ ...localSettings, adminAlertEmail: e.target.value })}
                  className="w-full p-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg"
                />
              </div>
            </div>
          </div>

          {/* Official Bangladesh Payment Account Settings */}
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-sm space-y-4">
            <h3 className="text-sm font-bold text-slate-900 dark:text-white uppercase tracking-wider flex items-center gap-2">
              <CreditCard className="w-4 h-4 text-emerald-500" />
              <span>Official Bangladesh Manual Payment Accounts</span>
            </h3>
            <p className="text-xs text-slate-500">
              These account numbers are shown to buyers when checking out. Editable at any time.
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs font-mono">
              <div>
                <label className="block font-bold text-pink-600 dark:text-pink-400 mb-1">
                  bKash Account Number
                </label>
                <input
                  type="text"
                  value={localSettings.bkashNumber}
                  onChange={(e) => setLocalSettings({ ...localSettings, bkashNumber: e.target.value })}
                  className="w-full p-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg font-bold"
                />
              </div>
              <div>
                <label className="block font-bold text-amber-600 dark:text-amber-400 mb-1">
                  Nagad Account Number
                </label>
                <input
                  type="text"
                  value={localSettings.nagadNumber}
                  onChange={(e) => setLocalSettings({ ...localSettings, nagadNumber: e.target.value })}
                  className="w-full p-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg font-bold"
                />
              </div>
              <div>
                <label className="block font-bold text-purple-600 dark:text-purple-400 mb-1">
                  Rocket Account Number
                </label>
                <input
                  type="text"
                  value={localSettings.rocketNumber}
                  onChange={(e) => setLocalSettings({ ...localSettings, rocketNumber: e.target.value })}
                  className="w-full p-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg font-bold"
                />
              </div>
            </div>
          </div>

          {/* Marketplace Commission & Limits */}
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-sm space-y-4">
            <h3 className="text-sm font-bold text-slate-900 dark:text-white uppercase tracking-wider">
              Marketplace Economics & Price Limits
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
              <div>
                <label className="block font-semibold mb-1">Platform Commission (%)</label>
                <input
                  type="number"
                  min={0}
                  max={50}
                  value={localSettings.commissionPercentage}
                  onChange={(e) =>
                    setLocalSettings({ ...localSettings, commissionPercentage: Number(e.target.value) })
                  }
                  className="w-full p-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg"
                />
              </div>
              <div>
                <label className="block font-semibold mb-1">Minimum Gig Price (BDT)</label>
                <input
                  type="number"
                  min={100}
                  value={localSettings.minGigPriceBDT}
                  onChange={(e) =>
                    setLocalSettings({ ...localSettings, minGigPriceBDT: Number(e.target.value) })
                  }
                  className="w-full p-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg"
                />
              </div>
              <div>
                <label className="block font-semibold mb-1">Maximum Gig Price (BDT)</label>
                <input
                  type="number"
                  value={localSettings.maxGigPriceBDT}
                  onChange={(e) =>
                    setLocalSettings({ ...localSettings, maxGigPriceBDT: Number(e.target.value) })
                  }
                  className="w-full p-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg"
                />
              </div>
            </div>
          </div>

          <div className="flex items-center justify-between">
            {settingsSavedToast && (
              <span className="text-xs font-bold text-emerald-600 dark:text-emerald-400 flex items-center gap-1">
                <CheckCircle2 className="w-4 h-4" /> Platform settings saved successfully!
              </span>
            )}
            <button
              type="submit"
              className="ml-auto px-6 py-2.5 bg-sky-600 hover:bg-sky-700 text-white rounded-xl text-xs font-bold shadow-md transition"
            >
              Save Website Settings
            </button>
          </div>
        </form>
      )}

      {/* ==================================================== */}
      {/* 4. DISPUTE CASES TAB */}
      {/* ==================================================== */}
      {activeTab === 'disputes' && (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-sm">
          <h3 className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider mb-4">
            Dispute Resolution Cases ({disputes.length})
          </h3>

          {disputes.length > 0 ? (
            <div className="space-y-4">
              {disputes.map((disp) => (
                <div
                  key={disp.id}
                  className="p-4 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl space-y-3"
                >
                  <div className="flex items-center justify-between">
                    <div>
                      <span className="font-mono font-bold text-slate-900 dark:text-white text-xs">
                        {disp.orderNumber}
                      </span>
                      <span className="text-[11px] text-slate-400 ml-2">
                        Opened by {disp.openedByName} ({disp.openedByRole})
                      </span>
                    </div>
                    <span
                      className={`text-[10px] font-bold px-2 py-0.5 rounded ${
                        disp.status === 'resolved'
                          ? 'bg-emerald-100 text-emerald-700'
                          : 'bg-rose-100 text-rose-700'
                      }`}
                    >
                      {disp.status.toUpperCase()}
                    </span>
                  </div>

                  <div className="text-xs text-slate-700 dark:text-slate-300">
                    <span className="font-bold">Reason:</span> {disp.reasonCategory}
                    <p className="mt-1 font-mono text-[11px] bg-white dark:bg-slate-900 p-2.5 rounded border border-slate-200 dark:border-slate-800">
                      "{disp.description}"
                    </p>
                  </div>

                  {disp.status === 'open' && (
                    <div className="flex items-center gap-2 pt-2 border-t border-slate-200 dark:border-slate-700">
                      <button
                        onClick={() => resolveDispute(disp.id, 'refund', 'Admin issued full refund.')}
                        className="px-3 py-1 bg-cyan-600 hover:bg-cyan-700 text-white rounded text-xs font-bold"
                      >
                        Issue Full Refund
                      </button>
                      <button
                        onClick={() => resolveDispute(disp.id, 'release_payment', 'Admin confirmed work fulfilled.')}
                        className="px-3 py-1 bg-emerald-600 hover:bg-emerald-700 text-white rounded text-xs font-bold"
                      >
                        Release Payment to Seller
                      </button>
                    </div>
                  )}

                  {disp.adminDecision && (
                    <div className="text-[11px] text-emerald-600 dark:text-emerald-400 font-medium">
                      ✓ Resolved by {disp.adminDecision.decidedBy}: {disp.adminDecision.action} ({disp.adminDecision.notes})
                    </div>
                  )}
                </div>
              ))}
            </div>
          ) : (
            <p className="text-xs text-slate-400 text-center py-6">
              No dispute cases reported. All orders executing normally.
            </p>
          )}
        </div>
      )}

      {/* ==================================================== */}
      {/* 5. GIG MODERATION TAB */}
      {/* ==================================================== */}
      {activeTab === 'gigs' && (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-sm">
          <h3 className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider mb-4">
            Marketplace Gigs ({gigs.length})
          </h3>
          <div className="overflow-x-auto">
            <table className="w-full text-xs text-left">
              <thead className="bg-slate-50 dark:bg-slate-800 text-slate-500 font-semibold uppercase text-[10px]">
                <tr>
                  <th className="p-3">Cover</th>
                  <th className="p-3">Gig Title</th>
                  <th className="p-3">Seller</th>
                  <th className="p-3">Price</th>
                  <th className="p-3">Rating</th>
                  <th className="p-3">Status</th>
                  <th className="p-3 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {gigs.map((g) => (
                  <tr key={g.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/50">
                    <td className="p-3">
                      <img src={g.mainImage} alt="" className="w-12 h-8 rounded object-cover" />
                    </td>
                    <td className="p-3 font-semibold text-slate-800 dark:text-slate-200 max-w-sm truncate">
                      {g.title}
                    </td>
                    <td className="p-3 text-slate-600 dark:text-slate-400">{g.sellerName}</td>
                    <td className="p-3 font-bold text-slate-900 dark:text-white">৳{g.price}</td>
                    <td className="p-3 text-amber-500 font-bold">★ {g.rating.toFixed(1)}</td>
                    <td className="p-3">
                      <span className="capitalize px-2 py-0.5 rounded bg-slate-100 dark:bg-slate-800 font-medium text-[10px]">
                        {g.status}
                      </span>
                    </td>
                    <td className="p-3 text-right">
                      <button
                        onClick={() =>
                          toggleGigStatus(g.id, g.status === 'published' ? 'paused' : 'published')
                        }
                        className="px-2.5 py-1 text-[11px] font-semibold rounded bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700"
                      >
                        {g.status === 'published' ? 'Pause' : 'Publish'}
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* ==================================================== */}
      {/* 6. USER MANAGEMENT TAB */}
      {/* ==================================================== */}
      {activeTab === 'users' && (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-sm">
          <h3 className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider mb-4">
            Registered Users ({users.length})
          </h3>
          <div className="overflow-x-auto">
            <table className="w-full text-xs text-left">
              <thead className="bg-slate-50 dark:bg-slate-800 text-slate-500 font-semibold uppercase text-[10px]">
                <tr>
                  <th className="p-3">User</th>
                  <th className="p-3">Username</th>
                  <th className="p-3">Email</th>
                  <th className="p-3">Role</th>
                  <th className="p-3">Balance</th>
                  <th className="p-3">Completed Orders</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {users.map((u) => (
                  <tr key={u.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/50">
                    <td className="p-3 font-semibold text-slate-800 dark:text-slate-200 flex items-center gap-2">
                      <img src={u.avatar} alt="" className="w-6 h-6 rounded-full object-cover" />
                      <span>{u.name}</span>
                    </td>
                    <td className="p-3 font-mono text-slate-600 dark:text-slate-400">@{u.username}</td>
                    <td className="p-3 text-slate-500">{u.email}</td>
                    <td className="p-3">
                      <span className="capitalize px-2 py-0.5 rounded font-bold text-[10px] bg-sky-100 dark:bg-sky-950 text-sky-800 dark:text-sky-300">
                        {u.role}
                      </span>
                    </td>
                    <td className="p-3 font-bold text-emerald-600 dark:text-emerald-400">
                      ৳{u.balance || 0}
                    </td>
                    <td className="p-3 text-slate-400">{u.completedOrdersCount || 0}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* ==================================================== */}
      {/* 7. EMAIL SETTINGS TAB */}
      {/* ==================================================== */}
      {activeTab === 'email' && (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-sm space-y-4">
          <h3 className="text-sm font-bold text-slate-900 dark:text-white uppercase tracking-wider flex items-center gap-2">
            <Mail className="w-4 h-4 text-sky-500" />
            <span>Email Notification System (InfinityFree Config)</span>
          </h3>
          <p className="text-xs text-slate-500">
            Official admin recipient: <span className="font-mono font-bold text-slate-800 dark:text-slate-200">{settings.adminAlertEmail}</span>.
            Because PHP mail() is restricted on InfinityFree shared hosting, standard external SMTP (e.g. Gmail SMTP, SendGrid, Brevo) is pre-configured in the deployment scripts.
          </p>

          <div className="p-4 bg-slate-50 dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700 text-xs font-mono space-y-2">
            <div className="text-slate-400">// Sample InfinityFree SMTP Integration in functions.php:</div>
            <div>define('SMTP_HOST', 'smtp.gmail.com');</div>
            <div>define('SMTP_PORT', 587);</div>
            <div>define('SMTP_USER', '{settings.adminAlertEmail}');</div>
            <div>define('ADMIN_NOTIFICATION_EMAIL', '{settings.adminAlertEmail}');</div>
          </div>
        </div>
      )}

      {/* ==================================================== */}
      {/* 8. AUDIT LOGS TAB */}
      {/* ==================================================== */}
      {activeTab === 'audit' && (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-sm">
          <h3 className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider mb-4">
            Administrator Action Audit Logs ({auditLogs.length})
          </h3>
          <div className="overflow-x-auto">
            <table className="w-full text-xs text-left">
              <thead className="bg-slate-50 dark:bg-slate-800 text-slate-500 font-semibold uppercase text-[10px]">
                <tr>
                  <th className="p-3">Timestamp</th>
                  <th className="p-3">Admin</th>
                  <th className="p-3">Action</th>
                  <th className="p-3">Target</th>
                  <th className="p-3">Details</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800 font-mono text-[11px]">
                {auditLogs.map((log) => (
                  <tr key={log.id}>
                    <td className="p-3 text-slate-400">
                      {new Date(log.createdAt).toLocaleString()}
                    </td>
                    <td className="p-3 font-bold text-slate-800 dark:text-slate-200">
                      @{log.adminUsername}
                    </td>
                    <td className="p-3 text-sky-600 dark:text-sky-400 font-bold">
                      {log.action}
                    </td>
                    <td className="p-3 text-slate-500">{log.targetType}:{log.targetId}</td>
                    <td className="p-3 text-slate-700 dark:text-slate-300 font-sans">
                      {log.details}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* ----------------- CHANGE ADMIN PASSWORD MODAL ----------------- */}
      {showPasswordChangeModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-sm animate-in fade-in">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 w-full max-w-md shadow-2xl">
            <h3 className="text-base font-bold text-slate-900 dark:text-white mb-2 flex items-center gap-2">
              <Lock className="w-4 h-4 text-amber-500" />
              <span>Change Initial Admin Password</span>
            </h3>
            <p className="text-xs text-slate-500 mb-4">
              Enter your current setup password (`masud#1234567`) and create a secure new password.
            </p>

            {passwordMsg.text && (
              <div
                className={`mb-4 p-2.5 rounded-lg text-xs font-semibold ${
                  passwordMsg.isError
                    ? 'bg-rose-50 text-rose-700 dark:bg-rose-950/60 dark:text-rose-300'
                    : 'bg-emerald-50 text-emerald-700 dark:bg-emerald-950/60 dark:text-emerald-300'
                }`}
              >
                {passwordMsg.text}
              </div>
            )}

            <form onSubmit={handlePasswordChangeSubmit} className="space-y-4 text-xs">
              <div>
                <label className="block font-bold mb-1">Current Password *</label>
                <input
                  type="password"
                  required
                  value={oldPassword}
                  onChange={(e) => setOldPassword(e.target.value)}
                  placeholder="masud#1234567"
                  className="w-full p-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg"
                />
              </div>

              <div>
                <label className="block font-bold mb-1">New Secure Password *</label>
                <input
                  type="password"
                  required
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                  placeholder="At least 6 characters"
                  className="w-full p-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowPasswordChangeModal(false)}
                  className="px-4 py-2 text-slate-500 font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-amber-600 hover:bg-amber-700 text-white rounded-lg font-bold"
                >
                  Update Password
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ----------------- REJECT PAYMENT REASON MODAL ----------------- */}
      {rejectingOrderId && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-sm animate-in fade-in">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 w-full max-w-md shadow-2xl">
            <h3 className="text-base font-bold text-rose-600 mb-2">Reject Payment Submission</h3>
            <p className="text-xs text-slate-500 mb-4">
              Enter the specific reason. The buyer will receive a notification to correct their TrxID.
            </p>

            <form
              onSubmit={(e) => {
                e.preventDefault();
                if (!rejectReason.trim()) return;
                rejectOrderPayment(rejectingOrderId, rejectReason.trim());
                setRejectingOrderId(null);
              }}
              className="space-y-4 text-xs"
            >
              <textarea
                required
                rows={3}
                value={rejectReason}
                onChange={(e) => setRejectReason(e.target.value)}
                placeholder="No received amount matching ৳2100 in bKash statement from this phone number."
                className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl"
              />
              <div className="flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setRejectingOrderId(null)}
                  className="px-4 py-2 text-slate-500 font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-rose-600 hover:bg-rose-700 text-white rounded-lg font-bold"
                >
                  Confirm Rejection
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
