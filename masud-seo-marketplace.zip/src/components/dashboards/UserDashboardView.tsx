import React, { useState } from 'react';
import {
  AlertCircle,
  CheckCircle2,
  Clock,
  DollarSign,
  Edit3,
  Layers,
  Pause,
  Play,
  PlusCircle,
  RotateCcw,
  ShieldCheck,
  ShoppingBag,
  Star,
  Trash2,
  TrendingUp,
  User,
  Wallet,
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { useMarketplace } from '../../context/MarketplaceContext';
import { useLanguage } from '../../i18n/LanguageContext';
import { Gig, Order } from '../../types';

interface UserDashboardViewProps {
  onOpenCreateGig: () => void;
  onEditGig: (gig: Gig) => void;
  onViewOrder: (order: Order) => void;
  onBrowseServices: () => void;
}

export const UserDashboardView: React.FC<UserDashboardViewProps> = ({
  onOpenCreateGig,
  onEditGig,
  onViewOrder,
  onBrowseServices,
}) => {
  const { currentUser, updateProfile, switchUserRole, isSeller } = useAuth();
  const { gigs, orders, toggleGigStatus, deleteGig } = useMarketplace();
  const { language, formatPrice, t } = useLanguage();

  const [activeTab, setActiveTab] = useState<'orders' | 'gigs' | 'profile'>('orders');

  // Profile edit state
  const [name, setName] = useState(currentUser?.name || '');
  const [bio, setBio] = useState(currentUser?.bio || '');
  const [phone, setPhone] = useState(currentUser?.phone || '');
  const [profileSavedToast, setProfileSavedToast] = useState(false);

  if (!currentUser) return null;

  // Filtered gigs & orders
  const myGigs = gigs.filter((g) => g.sellerId === currentUser.id && g.status !== 'archived');
  const myBuyerOrders = orders.filter((o) => o.buyerId === currentUser.id);
  const mySellerOrders = orders.filter((o) => o.sellerId === currentUser.id);

  const activeBuyerOrders = myBuyerOrders.filter(
    (o) => o.status !== 'completed' && o.status !== 'cancelled' && o.status !== 'refunded'
  );
  const activeSellerOrders = mySellerOrders.filter(
    (o) => o.status !== 'completed' && o.status !== 'cancelled' && o.status !== 'refunded'
  );

  const totalSpentBDT = myBuyerOrders.reduce((sum, o) => sum + o.totalAmountBDT, 0);
  const totalSellerEarningsBDT = mySellerOrders
    .filter((o) => o.status === 'completed')
    .reduce((sum, o) => sum + o.sellerNetBDT, 0);
  const escrowSellerEarningsBDT = mySellerOrders
    .filter((o) => o.status === 'in_progress' || o.status === 'work_submitted' || o.status === 'payment_confirmed')
    .reduce((sum, o) => sum + o.sellerNetBDT, 0);

  const handleProfileSave = (e: React.FormEvent) => {
    e.preventDefault();
    updateProfile({ name, bio, phone });
    setProfileSavedToast(true);
    setTimeout(() => setProfileSavedToast(false), 2000);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 animate-in fade-in">
      {/* Welcome & Role Switcher Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 p-6 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-sm mb-8">
        <div className="flex items-center gap-4">
          <img
            src={currentUser.avatar}
            alt={currentUser.name}
            className="w-16 h-16 rounded-full object-cover border-2 border-sky-500 shadow-sm"
          />
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-xl font-bold text-slate-900 dark:text-white">
                {currentUser.name}
              </h1>
              <span className="capitalize px-2 py-0.5 rounded text-[10px] font-extrabold uppercase tracking-wider bg-sky-100 dark:bg-sky-950 text-sky-700 dark:text-sky-300">
                {currentUser.role}
              </span>
            </div>
            <p className="text-xs text-slate-500 mt-0.5">
              @{currentUser.username} · Member since {new Date(currentUser.createdAt).toLocaleDateString()}
            </p>
          </div>
        </div>

        {/* Quick Role switch for testing */}
        <div className="flex items-center gap-2">
          <span className="text-xs text-slate-500 hidden sm:inline">Role:</span>
          <button
            onClick={() => switchUserRole('buyer')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition ${
              currentUser.role === 'buyer'
                ? 'bg-sky-600 text-white shadow-sm'
                : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200'
            }`}
          >
            🛒 {t('roleBuyer')}
          </button>
          <button
            onClick={() => switchUserRole('seller')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition ${
              currentUser.role === 'seller'
                ? 'bg-emerald-600 text-white shadow-sm'
                : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200'
            }`}
          >
            💼 {t('roleSeller')}
          </button>
        </div>
      </div>

      {/* Metric Cards */}
      {currentUser.role === 'seller' ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          <div className="p-4 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-sm">
            <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">
              {t('totalEarnings')}
            </span>
            <div className="text-2xl font-black text-emerald-600 dark:text-emerald-400 mt-1">
              ৳{totalSellerEarningsBDT.toLocaleString('en-IN')}
            </div>
            <span className="text-[10px] text-slate-400 mt-0.5 block">Net completed orders</span>
          </div>

          <div className="p-4 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-sm">
            <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">
              {t('pendingEarnings')} (Escrow)
            </span>
            <div className="text-2xl font-black text-sky-600 dark:text-sky-400 mt-1">
              ৳{escrowSellerEarningsBDT.toLocaleString('en-IN')}
            </div>
            <span className="text-[10px] text-slate-400 mt-0.5 block">Held safely until delivery</span>
          </div>

          <div className="p-4 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-sm">
            <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">
              {t('activeOrders')}
            </span>
            <div className="text-2xl font-black text-amber-500 mt-1">
              {activeSellerOrders.length}
            </div>
            <span className="text-[10px] text-slate-400 mt-0.5 block">Awaiting completion</span>
          </div>

          <div className="p-4 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-sm">
            <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">
              Active Gigs
            </span>
            <div className="text-2xl font-black text-slate-900 dark:text-white mt-1">
              {myGigs.length}
            </div>
            <span className="text-[10px] text-slate-400 mt-0.5 block">Published services</span>
          </div>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-8">
          <div className="p-4 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-sm">
            <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">
              {t('totalSpent')}
            </span>
            <div className="text-2xl font-black text-sky-600 dark:text-sky-400 mt-1">
              ৳{totalSpentBDT.toLocaleString('en-IN')}
            </div>
            <span className="text-[10px] text-slate-400 mt-0.5 block">Across all orders</span>
          </div>

          <div className="p-4 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-sm">
            <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">
              {t('activeOrders')}
            </span>
            <div className="text-2xl font-black text-amber-500 mt-1">
              {activeBuyerOrders.length}
            </div>
            <span className="text-[10px] text-slate-400 mt-0.5 block">In progress or review</span>
          </div>

          <div className="p-4 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-sm">
            <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">
              {t('completedOrdersStat')}
            </span>
            <div className="text-2xl font-black text-emerald-600 dark:text-emerald-400 mt-1">
              {myBuyerOrders.filter((o) => o.status === 'completed').length}
            </div>
            <span className="text-[10px] text-slate-400 mt-0.5 block">Verified SEO deliveries</span>
          </div>
        </div>
      )}

      {/* Tabs */}
      <div className="flex items-center gap-2 border-b border-slate-200 dark:border-slate-800 mb-6">
        <button
          onClick={() => setActiveTab('orders')}
          className={`flex items-center gap-1.5 px-4 py-2.5 text-xs font-bold border-b-2 transition ${
            activeTab === 'orders'
              ? 'border-sky-600 text-sky-600 dark:text-sky-400'
              : 'border-transparent text-slate-600 dark:text-slate-400 hover:text-slate-900'
          }`}
        >
          <ShoppingBag className="w-4 h-4" />
          <span>{t('myOrders')}</span>
        </button>

        {currentUser.role === 'seller' && (
          <button
            onClick={() => setActiveTab('gigs')}
            className={`flex items-center gap-1.5 px-4 py-2.5 text-xs font-bold border-b-2 transition ${
              activeTab === 'gigs'
                ? 'border-sky-600 text-sky-600 dark:text-sky-400'
                : 'border-transparent text-slate-600 dark:text-slate-400 hover:text-slate-900'
            }`}
          >
            <Layers className="w-4 h-4" />
            <span>{t('manageGigs')} ({myGigs.length})</span>
          </button>
        )}

        <button
          onClick={() => setActiveTab('profile')}
          className={`flex items-center gap-1.5 px-4 py-2.5 text-xs font-bold border-b-2 transition ${
            activeTab === 'profile'
              ? 'border-sky-600 text-sky-600 dark:text-sky-400'
              : 'border-transparent text-slate-600 dark:text-slate-400 hover:text-slate-900'
          }`}
        >
          <User className="w-4 h-4" />
          <span>{t('editProfile')}</span>
        </button>

        {currentUser.role === 'seller' && (
          <button
            onClick={onOpenCreateGig}
            className="ml-auto flex items-center gap-1 px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-bold shadow-sm transition"
          >
            <PlusCircle className="w-3.5 h-3.5" />
            <span>{t('createGig')}</span>
          </button>
        )}
      </div>

      {/* 1. ORDERS TAB */}
      {activeTab === 'orders' && (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-sm">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider">
              {currentUser.role === 'seller' ? 'Client Orders' : 'My Purchased Orders'}
            </h3>
            {currentUser.role === 'buyer' && (
              <button
                onClick={onBrowseServices}
                className="text-xs font-bold text-sky-600 hover:underline"
              >
                + Browse More Services
              </button>
            )}
          </div>

          {(currentUser.role === 'seller' ? mySellerOrders : myBuyerOrders).length > 0 ? (
            <div className="overflow-x-auto">
              <table className="w-full text-xs text-left">
                <thead className="bg-slate-50 dark:bg-slate-800 text-slate-500 font-semibold uppercase text-[10px]">
                  <tr>
                    <th className="p-3">Order Reference</th>
                    <th className="p-3">Service</th>
                    <th className="p-3">{currentUser.role === 'seller' ? 'Buyer' : 'Seller'}</th>
                    <th className="p-3">Amount</th>
                    <th className="p-3">Status</th>
                    <th className="p-3">Due Date</th>
                    <th className="p-3 text-right">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                  {(currentUser.role === 'seller' ? mySellerOrders : myBuyerOrders).map((ord) => (
                    <tr key={ord.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/50">
                      <td className="p-3 font-mono font-bold text-slate-900 dark:text-white">
                        {ord.orderNumber}
                      </td>
                      <td className="p-3 font-medium text-slate-700 dark:text-slate-300 max-w-xs truncate">
                        {ord.gigTitle}
                      </td>
                      <td className="p-3 text-slate-600 dark:text-slate-400">
                        {currentUser.role === 'seller' ? ord.buyerName : ord.sellerName}
                      </td>
                      <td className="p-3 font-bold text-slate-900 dark:text-white">
                        ৳{ord.totalAmountBDT}
                      </td>
                      <td className="p-3">
                        <span className="capitalize px-2 py-0.5 rounded font-bold text-[10px] bg-sky-100 dark:bg-sky-950 text-sky-800 dark:text-sky-300">
                          {ord.status.replace('_', ' ')}
                        </span>
                      </td>
                      <td className="p-3 text-slate-400 text-[11px]">
                        {new Date(ord.dueDate).toLocaleDateString()}
                      </td>
                      <td className="p-3 text-right">
                        <button
                          onClick={() => onViewOrder(ord)}
                          className="px-3 py-1 bg-sky-600 hover:bg-sky-700 text-white rounded text-xs font-semibold shadow-sm"
                        >
                          View Details →
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <div className="py-12 text-center text-xs text-slate-400">
              <p>No orders recorded yet.</p>
              {currentUser.role === 'buyer' && (
                <button
                  onClick={onBrowseServices}
                  className="mt-3 px-4 py-2 bg-sky-600 text-white font-bold rounded-xl shadow-sm"
                >
                  Explore Top SEO Gigs Now
                </button>
              )}
            </div>
          )}
        </div>
      )}

      {/* 2. GIGS TAB (SELLER ONLY) */}
      {activeTab === 'gigs' && currentUser.role === 'seller' && (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-sm">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider">
              My Gigs Portfolio ({myGigs.length})
            </h3>
            <button
              onClick={onOpenCreateGig}
              className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-bold shadow-sm"
            >
              + {t('createGig')}
            </button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-xs text-left">
              <thead className="bg-slate-50 dark:bg-slate-800 text-slate-500 font-semibold uppercase text-[10px]">
                <tr>
                  <th className="p-3">Cover</th>
                  <th className="p-3">Title</th>
                  <th className="p-3">Price</th>
                  <th className="p-3">Sales</th>
                  <th className="p-3">Rating</th>
                  <th className="p-3">Status</th>
                  <th className="p-3 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {myGigs.map((g) => (
                  <tr key={g.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/50">
                    <td className="p-3">
                      <img src={g.mainImage} alt="" className="w-12 h-8 rounded object-cover" />
                    </td>
                    <td className="p-3 font-semibold text-slate-800 dark:text-slate-200 max-w-sm truncate">
                      {g.title}
                    </td>
                    <td className="p-3 font-bold text-slate-900 dark:text-white">৳{g.price}</td>
                    <td className="p-3 text-slate-500">{g.salesCount} sold</td>
                    <td className="p-3 text-amber-500 font-bold">★ {g.rating.toFixed(1)}</td>
                    <td className="p-3">
                      <span className="capitalize px-2 py-0.5 rounded font-bold text-[10px] bg-slate-100 dark:bg-slate-800">
                        {g.status}
                      </span>
                    </td>
                    <td className="p-3 text-right">
                      <div className="flex items-center justify-end gap-1.5">
                        <button
                          onClick={() => onEditGig(g)}
                          className="p-1.5 rounded hover:bg-slate-100 dark:hover:bg-slate-800 text-sky-600"
                          title="Edit Gig"
                        >
                          <Edit3 className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() =>
                            toggleGigStatus(g.id, g.status === 'published' ? 'paused' : 'published')
                          }
                          className="p-1.5 rounded hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-600"
                          title={g.status === 'published' ? 'Pause' : 'Activate'}
                        >
                          {g.status === 'published' ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5 text-emerald-600" />}
                        </button>
                        <button
                          onClick={() => deleteGig(g.id)}
                          className="p-1.5 rounded hover:bg-slate-100 dark:hover:bg-slate-800 text-rose-500"
                          title="Archive"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* 3. PROFILE SETTINGS TAB */}
      {activeTab === 'profile' && (
        <form onSubmit={handleProfileSave} className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-sm space-y-4 max-w-xl">
          <h3 className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider mb-2">
            {t('editProfile')}
          </h3>

          <div>
            <label className="block text-xs font-bold mb-1">Full Name *</label>
            <input
              type="text"
              required
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full p-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-xs"
            />
          </div>

          <div>
            <label className="block text-xs font-bold mb-1">Phone Number</label>
            <input
              type="text"
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              className="w-full p-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-xs font-mono"
            />
          </div>

          <div>
            <label className="block text-xs font-bold mb-1">Bio / Expertise</label>
            <textarea
              rows={4}
              value={bio}
              onChange={(e) => setBio(e.target.value)}
              placeholder="Tell buyers about your SEO experience, rankings achieved, and core competencies..."
              className="w-full p-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-xs"
            />
          </div>

          <div className="flex items-center justify-between pt-2">
            {profileSavedToast && (
              <span className="text-xs font-bold text-emerald-600 flex items-center gap-1">
                <CheckCircle2 className="w-4 h-4" /> Profile updated successfully!
              </span>
            )}
            <button
              type="submit"
              className="ml-auto px-5 py-2 bg-sky-600 hover:bg-sky-700 text-white rounded-xl text-xs font-bold shadow-md"
            >
              Save Profile
            </button>
          </div>
        </form>
      )}
    </div>
  );
};
