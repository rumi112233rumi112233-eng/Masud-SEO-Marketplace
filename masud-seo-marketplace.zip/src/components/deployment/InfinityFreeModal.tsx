import React, { useState } from 'react';
import {
  Check,
  Copy,
  Database,
  Download,
  FileCode,
  FileText,
  Server,
  X,
} from 'lucide-react';
import {
  INFINITYFREE_CONFIG_PHP,
  INFINITYFREE_DB_PHP,
  INFINITYFREE_DEPLOY_GUIDE_MD,
  INFINITYFREE_HTACCESS,
  INFINITYFREE_SCHEMA_SQL,
} from '../../data/infinityfreeExport';
import { useLanguage } from '../../i18n/LanguageContext';

interface InfinityFreeModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const InfinityFreeModal: React.FC<InfinityFreeModalProps> = ({ isOpen, onClose }) => {
  const { language } = useLanguage();
  const [activeTab, setActiveTab] = useState<'guide' | 'sql' | 'config' | 'htaccess'>('guide');
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  const currentContent =
    activeTab === 'guide'
      ? INFINITYFREE_DEPLOY_GUIDE_MD
      : activeTab === 'sql'
      ? INFINITYFREE_SCHEMA_SQL
      : activeTab === 'config'
      ? INFINITYFREE_CONFIG_PHP
      : INFINITYFREE_HTACCESS;

  const handleCopy = () => {
    navigator.clipboard.writeText(currentContent);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownload = () => {
    const filename =
      activeTab === 'guide'
        ? 'INFINITYFREE_DEPLOYMENT_GUIDE.md'
        : activeTab === 'sql'
        ? 'masud_seo_schema.sql'
        : activeTab === 'config'
        ? 'config.php'
        : '.htaccess';

    const blob = new Blob([currentContent], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = filename;
    link.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-in fade-in">
      <div className="relative w-full max-w-4xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-2xl p-6 flex flex-col max-h-[90vh]">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-1 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-2 mb-2">
          <Server className="w-5 h-5 text-indigo-500" />
          <h2 className="text-lg font-bold text-slate-900 dark:text-white">
            InfinityFree PHP & MySQL Production Deployment Pack
          </h2>
        </div>
        <p className="text-xs text-slate-500 mb-4">
          Everything required to deploy www.masudseoservice.com on InfinityFree Shared Hosting (Apache + PHP 8 + MySQL/MariaDB).
        </p>

        {/* Tab selection */}
        <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-800 pb-2 mb-3">
          <div className="flex items-center gap-1">
            <button
              onClick={() => setActiveTab('guide')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1.5 ${
                activeTab === 'guide'
                  ? 'bg-indigo-600 text-white'
                  : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
              }`}
            >
              <FileText className="w-3.5 h-3.5" />
              <span>Deployment Guide</span>
            </button>
            <button
              onClick={() => setActiveTab('sql')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1.5 ${
                activeTab === 'sql'
                  ? 'bg-indigo-600 text-white'
                  : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
              }`}
            >
              <Database className="w-3.5 h-3.5" />
              <span>schema.sql (26 Tables)</span>
            </button>
            <button
              onClick={() => setActiveTab('config')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1.5 ${
                activeTab === 'config'
                  ? 'bg-indigo-600 text-white'
                  : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
              }`}
            >
              <FileCode className="w-3.5 h-3.5" />
              <span>config.php</span>
            </button>
            <button
              onClick={() => setActiveTab('htaccess')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1.5 ${
                activeTab === 'htaccess'
                  ? 'bg-indigo-600 text-white'
                  : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
              }`}
            >
              <span>.htaccess</span>
            </button>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleCopy}
              className="flex items-center gap-1 px-3 py-1 bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 rounded-lg text-xs font-medium hover:bg-slate-200 dark:hover:bg-slate-700 transition"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copied ? 'Copied' : 'Copy'}</span>
            </button>
            <button
              onClick={handleDownload}
              className="flex items-center gap-1 px-3 py-1 bg-sky-600 hover:bg-sky-700 text-white rounded-lg text-xs font-bold transition shadow-sm"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Download File</span>
            </button>
          </div>
        </div>

        {/* Code View Body */}
        <div className="flex-1 overflow-y-auto bg-slate-950 text-slate-200 p-4 rounded-xl font-mono text-xs leading-relaxed border border-slate-800">
          <pre className="whitespace-pre-wrap">{currentContent}</pre>
        </div>
      </div>
    </div>
  );
};
