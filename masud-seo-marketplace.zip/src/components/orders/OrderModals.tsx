import React, { useState } from 'react';
import {
  AlertCircle,
  CheckCircle2,
  Clock,
  Copy,
  DollarSign,
  FileText,
  Image,
  Shield,
  Upload,
  X,
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { useMarketplace } from '../../context/MarketplaceContext';
import { useLanguage } from '../../i18n/LanguageContext';
import { Gig, GigExtra, Order, PaymentMethod } from '../../types';

interface OrderCheckoutModalProps {
  gig: Gig;
  selectedExtras: GigExtra[];
  isOpen: boolean;
  onClose: () => void;
  onProceedToPayment: (order: Order) => void;
}

export const OrderCheckoutModal: React.FC<OrderCheckoutModalProps> = ({
  gig,
  selectedExtras,
  isOpen,
  onClose,
  onProceedToPayment,
}) => {
  const { language, formatPrice, t } = useLanguage();
  const { createOrder } = useMarketplace();
  const { currentUser } = useAuth();

  const [requirements, setRequirements] = useState('');
  const [error, setError] = useState('');

  if (!isOpen) return null;

  const extrasSum = selectedExtras.reduce((sum, e) => sum + e.price, 0);
  const totalAmountBDT = gig.price + extrasSum;
  const totalDays = gig.deliveryDays + selectedExtras.reduce((sum, e) => sum + e.deliveryDays, 0);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!requirements.trim()) {
      setError(
        language === 'bn'
          ? 'অনুগ্রহ করে ওয়েবসাইটের লিংক ও প্রয়োজনীয় নির্দেশনা বিস্তারিত লিখুন।'
          : 'Please provide your website URL and instructions for the seller.'
      );
      return;
    }

    try {
      const newOrder = createOrder(gig.id, selectedExtras, requirements.trim());
      onProceedToPayment(newOrder);
      onClose();
    } catch (err: any) {
      setError(err.message || 'Failed to initialize order');
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-sm animate-in fade-in">
      <div className="relative w-full max-w-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-2xl p-6 overflow-hidden">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-1 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800"
        >
          <X className="w-5 h-5" />
        </button>

        <h3 className="text-lg font-bold text-slate-900 dark:text-white flex items-center gap-2">
          <FileText className="w-5 h-5 text-sky-500" />
          <span>{t('orderRequirementsTitle')}</span>
        </h3>

        {/* Order Summary snippet */}
        <div className="my-4 p-3 bg-slate-50 dark:bg-slate-800/60 rounded-xl border border-slate-200 dark:border-slate-700/60 flex items-center justify-between text-xs">
          <div className="flex-1 pr-3">
            <span className="font-semibold text-slate-800 dark:text-slate-200 block truncate">
              {language === 'bn' && gig.titleBn ? gig.titleBn : gig.title}
            </span>
            <span className="text-[11px] text-slate-400">
              {totalDays} days delivery · {selectedExtras.length} extras selected
            </span>
          </div>
          <div className="text-sm font-black text-sky-600 dark:text-sky-400 whitespace-nowrap">
            {formatPrice(totalAmountBDT)}
          </div>
        </div>

        {error && (
          <div className="mb-4 p-3 rounded-lg bg-rose-50 dark:bg-rose-950/50 border border-rose-200 dark:border-rose-800 text-rose-700 dark:text-rose-300 text-xs flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{error}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-xs font-bold text-slate-800 dark:text-slate-200 mb-1">
              {language === 'bn' ? 'কাজের রিকোয়ারমেন্টস ও নির্দেশনা *' : 'Work Requirements & Instructions *'}
            </label>
            <p className="text-[11px] text-slate-400 mb-2">{t('orderRequirementsHelp')}</p>
            <textarea
              rows={5}
              value={requirements}
              onChange={(e) => setRequirements(e.target.value)}
              placeholder={t('requirementsPlaceholder')}
              className="w-full p-3 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-800 dark:text-slate-100 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-sky-500 font-mono"
            />
          </div>

          <div className="flex items-center justify-between pt-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-semibold text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2.5 bg-sky-600 hover:bg-sky-700 text-white rounded-xl text-xs font-bold shadow-md transition"
            >
              {t('confirmOrderAndPay')} →
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

// ----------------------------------------------------
// PAYMENT MODAL (bKash, Nagad, Rocket Manual Payments)
// ----------------------------------------------------
interface PaymentModalProps {
  order: Order | null;
  isOpen: boolean;
  onClose: () => void;
  onSuccess: () => void;
}

export const PaymentModal: React.FC<PaymentModalProps> = ({
  order,
  isOpen,
  onClose,
  onSuccess,
}) => {
  const { language, formatPrice, t } = useLanguage();
  const { settings, submitOrderPayment } = useMarketplace();

  const [method, setMethod] = useState<PaymentMethod>('bkash');
  const [senderNumber, setSenderNumber] = useState('');
  const [transactionId, setTransactionId] = useState('');
  const [screenshotPreview, setScreenshotPreview] = useState<string | null>(null);
  const [copiedNumber, setCopiedNumber] = useState(false);
  const [error, setError] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  if (!isOpen || !order) return null;

  const currentAccountNumber =
    method === 'bkash'
      ? settings.bkashNumber
      : method === 'nagad'
      ? settings.nagadNumber
      : settings.rocketNumber;

  const handleCopyNumber = () => {
    navigator.clipboard.writeText(currentAccountNumber);
    setCopiedNumber(true);
    setTimeout(() => setCopiedNumber(false), 2000);
  };

  const handleScreenshotUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 5 * 1024 * 1024) {
        setError('Screenshot size must be under 5MB.');
        return;
      }
      const reader = new FileReader();
      reader.onload = () => {
        setScreenshotPreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handlePaymentSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!senderNumber.trim()) {
      setError(
        language === 'bn'
          ? 'অনুগ্রহ করে আপনার প্রেরক মোবাইল নম্বর লিখুন।'
          : 'Please enter your sender mobile number.'
      );
      return;
    }

    if (!transactionId.trim()) {
      setError(
        language === 'bn'
          ? 'অনুগ্রহ করে মোবাইল ব্যাংকিং ট্রানজেকশন আইডি (TrxID) লিখুন।'
          : 'Please enter your Transaction ID (TrxID).'
      );
      return;
    }

    setIsSubmitting(true);

    const result = submitOrderPayment(
      order.id,
      method,
      senderNumber.trim(),
      transactionId.trim(),
      order.totalAmountBDT,
      screenshotPreview || undefined
    );

    setIsSubmitting(false);

    if (result.success) {
      onSuccess();
      onClose();
    } else {
      setError(result.message);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/75 backdrop-blur-sm overflow-y-auto animate-in fade-in">
      <div className="relative w-full max-w-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-2xl p-6 my-8">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-1 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header */}
        <div className="flex items-center gap-2 mb-1">
          <Shield className="w-5 h-5 text-emerald-500" />
          <h3 className="text-base sm:text-lg font-bold text-slate-900 dark:text-white">
            {t('paymentInstructionsTitle')}
          </h3>
        </div>
        <p className="text-xs text-slate-500 mb-4">{t('paymentInstructionsSubtitle')}</p>

        {/* Order Reference Box */}
        <div className="bg-sky-50 dark:bg-sky-950/40 border border-sky-200 dark:border-sky-800 rounded-xl p-3 flex flex-wrap items-center justify-between text-xs gap-2 mb-5">
          <div>
            <span className="text-[10px] text-sky-800 dark:text-sky-300 font-bold uppercase tracking-wider block">
              {t('orderReference')}
            </span>
            <span className="font-mono font-bold text-slate-900 dark:text-white text-sm">
              {order.orderNumber}
            </span>
          </div>
          <div className="text-right">
            <span className="text-[10px] text-sky-800 dark:text-sky-300 font-bold uppercase tracking-wider block">
              {t('exactPayableAmount')}
            </span>
            <span className="text-base font-black text-sky-600 dark:text-sky-400">
              ৳{order.totalAmountBDT.toLocaleString('en-IN')} BDT
            </span>
          </div>
        </div>

        {/* Payment Method Selector Tabs */}
        <div className="grid grid-cols-3 gap-2 mb-4">
          <button
            type="button"
            onClick={() => setMethod('bkash')}
            className={`py-2 px-3 rounded-xl border text-xs font-bold transition flex flex-col items-center gap-1 ${
              method === 'bkash'
                ? 'border-pink-500 bg-pink-50 dark:bg-pink-950/30 text-pink-600 dark:text-pink-400 shadow-sm'
                : 'border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400 hover:border-slate-300'
            }`}
          >
            <span>bKash</span>
            <span className="text-[10px] font-normal">বিকাশ পার্সোনাল</span>
          </button>

          <button
            type="button"
            onClick={() => setMethod('nagad')}
            className={`py-2 px-3 rounded-xl border text-xs font-bold transition flex flex-col items-center gap-1 ${
              method === 'nagad'
                ? 'border-amber-500 bg-amber-50 dark:bg-amber-950/30 text-amber-600 dark:text-amber-400 shadow-sm'
                : 'border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400 hover:border-slate-300'
            }`}
          >
            <span>Nagad</span>
            <span className="text-[10px] font-normal">নগদ পার্সোনাল</span>
          </button>

          <button
            type="button"
            onClick={() => setMethod('rocket')}
            className={`py-2 px-3 rounded-xl border text-xs font-bold transition flex flex-col items-center gap-1 ${
              method === 'rocket'
                ? 'border-purple-500 bg-purple-50 dark:bg-purple-950/30 text-purple-600 dark:text-purple-400 shadow-sm'
                : 'border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400 hover:border-slate-300'
            }`}
          >
            <span>Rocket</span>
            <span className="text-[10px] font-normal">রকেট পার্সোনাল</span>
          </button>
        </div>

        {/* Account Number Box with One-Click Copy */}
        <div className="p-3.5 bg-slate-100 dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700 flex items-center justify-between mb-5">
          <div>
            <div className="text-[10px] font-semibold text-slate-500 uppercase">
              {method.toUpperCase()} {t('accountNumber')}:
            </div>
            <div className="text-base font-mono font-black text-slate-900 dark:text-white tracking-wider">
              {currentAccountNumber}
            </div>
          </div>
          <button
            type="button"
            onClick={handleCopyNumber}
            className="flex items-center gap-1 px-3 py-1.5 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-lg text-xs font-medium text-slate-700 dark:text-slate-200 hover:bg-slate-50 transition"
          >
            {copiedNumber ? <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500" /> : <Copy className="w-3.5 h-3.5" />}
            <span>{copiedNumber ? t('copied') : t('copyNumber')}</span>
          </button>
        </div>

        {error && (
          <div className="mb-4 p-3 rounded-lg bg-rose-50 dark:bg-rose-950/50 border border-rose-200 dark:border-rose-800 text-rose-700 dark:text-rose-300 text-xs flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{error}</span>
          </div>
        )}

        {/* Submission Form */}
        <form onSubmit={handlePaymentSubmit} className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                {t('senderNumberLabel')} *
              </label>
              <input
                type="text"
                required
                value={senderNumber}
                onChange={(e) => setSenderNumber(e.target.value)}
                placeholder={t('senderNumberPlaceholder')}
                className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-xs text-slate-800 dark:text-slate-100 placeholder-slate-400 focus:outline-none focus:ring-1 focus:ring-sky-500 font-mono"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                {t('transactionIdLabel')} *
              </label>
              <input
                type="text"
                required
                value={transactionId}
                onChange={(e) => setTransactionId(e.target.value.toUpperCase())}
                placeholder={t('transactionIdPlaceholder')}
                className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-xs text-slate-800 dark:text-slate-100 placeholder-slate-400 focus:outline-none focus:ring-1 focus:ring-sky-500 font-mono uppercase"
              />
            </div>
          </div>

          {/* Screenshot Upload from Computer */}
          <div>
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
              {t('uploadScreenshot')}
            </label>
            <div className="flex items-center gap-3">
              <label className="flex items-center gap-2 px-3 py-2 bg-slate-100 dark:bg-slate-800 border border-dashed border-slate-300 dark:border-slate-600 rounded-lg text-xs text-slate-700 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700 cursor-pointer transition">
                <Upload className="w-3.5 h-3.5" />
                <span>{language === 'bn' ? 'ফাইল সিলেক্ট করুন' : 'Browse Screenshot File'}</span>
                <input
                  type="file"
                  accept="image/png, image/jpeg, image/webp"
                  onChange={handleScreenshotUpload}
                  className="hidden"
                />
              </label>
              {screenshotPreview && (
                <div className="flex items-center gap-1.5 text-xs text-emerald-600 dark:text-emerald-400 font-medium">
                  <CheckCircle2 className="w-4 h-4" />
                  <span>{language === 'bn' ? 'স্ক্রিনশট সিলেক্ট হয়েছে' : 'Image attached'}</span>
                </div>
              )}
            </div>
            {screenshotPreview && (
              <div className="mt-2 w-32 h-20 rounded-lg overflow-hidden border border-slate-200 dark:border-slate-700">
                <img src={screenshotPreview} alt="Proof" className="w-full h-full object-cover" />
              </div>
            )}
          </div>

          {/* Escrow & Verification Note */}
          <div className="p-3 bg-amber-50 dark:bg-amber-950/30 rounded-xl border border-amber-200 dark:border-amber-800/60 text-[11px] text-amber-800 dark:text-amber-300 leading-snug">
            ⚠️ {t('paymentUnderReviewNotice')}
          </div>

          <div className="flex items-center justify-between pt-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-semibold text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isSubmitting}
              className="px-5 py-2.5 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white rounded-xl text-xs font-bold shadow-md transition disabled:opacity-50"
            >
              {isSubmitting ? 'Verifying...' : t('submitPaymentProof')}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
