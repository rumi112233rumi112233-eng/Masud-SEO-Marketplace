import React, { useState } from 'react';
import {
  AlertTriangle,
  ArrowLeft,
  CheckCircle2,
  Clock,
  Download,
  FileCheck,
  FileText,
  MessageSquare,
  RefreshCw,
  ShieldAlert,
  ShieldCheck,
  Star,
  Upload,
  XCircle,
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { useMarketplace } from '../../context/MarketplaceContext';
import { useLanguage } from '../../i18n/LanguageContext';
import { Order, OrderStatus } from '../../types';

interface OrderDetailsViewProps {
  order: Order;
  onBack: () => void;
  onOpenPaymentModal: (order: Order) => void;
  onOpenChat: (partnerId: string, orderId: string) => void;
}

export const OrderDetailsView: React.FC<OrderDetailsViewProps> = ({
  order,
  onBack,
  onOpenPaymentModal,
  onOpenChat,
}) => {
  const { currentUser, isAdmin } = useAuth();
  const {
    verifyOrderPayment,
    rejectOrderPayment,
    deliverOrderWork,
    requestOrderRevision,
    acceptOrderDelivery,
    submitReview,
    openDispute,
  } = useMarketplace();
  const { language, formatPrice, t } = useLanguage();

  // Modals inside details
  const [deliveryModalOpen, setDeliveryModalOpen] = useState(false);
  const [deliveryNotes, setDeliveryNotes] = useState('');
  const [deliveryFiles, setDeliveryFiles] = useState<{ name: string; url: string; size?: string }[]>([]);

  const [revisionModalOpen, setRevisionModalOpen] = useState(false);
  const [revisionNote, setRevisionNote] = useState('');

  const [reviewModalOpen, setReviewModalOpen] = useState(false);
  const [reviewRating, setReviewRating] = useState(5);
  const [reviewComment, setReviewComment] = useState('');
  const [reviewSuccess, setReviewSuccess] = useState('');

  const [disputeModalOpen, setDisputeModalOpen] = useState(false);
  const [disputeReason, setDisputeReason] = useState('Poor Quality / Requirements Not Met');
  const [disputeDetails, setDisputeDetails] = useState('');

  const [rejectPaymentModalOpen, setRejectPaymentModalOpen] = useState(false);
  const [rejectionReason, setRejectionReason] = useState('');

  const isBuyer = currentUser?.id === order.buyerId;
  const isSeller = currentUser?.id === order.sellerId;

  // Handle local computer delivery file attach simulation
  const handleDeliveryFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setDeliveryFiles([
        ...deliveryFiles,
        {
          name: file.name,
          url: URL.createObjectURL(file),
          size: `${(file.size / 1024).toFixed(1)} KB`,
        },
      ]);
    }
  };

  const handleDeliverSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!deliveryNotes.trim()) return;
    deliverOrderWork(order.id, deliveryNotes.trim(), deliveryFiles);
    setDeliveryModalOpen(false);
  };

  const handleRevisionSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!revisionNote.trim()) return;
    requestOrderRevision(order.id, revisionNote.trim());
    setRevisionModalOpen(false);
  };

  const handleReviewSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!reviewComment.trim()) return;
    const res = submitReview(order.id, reviewRating, reviewComment.trim());
    if (res.success) {
      setReviewSuccess(res.message);
      setTimeout(() => setReviewModalOpen(false), 1500);
    }
  };

  const handleDisputeSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!disputeDetails.trim()) return;
    openDispute(order.id, disputeReason, disputeDetails.trim(), 'refund');
    setDisputeModalOpen(false);
  };

  const getStatusBadge = (status: OrderStatus) => {
    const statusMap: Record<OrderStatus, { bg: string; text: string; icon: any }> = {
      awaiting_payment: { bg: 'bg-amber-100 dark:bg-amber-950/60 text-amber-800 dark:text-amber-300', text: t('awaiting_payment'), icon: Clock },
      payment_submitted: { bg: 'bg-sky-100 dark:bg-sky-950/60 text-sky-800 dark:text-sky-300', text: t('payment_submitted'), icon: Clock },
      payment_under_review: { bg: 'bg-indigo-100 dark:bg-indigo-950/60 text-indigo-800 dark:text-indigo-300', text: t('payment_under_review'), icon: ShieldAlert },
      payment_confirmed: { bg: 'bg-emerald-100 dark:bg-emerald-950/60 text-emerald-800 dark:text-emerald-300', text: t('payment_confirmed'), icon: ShieldCheck },
      in_progress: { bg: 'bg-blue-100 dark:bg-blue-950/60 text-blue-800 dark:text-blue-300', text: t('in_progress'), icon: RefreshCw },
      work_submitted: { bg: 'bg-purple-100 dark:bg-purple-950/60 text-purple-800 dark:text-purple-300', text: t('work_submitted'), icon: FileCheck },
      revision_requested: { bg: 'bg-orange-100 dark:bg-orange-950/60 text-orange-800 dark:text-orange-300', text: t('revision_requested'), icon: RefreshCw },
      completed: { bg: 'bg-emerald-100 dark:bg-emerald-950/60 text-emerald-800 dark:text-emerald-300', text: t('completed'), icon: CheckCircle2 },
      cancelled: { bg: 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300', text: t('cancelled'), icon: XCircle },
      disputed: { bg: 'bg-rose-100 dark:bg-rose-950/60 text-rose-800 dark:text-rose-300', text: t('disputed'), icon: AlertTriangle },
      refunded: { bg: 'bg-cyan-100 dark:bg-cyan-950/60 text-cyan-800 dark:text-cyan-300', text: t('refunded'), icon: CheckCircle2 },
    };

    const cfg = statusMap[status] || statusMap.awaiting_payment;
    const Icon = cfg.icon;

    return (
      <span className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold ${cfg.bg}`}>
        <Icon className="w-3.5 h-3.5" />
        <span>{cfg.text}</span>
      </span>
    );
  };

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8 animate-in fade-in">
      {/* Top Back bar */}
      <div className="flex items-center justify-between mb-6">
        <button
          onClick={onBack}
          className="inline-flex items-center gap-1.5 text-xs font-semibold text-slate-600 dark:text-slate-400 hover:text-sky-600 dark:hover:text-sky-400"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>{language === 'bn' ? 'অর্ডার লিস্টে ফিরে যান' : 'Back to Orders'}</span>
        </button>

        <div className="flex items-center gap-2">
          {getStatusBadge(order.status)}
          <button
            onClick={() => onOpenChat(isBuyer ? order.sellerId : order.buyerId, order.id)}
            className="flex items-center gap-1 px-3 py-1.5 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-lg text-xs font-semibold text-slate-700 dark:text-slate-200 transition"
          >
            <MessageSquare className="w-3.5 h-3.5 text-sky-500" />
            <span>{isBuyer ? t('sellerInfo') : 'Buyer Chat'}</span>
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Main 2-column: Order details, deliverables, revisions, timeline */}
        <div className="lg:col-span-2 space-y-6">
          {/* Order Banner Card */}
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-sm">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-100 dark:border-slate-800">
              <div>
                <span className="text-[11px] font-mono text-slate-400 block">
                  ORDER REFERENCE
                </span>
                <h1 className="text-lg sm:text-xl font-extrabold text-slate-900 dark:text-white">
                  {order.orderNumber}
                </h1>
              </div>
              <div className="text-right">
                <span className="text-[11px] font-mono text-slate-400 block">TOTAL PAID</span>
                <span className="text-xl font-black text-sky-600 dark:text-sky-400">
                  {formatPrice(order.totalAmountBDT)}
                </span>
              </div>
            </div>

            {/* Service Item */}
            <div className="flex items-start gap-4 py-4">
              <img
                src={order.gigImage}
                alt=""
                className="w-20 h-14 rounded-lg object-cover border border-slate-200 dark:border-slate-700 shrink-0"
              />
              <div className="flex-1">
                <h3 className="text-xs sm:text-sm font-bold text-slate-900 dark:text-slate-100 leading-snug">
                  {order.gigTitle}
                </h3>
                <div className="flex items-center gap-2 text-[11px] text-slate-500 mt-1">
                  <span>Buyer: {order.buyerName}</span>
                  <span>·</span>
                  <span>Seller: {order.sellerName}</span>
                </div>
              </div>
            </div>

            {/* Deliverables / Status Action Box */}
            <div className="mt-4 pt-4 border-t border-slate-100 dark:border-slate-800">
              {/* Buyer needs to pay */}
              {order.status === 'awaiting_payment' && (
                <div className="p-4 bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800 rounded-xl flex flex-col sm:flex-row items-center justify-between gap-3">
                  <div>
                    <h4 className="text-xs font-bold text-amber-900 dark:text-amber-200">
                      Payment Required to Start Order
                    </h4>
                    <p className="text-[11px] text-amber-700 dark:text-amber-400 mt-0.5">
                      Send ৳{order.totalAmountBDT} to bKash (01784038383) or Nagad (01644858242) and submit your TrxID.
                    </p>
                  </div>
                  {isBuyer && (
                    <button
                      onClick={() => onOpenPaymentModal(order)}
                      className="px-4 py-2 bg-amber-600 hover:bg-amber-700 text-white rounded-lg text-xs font-bold whitespace-nowrap shadow-sm"
                    >
                      {t('submitPaymentProof')} →
                    </button>
                  )}
                </div>
              )}

              {/* Admin needs to verify payment */}
              {(order.status === 'payment_submitted' || order.status === 'payment_under_review') && (
                <div className="p-4 bg-sky-50 dark:bg-sky-950/40 border border-sky-200 dark:border-sky-800 rounded-xl space-y-3">
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <h4 className="text-xs font-bold text-sky-950 dark:text-sky-200 flex items-center gap-1.5">
                        <Clock className="w-4 h-4 text-sky-600" />
                        <span>Payment Verification in Progress</span>
                      </h4>
                      <p className="text-[11px] text-sky-800 dark:text-sky-300 mt-0.5">
                        Submitted: {order.paymentSubmission?.method.toUpperCase()} | TrxID:{' '}
                        <span className="font-mono font-bold text-slate-900 dark:text-white">
                          {order.paymentSubmission?.transactionId}
                        </span>{' '}
                        | Sender: {order.paymentSubmission?.senderNumber}
                      </p>
                    </div>
                  </div>

                  {/* Admin controls for instant verification */}
                  {isAdmin && (
                    <div className="flex items-center gap-2 pt-2 border-t border-sky-200 dark:border-sky-800">
                      <button
                        onClick={() => verifyOrderPayment(order.id, 'Verified in mobile banking wallet')}
                        className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-bold shadow-sm"
                      >
                        ✓ {t('actionVerify')}
                      </button>
                      <button
                        onClick={() => setRejectPaymentModalOpen(true)}
                        className="px-3 py-1.5 bg-rose-600 hover:bg-rose-700 text-white rounded-lg text-xs font-bold"
                      >
                        ✗ {t('actionReject')}
                      </button>
                    </div>
                  )}
                </div>
              )}

              {/* In Progress: Seller can deliver */}
              {(order.status === 'in_progress' || order.status === 'revision_requested') && isSeller && (
                <div className="p-4 bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 rounded-xl flex items-center justify-between gap-3">
                  <div>
                    <h4 className="text-xs font-bold text-emerald-900 dark:text-emerald-200">
                      Work In Progress
                    </h4>
                    <p className="text-[11px] text-emerald-700 dark:text-emerald-400">
                      Complete the requirements and deliver your report or backlink sheet to the buyer.
                    </p>
                  </div>
                  <button
                    onClick={() => setDeliveryModalOpen(true)}
                    className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-bold shadow-sm whitespace-nowrap"
                  >
                    {t('deliverWork')} 🚀
                  </button>
                </div>
              )}

              {/* Work Submitted: Buyer inspects & approves */}
              {order.status === 'work_submitted' && isBuyer && (
                <div className="p-4 bg-purple-50 dark:bg-purple-950/40 border border-purple-200 dark:border-purple-800 rounded-xl space-y-3">
                  <div>
                    <h4 className="text-xs font-bold text-purple-900 dark:text-purple-200">
                      Work Submitted by Seller!
                    </h4>
                    <p className="text-[11px] text-purple-700 dark:text-purple-400">
                      Please review the delivery report below. If satisfied, accept to complete the order and release escrow funds.
                    </p>
                  </div>
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => acceptOrderDelivery(order.id)}
                      className="px-4 py-2 bg-purple-600 hover:bg-purple-700 text-white rounded-lg text-xs font-bold shadow-sm"
                    >
                      ✓ {t('acceptDelivery')}
                    </button>
                    <button
                      onClick={() => setRevisionModalOpen(true)}
                      className="px-3.5 py-2 border border-purple-300 dark:border-purple-700 text-purple-700 dark:text-purple-300 rounded-lg text-xs font-semibold hover:bg-purple-100 dark:hover:bg-purple-900/50"
                    >
                      {t('requestRevision')}
                    </button>
                  </div>
                </div>
              )}

              {/* Completed: Buyer reviews */}
              {order.status === 'completed' && isBuyer && !order.isReviewed && (
                <div className="p-4 bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 rounded-xl flex items-center justify-between gap-3">
                  <div>
                    <h4 className="text-xs font-bold text-emerald-900 dark:text-emerald-200">
                      Order Successfully Completed!
                    </h4>
                    <p className="text-[11px] text-emerald-700 dark:text-emerald-400">
                      Share your experience to help other buyers on Masud SEO Marketplace.
                    </p>
                  </div>
                  <button
                    onClick={() => setReviewModalOpen(true)}
                    className="px-4 py-2 bg-amber-500 hover:bg-amber-600 text-slate-950 rounded-lg text-xs font-bold whitespace-nowrap shadow-sm"
                  >
                    ⭐ {t('rateAndReview')}
                  </button>
                </div>
              )}
            </div>
          </div>

          {/* Buyer Requirements */}
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-sm">
            <h3 className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider mb-2 flex items-center gap-1.5">
              <FileText className="w-4 h-4 text-sky-500" />
              <span>Buyer Order Requirements</span>
            </h3>
            <div className="p-4 bg-slate-50 dark:bg-slate-800 rounded-xl text-xs text-slate-700 dark:text-slate-300 font-mono whitespace-pre-wrap leading-relaxed">
              {order.requirements || 'No specific requirements given.'}
            </div>
          </div>

          {/* Delivered Work Records */}
          {order.deliveries && order.deliveries.length > 0 && (
            <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-sm space-y-4">
              <h3 className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider flex items-center gap-1.5">
                <FileCheck className="w-4 h-4 text-emerald-500" />
                <span>Work Deliveries & Reports ({order.deliveries.length})</span>
              </h3>

              {order.deliveries.map((del, i) => (
                <div key={del.id || i} className="p-4 bg-emerald-50/50 dark:bg-emerald-950/20 border border-emerald-200/80 dark:border-emerald-800/60 rounded-xl space-y-2">
                  <div className="flex items-center justify-between text-[11px] text-slate-400">
                    <span className="font-bold text-emerald-700 dark:text-emerald-400">
                      Delivery #{order.deliveries.length - i}
                    </span>
                    <span>{new Date(del.deliveredAt).toLocaleString()}</span>
                  </div>
                  <p className="text-xs text-slate-800 dark:text-slate-200 whitespace-pre-wrap">
                    {del.notes}
                  </p>

                  {del.workFiles && del.workFiles.length > 0 && (
                    <div className="mt-3 pt-2 border-t border-emerald-200/50 dark:border-emerald-800/40 space-y-1.5">
                      <span className="text-[10px] font-bold text-slate-500 uppercase">Attached Files:</span>
                      <div className="flex flex-wrap gap-2">
                        {del.workFiles.map((f, fi) => (
                          <a
                            key={fi}
                            href={f.url}
                            download={f.name}
                            className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-xs font-medium text-sky-600 dark:text-sky-400 hover:underline"
                          >
                            <Download className="w-3.5 h-3.5" />
                            <span>{f.name}</span>
                            {f.size && <span className="text-[10px] text-slate-400">({f.size})</span>}
                          </a>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}

          {/* Timeline History */}
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-sm">
            <h3 className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider mb-4 flex items-center gap-1.5">
              <Clock className="w-4 h-4 text-sky-500" />
              <span>Timestamped Order Activity Audit</span>
            </h3>
            <div className="space-y-3 relative before:absolute before:left-2 before:top-2 before:bottom-2 before:w-0.5 before:bg-slate-200 dark:before:bg-slate-800">
              {order.statusHistory.map((hist, idx) => (
                <div key={idx} className="relative pl-6 text-xs">
                  <div className="absolute left-1 top-1 w-2.5 h-2.5 rounded-full bg-sky-500 border-2 border-white dark:border-slate-900"></div>
                  <div className="flex items-baseline justify-between gap-2">
                    <span className="font-bold text-slate-800 dark:text-slate-200 capitalize">
                      {hist.status.replace('_', ' ')}
                    </span>
                    <span className="text-[10px] text-slate-400">
                      {new Date(hist.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </span>
                  </div>
                  {hist.note && (
                    <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">
                      {hist.note}
                    </p>
                  )}
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Right Column: Financial details, Escrow status, Dispute trigger */}
        <div className="space-y-6">
          {/* Financial Breakdown Card */}
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-sm space-y-4">
            <h3 className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider">
              Financial Summary
            </h3>

            <div className="space-y-2 text-xs">
              <div className="flex justify-between text-slate-500">
                <span>Base Service Price</span>
                <span>{formatPrice(order.priceBDT)}</span>
              </div>
              {order.selectedExtras.length > 0 && (
                <div className="flex justify-between text-slate-500">
                  <span>Extras / Add-ons ({order.selectedExtras.length})</span>
                  <span>
                    +{formatPrice(order.selectedExtras.reduce((s, e) => s + e.price, 0))}
                  </span>
                </div>
              )}
              <div className="flex justify-between text-slate-500">
                <span>Platform Commission (10%)</span>
                <span>৳{order.platformFeeBDT}</span>
              </div>
              <div className="flex justify-between text-slate-500">
                <span>Seller Net Earnings</span>
                <span className="text-emerald-600 dark:text-emerald-400 font-bold">
                  ৳{order.sellerNetBDT}
                </span>
              </div>
              <div className="pt-2 border-t border-slate-100 dark:border-slate-800 flex justify-between font-bold text-sm text-slate-900 dark:text-white">
                <span>Total Amount</span>
                <span className="text-base text-sky-600 dark:text-sky-400">
                  {formatPrice(order.totalAmountBDT)}
                </span>
              </div>
            </div>

            {/* Escrow Status info */}
            <div className="p-3 bg-slate-50 dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700 text-[11px] text-slate-600 dark:text-slate-300 space-y-1">
              <div className="flex items-center gap-1.5 font-bold text-slate-800 dark:text-slate-100">
                <ShieldCheck className="w-4 h-4 text-emerald-500" />
                <span>Escrow Protection Active</span>
              </div>
              <p>
                {order.status === 'completed'
                  ? 'Funds released to seller balance upon approved delivery.'
                  : 'Funds securely held until buyer verification.'}
              </p>
            </div>

            {/* Dispute button for legit issues */}
            {order.status !== 'cancelled' && order.status !== 'refunded' && (
              <button
                onClick={() => setDisputeModalOpen(true)}
                className="w-full py-2 text-rose-600 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/30 rounded-xl text-xs font-semibold border border-rose-200 dark:border-rose-900 transition flex items-center justify-center gap-1.5"
              >
                <AlertTriangle className="w-3.5 h-3.5" />
                <span>{t('openDispute')}</span>
              </button>
            )}
          </div>
        </div>
      </div>

      {/* -------------------- DELIVERY MODAL -------------------- */}
      {deliveryModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-sm animate-in fade-in">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 w-full max-w-lg shadow-2xl">
            <h3 className="text-base font-bold text-slate-900 dark:text-white mb-2">
              {t('deliverWork')}
            </h3>
            <p className="text-xs text-slate-500 mb-4">{t('deliveryNotesPlaceholder')}</p>

            <form onSubmit={handleDeliverSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                  {t('deliveryNotes')} *
                </label>
                <textarea
                  required
                  rows={4}
                  value={deliveryNotes}
                  onChange={(e) => setDeliveryNotes(e.target.value)}
                  placeholder="I have completed 50 contextual backlinks on DA 55+ websites. Please check attached report..."
                  className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs font-mono"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                  {t('attachWorkFiles')}
                </label>
                <input
                  type="file"
                  onChange={handleDeliveryFileUpload}
                  className="text-xs text-slate-500 file:mr-3 file:py-1.5 file:px-3 file:rounded-lg file:border-0 file:text-xs file:font-semibold file:bg-sky-50 file:text-sky-700 dark:file:bg-slate-800 dark:file:text-sky-400"
                />
                {deliveryFiles.length > 0 && (
                  <div className="mt-2 text-xs text-emerald-600 flex items-center gap-1">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    <span>Attached: {deliveryFiles.map((f) => f.name).join(', ')}</span>
                  </div>
                )}
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setDeliveryModalOpen(false)}
                  className="px-4 py-2 text-xs font-semibold text-slate-500"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold shadow-md"
                >
                  {t('submitDelivery')}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* -------------------- REVISION MODAL -------------------- */}
      {revisionModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-sm animate-in fade-in">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 w-full max-w-lg shadow-2xl">
            <h3 className="text-base font-bold text-slate-900 dark:text-white mb-2">
              {t('requestRevision')}
            </h3>
            <p className="text-xs text-slate-500 mb-4">{t('revisionReason')}</p>
            <form onSubmit={handleRevisionSubmit} className="space-y-4">
              <textarea
                required
                rows={4}
                value={revisionNote}
                onChange={(e) => setRevisionNote(e.target.value)}
                placeholder="Please re-check the anchors for lines 4 and 12, as they point to the incorrect landing page..."
                className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs"
              />
              <div className="flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setRevisionModalOpen(false)}
                  className="px-4 py-2 text-xs font-semibold text-slate-500"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-purple-600 hover:bg-purple-700 text-white rounded-xl text-xs font-bold"
                >
                  {t('submitRevision')}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* -------------------- REVIEW MODAL -------------------- */}
      {reviewModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-sm animate-in fade-in">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 w-full max-w-md shadow-2xl">
            <h3 className="text-base font-bold text-slate-900 dark:text-white mb-2">
              {t('rateAndReview')}
            </h3>

            {reviewSuccess ? (
              <div className="p-4 bg-emerald-50 dark:bg-emerald-950/40 rounded-xl text-emerald-700 dark:text-emerald-300 text-xs font-bold text-center">
                ✓ {reviewSuccess}
              </div>
            ) : (
              <form onSubmit={handleReviewSubmit} className="space-y-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                    Rating (1 to 5 Stars)
                  </label>
                  <div className="flex items-center gap-1.5">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <button
                        type="button"
                        key={star}
                        onClick={() => setReviewRating(star)}
                        className="p-1 hover:scale-110 transition"
                      >
                        <Star
                          className={`w-6 h-6 ${
                            star <= reviewRating
                              ? 'fill-amber-400 stroke-amber-400'
                              : 'text-slate-300 dark:text-slate-700'
                          }`}
                        />
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                    {t('reviewComment')} *
                  </label>
                  <textarea
                    required
                    rows={3}
                    value={reviewComment}
                    onChange={(e) => setReviewComment(e.target.value)}
                    placeholder="Excellent SEO work! Fast response, genuine high DA links, clean report."
                    className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs"
                  />
                </div>

                <div className="flex justify-end gap-2">
                  <button
                    type="button"
                    onClick={() => setReviewModalOpen(false)}
                    className="px-4 py-2 text-xs font-semibold text-slate-500"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-4 py-2 bg-amber-500 hover:bg-amber-600 text-slate-950 rounded-xl text-xs font-bold"
                  >
                    {t('submitReview')}
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      )}

      {/* -------------------- DISPUTE MODAL -------------------- */}
      {disputeModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-sm animate-in fade-in">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 w-full max-w-lg shadow-2xl">
            <h3 className="text-base font-bold text-slate-900 dark:text-white mb-2 flex items-center gap-2">
              <AlertTriangle className="w-5 h-5 text-rose-500" />
              <span>{t('openDispute')}</span>
            </h3>
            <p className="text-xs text-slate-500 mb-4">{t('disputeDetails')}</p>

            <form onSubmit={handleDisputeSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                  {t('disputeReason')}
                </label>
                <select
                  value={disputeReason}
                  onChange={(e) => setDisputeReason(e.target.value)}
                  className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs"
                >
                  <option value="Poor Quality / Requirements Not Met">{t('disputeReasonQuality')}</option>
                  <option value="Extremely Late Delivery with No Communication">{t('disputeReasonLate')}</option>
                  <option value="Invalid or Broken Links / Fake Delivery">{t('disputeReasonFakeProof')}</option>
                  <option value="Other Issue">{t('disputeReasonOther')}</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Detailed Explanation *
                </label>
                <textarea
                  required
                  rows={4}
                  value={disputeDetails}
                  onChange={(e) => setDisputeDetails(e.target.value)}
                  placeholder="Explain exactly what went wrong and what resolution you expect..."
                  className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs"
                />
              </div>

              <div className="flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setDisputeModalOpen(false)}
                  className="px-4 py-2 text-xs font-semibold text-slate-500"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-rose-600 hover:bg-rose-700 text-white rounded-xl text-xs font-bold"
                >
                  {t('submitDispute')}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* -------------------- REJECT PAYMENT MODAL (ADMIN) -------------------- */}
      {rejectPaymentModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-sm animate-in fade-in">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 w-full max-w-md shadow-2xl">
            <h3 className="text-base font-bold text-slate-900 dark:text-white mb-2 text-rose-600">
              {t('actionReject')}
            </h3>
            <p className="text-xs text-slate-500 mb-4">{t('reasonForRejection')}</p>

            <form
              onSubmit={(e) => {
                e.preventDefault();
                if (!rejectionReason.trim()) return;
                rejectOrderPayment(order.id, rejectionReason.trim());
                setRejectPaymentModalOpen(false);
              }}
              className="space-y-4"
            >
              <textarea
                required
                rows={3}
                value={rejectionReason}
                onChange={(e) => setRejectionReason(e.target.value)}
                placeholder="Invalid TrxID. No matching amount found in bKash statement for this sender number."
                className="w-full p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs"
              />
              <div className="flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setRejectPaymentModalOpen(false)}
                  className="px-4 py-2 text-xs font-semibold text-slate-500"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-rose-600 hover:bg-rose-700 text-white rounded-xl text-xs font-bold"
                >
                  Confirm Rejection
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
