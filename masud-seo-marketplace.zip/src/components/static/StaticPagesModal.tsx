import React from 'react';
import { Mail, Phone, Shield, X } from 'lucide-react';
import { useLanguage } from '../../i18n/LanguageContext';

interface StaticPagesModalProps {
  page: 'help' | 'contact' | 'privacy' | 'terms' | 'refund' | null;
  onClose: () => void;
}

export const StaticPagesModal: React.FC<StaticPagesModalProps> = ({ page, onClose }) => {
  const { language, t } = useLanguage();

  if (!page) return null;

  const titles = {
    help: t('helpCenter'),
    contact: t('contactUs'),
    privacy: t('privacyPolicy'),
    terms: t('termsOfService'),
    refund: t('refundPolicy'),
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/75 backdrop-blur-sm animate-in fade-in">
      <div className="relative w-full max-w-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-2xl p-6 max-h-[85vh] overflow-y-auto">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-1 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
        >
          <X className="w-5 h-5" />
        </button>

        <h2 className="text-lg font-bold text-slate-900 dark:text-white mb-4 pb-2 border-b border-slate-100 dark:border-slate-800">
          {titles[page]}
        </h2>

        {/* 1. HELP CENTER */}
        {page === 'help' && (
          <div className="space-y-4 text-xs text-slate-700 dark:text-slate-300 leading-relaxed">
            <div>
              <h4 className="font-bold text-slate-900 dark:text-white mb-1">
                {language === 'bn' ? '১. কীভাবে অর্ডার ও পেমেন্ট করবেন?' : '1. How to place an order and pay?'}
              </h4>
              <p>
                {language === 'bn'
                  ? 'আপনার পছন্দের এসইও গিগ বেছে নিয়ে "Order Now" চাপুন। আপনার ওয়েবসাইটের রিকোয়ারমেন্টস লিখে আমাদের ভেরিফাইড বিকাশ (01784038383), নগদ (01644858242) বা রকেট নম্বরে সেন্ড মানি করে TrxID ও প্রেরক নম্বর সাবমিট করুন।'
                  : 'Select your preferred SEO gig, click "Order Now", enter your website instructions, and send funds via bKash (01784038383), Nagad (01644858242), or Rocket. Submit your TrxID for admin verification.'}
              </p>
            </div>

            <div>
              <h4 className="font-bold text-slate-900 dark:text-white mb-1">
                {language === 'bn' ? '২. এসক্রো সুরক্ষা কীভাবে কাজ করে?' : '2. How does Escrow Protection work?'}
              </h4>
              <p>
                {language === 'bn'
                  ? 'অ্যাডমিন পেমেন্ট ভেরিফাই করলে আপনার টাকা আমাদের সুরক্ষিত এসক্রো লেজারে জমা থাকে। সেলার কাজ ডেলিভারি করার পর আপনি রিপোর্ট দেখে অনুমোদন দিলেই কেবল সেলার টাকা পাবেন।'
                  : 'Funds remain held securely in escrow after admin verification. Only when you receive and approve the completed SEO delivery are funds released to the seller.'}
              </p>
            </div>

            <div>
              <h4 className="font-bold text-slate-900 dark:text-white mb-1">
                {language === 'bn' ? '৩. কাজে সমস্যা হলে কী করবেন?' : '3. What if there is an issue with the delivery?'}
              </h4>
              <p>
                {language === 'bn'
                  ? 'আপনি রিভিশন রিকোয়েস্ট পাঠাতে পারেন অথবা সরাসরি "Open Dispute" বাটনে ক্লিক করে অ্যাডমিন হস্তক্ষেপ চাইতে পারেন।'
                  : 'You can request revisions from the seller or click "Open Dispute" to request an immediate administrative refund review.'}
              </p>
            </div>
          </div>
        )}

        {/* 2. CONTACT US */}
        {page === 'contact' && (
          <div className="space-y-4 text-xs text-slate-700 dark:text-slate-300 leading-relaxed">
            <p>
              {language === 'bn'
                ? 'যেকোনো জিজ্ঞাসা, পেমেন্ট সংক্রান্ত যাচাই বা সহায়তার জন্য সরাসরি আমাদের সাথে যোগাযোগ করুন:'
                : 'For any inquiries, payment confirmation, or disputes, contact our official support team:'}
            </p>

            <div className="p-4 bg-slate-50 dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700 space-y-2.5">
              <div className="flex items-center gap-2">
                <span className="font-bold text-slate-900 dark:text-white">Founder & Admin:</span>
                <span>Md. Masud Rana</span>
              </div>
              <div className="flex items-center gap-2">
                <Mail className="w-4 h-4 text-sky-500" />
                <span className="font-mono font-medium">mdmasudranakeshorhatbajar29@gmail.com</span>
              </div>
              <div className="flex items-center gap-2">
                <Phone className="w-4 h-4 text-sky-500" />
                <span className="font-mono font-medium">+8801784038383</span>
              </div>
              <div>
                <span className="font-bold text-slate-900 dark:text-white">Official Domain:</span>{' '}
                <span className="text-sky-600 font-semibold">www.masudseoservice.com</span>
              </div>
              <div>
                <span className="font-bold text-slate-900 dark:text-white">Address:</span> Keshorhat Bajar, Rajshahi, Bangladesh.
              </div>
            </div>
          </div>
        )}

        {/* 3. PRIVACY POLICY */}
        {page === 'privacy' && (
          <div className="space-y-3 text-xs text-slate-700 dark:text-slate-300 leading-relaxed">
            <p>
              At <strong>Masud SEO Marketplace</strong> (www.masudseoservice.com), we respect the privacy of buyers and sellers.
            </p>
            <h4 className="font-bold text-slate-900 dark:text-white">Data Protection Principles:</h4>
            <ul className="list-disc pl-5 space-y-1">
              <li>Passwords are strictly hashed via secure industry-standard algorithms; plain-text passwords are never stored.</li>
              <li>Wallet PINs, OTPs, or financial secrets are never requested or stored.</li>
              <li>Uploaded screenshots and deliverables are restricted to authorized order participants and auditing administrators.</li>
              <li>All database communications use prepared statements to safeguard user integrity.</li>
            </ul>
          </div>
        )}

        {/* 4. TERMS OF SERVICE */}
        {page === 'terms' && (
          <div className="space-y-3 text-xs text-slate-700 dark:text-slate-300 leading-relaxed">
            <h4 className="font-bold text-slate-900 dark:text-white">User Agreements:</h4>
            <ul className="list-disc pl-5 space-y-1.5">
              <li>All sellers agree to provide genuine white-hat or agreed SEO backlinks and services without black-hat malware risks.</li>
              <li>Platform charges an administrator-configured 10% commission on completed orders to maintain infrastructure.</li>
              <li>Fake payment submissions, false Transaction IDs, or harassment are subject to immediate account termination.</li>
              <li>Work is delivered with transparent reporting (Excel, PDF, live link logs).</li>
            </ul>
          </div>
        )}

        {/* 5. REFUND POLICY */}
        {page === 'refund' && (
          <div className="space-y-3 text-xs text-slate-700 dark:text-slate-300 leading-relaxed">
            <h4 className="font-bold text-slate-900 dark:text-white">100% Buyer Satisfaction Guarantee:</h4>
            <p>
              If a seller fails to deliver within the agreed timeframe without notice, or delivers work that completely breaches the gig specifications, buyers are entitled to open an administrative dispute for a full 100% refund.
            </p>
            <p>
              Refunds are processed back through bKash, Nagad, or Rocket within 24-48 business hours following dispute resolution.
            </p>
          </div>
        )}

        <div className="mt-6 pt-4 border-t border-slate-100 dark:border-slate-800 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 bg-slate-900 dark:bg-white text-white dark:text-slate-900 font-bold rounded-xl text-xs"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
