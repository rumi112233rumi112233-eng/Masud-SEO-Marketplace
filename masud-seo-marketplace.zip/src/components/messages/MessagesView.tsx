import React, { useState } from 'react';
import {
  ArrowLeft,
  FileText,
  Paperclip,
  Send,
  ShoppingBag,
  User,
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { useMarketplace } from '../../context/MarketplaceContext';
import { useLanguage } from '../../i18n/LanguageContext';

interface MessagesViewProps {
  initialPartnerId?: string;
  initialOrderId?: string;
  onBack: () => void;
  onViewOrder?: (orderId: string) => void;
}

export const MessagesView: React.FC<MessagesViewProps> = ({
  initialPartnerId,
  initialOrderId,
  onBack,
  onViewOrder,
}) => {
  const { currentUser, users } = useAuth();
  const { messages, orders, sendMessage, markMessagesRead } = useMarketplace();
  const { language, t } = useLanguage();

  // Find all distinct chat partners from messages or active orders
  const chatPartners = users.filter((u) => u.id !== currentUser?.id);

  const [selectedPartnerId, setSelectedPartnerId] = useState<string>(
    initialPartnerId || chatPartners[0]?.id || ''
  );
  const [inputText, setInputText] = useState('');
  const [attachedFile, setAttachedFile] = useState<{ name: string; url: string } | null>(null);

  if (!currentUser) return null;

  const activePartner = users.find((u) => u.id === selectedPartnerId);

  // Filter messages between currentUser and selectedPartner
  const conversationMessages = messages.filter((m) => {
    return (
      (m.senderId === currentUser.id && m.conversationId.includes(selectedPartnerId)) ||
      (m.senderId === selectedPartnerId && m.conversationId.includes(currentUser.id))
    );
  });

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim() && !attachedFile) return;

    sendMessage(
      selectedPartnerId,
      inputText.trim() || 'Sent an attachment.',
      initialOrderId,
      attachedFile || undefined
    );

    setInputText('');
    setAttachedFile(null);
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setAttachedFile({
        name: file.name,
        url: URL.createObjectURL(file),
      });
    }
  };

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8 animate-in fade-in">
      <button
        onClick={onBack}
        className="inline-flex items-center gap-1.5 text-xs font-semibold text-slate-600 dark:text-slate-400 hover:text-sky-600 mb-4"
      >
        <ArrowLeft className="w-4 h-4" />
        <span>Back to Dashboard</span>
      </button>

      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-xl overflow-hidden grid grid-cols-1 md:grid-cols-3 h-[75vh]">
        {/* Left column: Conversations list */}
        <div className="border-r border-slate-200 dark:border-slate-800 flex flex-col h-full bg-slate-50/50 dark:bg-slate-900/50">
          <div className="p-4 border-b border-slate-200 dark:border-slate-800">
            <h2 className="text-sm font-bold text-slate-900 dark:text-white">
              {t('messages')}
            </h2>
          </div>

          <div className="flex-1 overflow-y-auto divide-y divide-slate-100 dark:divide-slate-800">
            {chatPartners.map((partner) => {
              const isSelected = partner.id === selectedPartnerId;
              const lastMsg = messages
                .filter(
                  (m) =>
                    (m.senderId === currentUser.id && m.conversationId.includes(partner.id)) ||
                    (m.senderId === partner.id && m.conversationId.includes(currentUser.id))
                )
                .slice(-1)[0];

              return (
                <button
                  key={partner.id}
                  onClick={() => {
                    setSelectedPartnerId(partner.id);
                    markMessagesRead(partner.id);
                  }}
                  className={`w-full text-left p-3.5 flex items-center gap-3 transition ${
                    isSelected
                      ? 'bg-sky-50 dark:bg-sky-950/40 border-l-4 border-sky-600'
                      : 'hover:bg-slate-100/60 dark:hover:bg-slate-800/60'
                  }`}
                >
                  <img
                    src={partner.avatar}
                    alt={partner.name}
                    className="w-10 h-10 rounded-full object-cover shrink-0"
                  />
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold text-slate-900 dark:text-slate-100 truncate">
                        {partner.name}
                      </span>
                      <span className="text-[10px] text-slate-400 capitalize">
                        {partner.role}
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-500 truncate mt-0.5">
                      {lastMsg ? lastMsg.text : 'Click to start conversation'}
                    </p>
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Right 2-column: Chat thread */}
        <div className="md:col-span-2 flex flex-col h-full bg-white dark:bg-slate-900">
          {activePartner ? (
            <>
              {/* Partner Header */}
              <div className="p-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <img
                    src={activePartner.avatar}
                    alt={activePartner.name}
                    className="w-9 h-9 rounded-full object-cover"
                  />
                  <div>
                    <h3 className="text-xs font-bold text-slate-900 dark:text-white">
                      {activePartner.name}
                    </h3>
                    <span className="text-[10px] text-emerald-600 dark:text-emerald-400 font-semibold">
                      Online · Verified {activePartner.role}
                    </span>
                  </div>
                </div>

                {initialOrderId && (
                  <div className="text-[11px] font-mono text-sky-600 bg-sky-50 dark:bg-sky-950/40 px-2.5 py-1 rounded-lg">
                    Order Ref: #{initialOrderId}
                  </div>
                )}
              </div>

              {/* Messages scroll area */}
              <div className="flex-1 overflow-y-auto p-4 space-y-3">
                {conversationMessages.map((msg) => {
                  const isMine = msg.senderId === currentUser.id;
                  return (
                    <div
                      key={msg.id}
                      className={`flex flex-col ${isMine ? 'items-end' : 'items-start'}`}
                    >
                      <div
                        className={`max-w-md p-3 rounded-2xl text-xs leading-relaxed shadow-sm ${
                          isMine
                            ? 'bg-sky-600 text-white rounded-br-none'
                            : 'bg-slate-100 dark:bg-slate-800 text-slate-800 dark:text-slate-100 rounded-bl-none'
                        }`}
                      >
                        <p>{msg.text}</p>
                        {msg.attachments && msg.attachments.length > 0 && (
                          <div className="mt-2 pt-2 border-t border-white/20 dark:border-slate-700 space-y-1">
                            {msg.attachments.map((att, i) => (
                              <div key={i} className="flex items-center gap-1.5 text-[11px] underline">
                                <Paperclip className="w-3 h-3" />
                                <span>{att.name}</span>
                              </div>
                            ))}
                          </div>
                        )}
                      </div>
                      <span className="text-[9px] text-slate-400 mt-1 px-1">
                        {new Date(msg.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                      </span>
                    </div>
                  );
                })}

                {conversationMessages.length === 0 && (
                  <div className="h-full flex items-center justify-center text-xs text-slate-400">
                    No messages yet. Send a message to discuss requirements or ask questions.
                  </div>
                )}
              </div>

              {/* Input bar */}
              <form onSubmit={handleSend} className="p-3 border-t border-slate-200 dark:border-slate-800 flex items-center gap-2">
                <label className="p-2 rounded-lg text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer">
                  <Paperclip className="w-4 h-4" />
                  <input type="file" onChange={handleFileUpload} className="hidden" />
                </label>

                {attachedFile && (
                  <div className="text-[10px] bg-sky-100 dark:bg-sky-950 text-sky-800 dark:text-sky-300 px-2 py-1 rounded truncate max-w-xs">
                    {attachedFile.name}
                  </div>
                )}

                <input
                  type="text"
                  value={inputText}
                  onChange={(e) => setInputText(e.target.value)}
                  placeholder="Write a message..."
                  className="flex-1 px-3 py-2 bg-slate-100 dark:bg-slate-800 border-none rounded-xl text-xs text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-1 focus:ring-sky-500"
                />

                <button
                  type="submit"
                  className="p-2 bg-sky-600 hover:bg-sky-700 text-white rounded-xl shadow-sm transition"
                >
                  <Send className="w-4 h-4" />
                </button>
              </form>
            </>
          ) : (
            <div className="h-full flex items-center justify-center text-xs text-slate-400">
              Select a conversation to start messaging.
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
