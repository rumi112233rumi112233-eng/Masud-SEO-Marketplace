import React from 'react';
import { Mail, Phone, Shield, Sparkles } from 'lucide-react';
import { useLanguage } from '../../i18n/LanguageContext';

interface FooterProps {
  onNavigate: (view: string) => void;
  onOpenStaticModal: (page: 'help' | 'contact' | 'privacy' | 'terms' | 'refund') => void;
  onOpenDeploy: () => void;
}

export const Footer: React.FC<FooterProps> = ({ onNavigate, onOpenStaticModal, onOpenDeploy }) => {
  const { language, t } = useLanguage();

  return (
    <footer className="bg-slate-900 text-slate-400 border-t border-slate-800 text-xs">
      {/* Top Banner with Payment badges */}
      <div className="border-b border-slate-800/80 py-6 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
        <div className="flex flex-col md:flex-row items-center justify-between gap-4">
          <div>
            <h4 className="text-white font-bold text-sm flex items-center gap-2">
              <Shield className="w-4 h-4 text-emerald-400" />
              <span>{language === 'bn' ? 'বাংলাদেশি অফিসিয়াল ম্যানুয়াল পেমেন্ট চ্যানেল' : 'Official Bangladesh Manual Payment Channels'}</span>
            </h4>
            <p className="text-[11px] text-slate-400 mt-0.5">
              {language === 'bn'
                ? 'বিকাশ, নগদ ও রকেটে টাকা পাঠিয়ে ট্রানজেকশন আইডি (TrxID) দিয়ে অর্ডার নিশ্চিত করুন।'
                : 'Send funds securely via bKash, Nagad, or Rocket and submit TrxID for admin verification.'}
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            {/* bKash Badge */}
            <div className="flex items-center gap-2 bg-pink-950/40 border border-pink-700/50 rounded-lg px-3 py-1.5 text-pink-300">
              <span className="font-extrabold text-xs">bKash</span>
              <span className="font-mono text-white text-[11px] font-semibold">01784038383</span>
            </div>

            {/* Nagad Badge */}
            <div className="flex items-center gap-2 bg-amber-950/40 border border-amber-700/50 rounded-lg px-3 py-1.5 text-amber-300">
              <span className="font-extrabold text-xs">Nagad</span>
              <span className="font-mono text-white text-[11px] font-semibold">01644858242</span>
            </div>

            {/* Rocket Badge */}
            <div className="flex items-center gap-2 bg-purple-950/40 border border-purple-700/50 rounded-lg px-3 py-1.5 text-purple-300">
              <span className="font-extrabold text-xs">Rocket</span>
              <span className="font-mono text-white text-[11px] font-semibold">017948469293</span>
            </div>
          </div>
        </div>
      </div>

      {/* Main Footer Links */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Brand Info */}
          <div className="space-y-3 md:col-span-1">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-sky-600 flex items-center justify-center text-white font-extrabold text-base">
                M
              </div>
              <span className="font-extrabold text-sm tracking-tight text-white">
                MASUD <span className="text-sky-400">SEO</span> MARKETPLACE
              </span>
            </div>
            <p className="text-xs text-slate-400 leading-relaxed">
              {t('aboutMarketplaceText')}
            </p>
            <div className="space-y-1 text-[11px] text-slate-300">
              <div className="flex items-center gap-2">
                <Mail className="w-3.5 h-3.5 text-sky-400" />
                <span>mdmasudranakeshorhatbajar29@gmail.com</span>
              </div>
              <div className="flex items-center gap-2">
                <Phone className="w-3.5 h-3.5 text-sky-400" />
                <span>+8801784038383 (Founder Masud Rana)</span>
              </div>
            </div>
          </div>

          {/* Quick Categories */}
          <div>
            <h5 className="font-bold text-white text-xs uppercase tracking-wider mb-3">
              {t('categories')}
            </h5>
            <ul className="space-y-2 text-xs">
              <li>
                <button
                  onClick={() => onNavigate('browse')}
                  className="hover:text-white transition"
                >
                  {language === 'bn' ? 'ব্যাকলিংক ও লিংক বিল্ডিং' : 'Backlinks & Link Building'}
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('browse')}
                  className="hover:text-white transition"
                >
                  {language === 'bn' ? 'টেকনিক্যাল ও অন-পেজ এসইও' : 'Technical & On-Page SEO'}
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('browse')}
                  className="hover:text-white transition"
                >
                  {language === 'bn' ? 'ওয়ার্ডপ্রেস স্পিড অপটিমাইজেশন' : 'WordPress Speed Acceleration'}
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('browse')}
                  className="hover:text-white transition"
                >
                  {language === 'bn' ? 'লোকাল এসইও ও গুগল ম্যাপস' : 'Local SEO & Google Maps'}
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('browse')}
                  className="hover:text-white transition"
                >
                  {language === 'bn' ? 'এসইও কনটেন্ট ও আর্টিকেল' : 'SEO Content Writing'}
                </button>
              </li>
            </ul>
          </div>

          {/* Support & Legal Policies */}
          <div>
            <h5 className="font-bold text-white text-xs uppercase tracking-wider mb-3">
              {language === 'bn' ? 'সহায়তা ও নীতিমালা' : 'Support & Legal'}
            </h5>
            <ul className="space-y-2 text-xs">
              <li>
                <button onClick={() => onOpenStaticModal('help')} className="hover:text-white transition">
                  {t('helpCenter')}
                </button>
              </li>
              <li>
                <button onClick={() => onOpenStaticModal('contact')} className="hover:text-white transition">
                  {t('contactUs')}
                </button>
              </li>
              <li>
                <button onClick={() => onOpenStaticModal('privacy')} className="hover:text-white transition">
                  {t('privacyPolicy')}
                </button>
              </li>
              <li>
                <button onClick={() => onOpenStaticModal('terms')} className="hover:text-white transition">
                  {t('termsOfService')}
                </button>
              </li>
              <li>
                <button onClick={() => onOpenStaticModal('refund')} className="hover:text-white transition">
                  {t('refundPolicy')}
                </button>
              </li>
            </ul>
          </div>

          {/* Administration & Deployment */}
          <div>
            <h5 className="font-bold text-white text-xs uppercase tracking-wider mb-3">
              {language === 'bn' ? 'প্রোডাকশন ডেপ্লয়মেন্ট' : 'Hosting & Admin'}
            </h5>
            <p className="text-[11px] text-slate-400 mb-3">
              {language === 'bn'
                ? 'InfinityFree শেয়ার্ড হোস্টিংয়ের জন্য প্রস্তুত পিএইচপি ও মাইএসকিউএল স্ক্রিপ্ট ও স্কিমা ডাউনলোড করুন।'
                : 'Deploy on InfinityFree shared hosting with complete PHP 8 & MySQL database schema.'}
            </p>
            <div className="space-y-2">
              <button
                onClick={onOpenDeploy}
                className="w-full flex items-center justify-center gap-1.5 py-2 px-3 bg-sky-600 hover:bg-sky-500 text-white rounded-lg text-xs font-semibold shadow-sm transition"
              >
                <Sparkles className="w-3.5 h-3.5" />
                <span>{language === 'bn' ? 'InfinityFree SQL ও ফাইলস' : 'InfinityFree Deployment Pack'}</span>
              </button>

              <button
                onClick={() => onNavigate('admin')}
                className="w-full py-1.5 text-center text-[11px] text-slate-400 hover:text-slate-200 transition"
              >
                🔐 {t('adminLoginPrompt')} (addminmasud)
              </button>
            </div>
          </div>
        </div>

        {/* Bottom copyright */}
        <div className="border-t border-slate-800 mt-8 pt-6 flex flex-col sm:flex-row items-center justify-between text-[11px] text-slate-500 gap-2">
          <div>
            © {new Date().getFullYear()} {t('brandName')} · <span className="text-sky-400">www.masudseoservice.com</span>. {language === 'bn' ? 'সর্বস্বত্ব সংরক্ষিত।' : 'All rights reserved.'}
          </div>
          <div className="flex items-center gap-3">
            <span>Powered by PHP 8 & MySQL Architecture</span>
            <span>·</span>
            <span>Escrow Protected</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
