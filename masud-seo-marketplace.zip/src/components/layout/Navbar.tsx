import React, { useState } from 'react';
import {
  Bell,
  CheckCircle2,
  ChevronDown,
  Globe,
  Layers,
  LogOut,
  Menu,
  Moon,
  PlusCircle,
  Search,
  ShieldCheck,
  ShoppingBag,
  Sun,
  User as UserIcon,
  X,
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { useMarketplace } from '../../context/MarketplaceContext';
import { useLanguage } from '../../i18n/LanguageContext';
import { CurrencyCode, LanguageCode } from '../../types';

interface NavbarProps {
  onNavigate: (view: string, param?: any) => void;
  currentView: string;
  onOpenAuth: (mode: 'login' | 'register' | 'admin') => void;
  onOpenCreateGig: () => void;
  onOpenDeploy: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  onNavigate,
  currentView,
  onOpenAuth,
  onOpenCreateGig,
  onOpenDeploy,
}) => {
  const { currentUser, logout, quickLoginAs, isAdmin, isSeller } = useAuth();
  const { categories, notifications, orders, markNotificationRead, markAllNotificationsRead } = useMarketplace();
  const { language, setLanguage, currency, setCurrency, theme, toggleTheme, t } = useLanguage();

  const [searchQuery, setSearchQuery] = useState('');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [userDropdownOpen, setUserDropdownOpen] = useState(false);
  const [notifDropdownOpen, setNotifDropdownOpen] = useState(false);
  const [categoriesDropdownOpen, setCategoriesDropdownOpen] = useState(false);

  const unreadNotifs = currentUser
    ? notifications.filter((n) => n.userId === currentUser.id && !n.isRead)
    : [];

  const userActiveOrders = currentUser
    ? orders.filter(
        (o) =>
          (o.buyerId === currentUser.id || o.sellerId === currentUser.id) &&
          o.status !== 'completed' &&
          o.status !== 'cancelled' &&
          o.status !== 'refunded'
      )
    : [];

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      onNavigate('browse', { query: searchQuery.trim() });
    } else {
      onNavigate('browse');
    }
  };

  return (
    <header className="sticky top-0 z-40 w-full bg-white/95 dark:bg-slate-900/95 backdrop-blur-md border-b border-slate-200 dark:border-slate-800 transition-colors">
      {/* Top Banner: Quick Role Switcher for Testing & Domain Info */}
      <div className="bg-gradient-to-r from-sky-900 via-indigo-900 to-sky-950 text-white text-xs py-1.5 px-4">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-3">
            <span className="font-semibold text-sky-300">🌐 www.masudseoservice.com</span>
            <span className="hidden sm:inline text-slate-300">|</span>
            <span className="hidden sm:inline text-slate-200">
              {language === 'bn' ? 'ম্যানুয়াল পেমেন্ট: বিকাশ 01784038383 · নগদ 01644858242 · রকেট 017948469293' : 'Manual Payment: bKash 01784038383 · Nagad 01644858242 · Rocket 017948469293'}
            </span>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-slate-300 hidden md:inline">{language === 'bn' ? 'দ্রুত রোল টেস্ট:' : 'Quick Role Switch:'}</span>
            <div className="flex items-center gap-1 bg-white/10 rounded-md p-0.5">
              <button
                onClick={() => quickLoginAs('admin')}
                className={`px-2 py-0.5 rounded text-[11px] font-medium transition ${
                  currentUser?.role === 'admin' ? 'bg-amber-500 text-slate-950 font-bold' : 'hover:bg-white/20'
                }`}
                title="Login as Administrator (addminmasud)"
              >
                👑 Admin
              </button>
              <button
                onClick={() => quickLoginAs('seller')}
                className={`px-2 py-0.5 rounded text-[11px] font-medium transition ${
                  currentUser?.role === 'seller' ? 'bg-emerald-500 text-white font-bold' : 'hover:bg-white/20'
                }`}
                title="Login as Verified Seller (tanvir_seo)"
              >
                💼 Seller
              </button>
              <button
                onClick={() => quickLoginAs('buyer')}
                className={`px-2 py-0.5 rounded text-[11px] font-medium transition ${
                  currentUser?.role === 'buyer' ? 'bg-sky-500 text-white font-bold' : 'hover:bg-white/20'
                }`}
                title="Login as Buyer (shafiul_biz)"
              >
                🛒 Buyer
              </button>
            </div>

            <button
              onClick={onOpenDeploy}
              className="ml-2 bg-indigo-600 hover:bg-indigo-500 text-white text-[11px] font-semibold px-2 py-0.5 rounded transition flex items-center gap-1 shadow-sm"
            >
              📥 InfinityFree SQL & Files
            </button>
          </div>
        </div>
      </div>

      {/* Main Nav */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 gap-4">
          {/* Brand Logo */}
          <div className="flex items-center gap-3">
            <button
              onClick={() => onNavigate('home')}
              className="flex items-center gap-2.5 text-left focus:outline-none group"
            >
              <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-sky-600 to-indigo-600 flex items-center justify-center text-white font-black text-xl shadow-md group-hover:scale-105 transition-transform">
                M
              </div>
              <div>
                <div className="font-extrabold text-base sm:text-lg tracking-tight text-slate-900 dark:text-white leading-none">
                  MASUD <span className="text-sky-600 dark:text-sky-400">SEO</span>
                </div>
                <div className="text-[10px] font-medium text-slate-500 dark:text-slate-400 uppercase tracking-widest leading-none mt-1">
                  Marketplace
                </div>
              </div>
            </button>

            {/* Categories Dropdown (Desktop) */}
            <div className="relative hidden lg:block">
              <button
                onClick={() => setCategoriesDropdownOpen(!categoriesDropdownOpen)}
                className="flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-slate-700 dark:text-slate-200 hover:text-sky-600 dark:hover:text-sky-400 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition"
              >
                <Layers className="w-4 h-4 text-sky-500" />
                <span>{t('categories')}</span>
                <ChevronDown className="w-3.5 h-3.5" />
              </button>

              {categoriesDropdownOpen && (
                <div
                  className="absolute left-0 mt-2 w-64 bg-white dark:bg-slate-800 rounded-xl shadow-xl border border-slate-200 dark:border-slate-700 py-2 z-50 animate-in fade-in"
                  onMouseLeave={() => setCategoriesDropdownOpen(false)}
                >
                  {categories.map((cat) => (
                    <button
                      key={cat.id}
                      onClick={() => {
                        onNavigate('browse', { categoryId: cat.id });
                        setCategoriesDropdownOpen(false);
                      }}
                      className="w-full text-left px-4 py-2.5 text-xs text-slate-700 dark:text-slate-200 hover:bg-sky-50 dark:hover:bg-slate-700 hover:text-sky-600 transition flex items-center justify-between"
                    >
                      <span className="font-medium">
                        {language === 'bn' ? cat.nameBn : cat.nameEn}
                      </span>
                      <span className="text-[10px] text-slate-400 font-mono">
                        {cat.subcategories.length} sub
                      </span>
                    </button>
                  ))}
                  <div className="border-t border-slate-100 dark:border-slate-700 my-1"></div>
                  <button
                    onClick={() => {
                      onNavigate('browse');
                      setCategoriesDropdownOpen(false);
                    }}
                    className="w-full text-left px-4 py-2 text-xs font-semibold text-sky-600 dark:text-sky-400 hover:bg-sky-50 dark:hover:bg-slate-700"
                  >
                    {t('browseServices')} →
                  </button>
                </div>
              )}
            </div>
          </div>

          {/* Search Bar */}
          <form onSubmit={handleSearchSubmit} className="hidden md:flex flex-1 max-w-md mx-2">
            <div className="relative w-full">
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder={t('searchPlaceholder')}
                className="w-full pl-9 pr-20 py-2 bg-slate-100 dark:bg-slate-800 border border-transparent focus:border-sky-500 focus:bg-white dark:focus:bg-slate-900 rounded-lg text-xs text-slate-800 dark:text-slate-100 placeholder-slate-400 focus:outline-none transition"
              />
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
              <button
                type="submit"
                className="absolute right-1.5 top-1 bottom-1 px-3 bg-sky-600 hover:bg-sky-700 text-white rounded text-xs font-medium transition"
              >
                {t('search')}
              </button>
            </div>
          </form>

          {/* Right Action Icons & User Controls */}
          <div className="flex items-center gap-2">
            {/* Language Switcher */}
            <div className="relative">
              <button
                onClick={() => setLanguage(language === 'bn' ? 'en' : 'bn')}
                className="flex items-center gap-1 px-2 py-1.5 rounded-lg text-xs font-semibold text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition border border-slate-200 dark:border-slate-700"
                title="Switch Language (বাংলা / English)"
              >
                <Globe className="w-3.5 h-3.5 text-sky-500" />
                <span>{language === 'bn' ? 'বাংলা' : 'EN'}</span>
              </button>
            </div>

            {/* Currency Selector */}
            <div className="hidden sm:block">
              <select
                value={currency}
                onChange={(e) => setCurrency(e.target.value as CurrencyCode)}
                className="bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-semibold rounded-lg px-2 py-1.5 text-slate-700 dark:text-slate-200 focus:outline-none focus:ring-1 focus:ring-sky-500 cursor-pointer"
                title="Select Currency"
              >
                <option value="BDT">BDT (৳)</option>
                <option value="USD">USD ($)</option>
                <option value="EUR">EUR (€)</option>
                <option value="GBP">GBP (£)</option>
              </select>
            </div>

            {/* Theme Toggle */}
            <button
              onClick={toggleTheme}
              className="p-1.5 rounded-lg text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition"
              title={theme === 'dark' ? t('light') : t('dark')}
            >
              {theme === 'dark' ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4 text-slate-600" />}
            </button>

            {/* If Logged in */}
            {currentUser ? (
              <>
                {/* Seller: Post Gig Button */}
                {isSeller && (
                  <button
                    onClick={onOpenCreateGig}
                    className="hidden sm:flex items-center gap-1 px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-semibold shadow-sm transition"
                  >
                    <PlusCircle className="w-3.5 h-3.5" />
                    <span>{t('createGig')}</span>
                  </button>
                )}

                {/* My Orders Button */}
                <button
                  onClick={() => onNavigate('orders')}
                  className="relative p-2 rounded-lg text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition"
                  title={t('myOrders')}
                >
                  <ShoppingBag className="w-4 h-4" />
                  {userActiveOrders.length > 0 && (
                    <span className="absolute top-1 right-1 w-4 h-4 bg-sky-600 text-white text-[9px] font-bold rounded-full flex items-center justify-center">
                      {userActiveOrders.length}
                    </span>
                  )}
                </button>

                {/* Notifications Bell */}
                <div className="relative">
                  <button
                    onClick={() => {
                      setNotifDropdownOpen(!notifDropdownOpen);
                      setUserDropdownOpen(false);
                    }}
                    className="relative p-2 rounded-lg text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition"
                    title={t('notifications')}
                  >
                    <Bell className="w-4 h-4" />
                    {unreadNotifs.length > 0 && (
                      <span className="absolute top-1 right-1 w-4 h-4 bg-rose-500 text-white text-[9px] font-bold rounded-full flex items-center justify-center animate-pulse">
                        {unreadNotifs.length}
                      </span>
                    )}
                  </button>

                  {/* Notifications Dropdown */}
                  {notifDropdownOpen && (
                    <div className="absolute right-0 mt-2 w-80 sm:w-96 bg-white dark:bg-slate-800 rounded-xl shadow-2xl border border-slate-200 dark:border-slate-700 py-3 z-50 animate-in fade-in">
                      <div className="flex items-center justify-between px-4 pb-2 border-b border-slate-100 dark:border-slate-700">
                        <span className="text-xs font-bold text-slate-800 dark:text-slate-200">
                          {t('notifications')} ({unreadNotifs.length})
                        </span>
                        {unreadNotifs.length > 0 && (
                          <button
                            onClick={markAllNotificationsRead}
                            className="text-[11px] text-sky-600 hover:underline font-medium"
                          >
                            Mark all read
                          </button>
                        )}
                      </div>

                      <div className="max-h-72 overflow-y-auto divide-y divide-slate-100 dark:divide-slate-700/50">
                        {notifications
                          .filter((n) => n.userId === currentUser.id)
                          .slice(0, 8)
                          .map((notif) => (
                            <div
                              key={notif.id}
                              onClick={() => {
                                markNotificationRead(notif.id);
                                if (notif.link) {
                                  onNavigate(notif.link.replace('/', ''));
                                  setNotifDropdownOpen(false);
                                }
                              }}
                              className={`p-3 text-left hover:bg-slate-50 dark:hover:bg-slate-700/50 cursor-pointer transition ${
                                !notif.isRead ? 'bg-sky-50/60 dark:bg-sky-950/30' : ''
                              }`}
                            >
                              <div className="flex items-start justify-between gap-1">
                                <div className="text-xs font-semibold text-slate-900 dark:text-slate-100">
                                  {language === 'bn' ? notif.titleBn : notif.titleEn}
                                </div>
                                <span className="text-[10px] text-slate-400 whitespace-nowrap">
                                  {new Date(notif.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                                </span>
                              </div>
                              <p className="text-[11px] text-slate-600 dark:text-slate-400 mt-0.5 line-clamp-2">
                                {language === 'bn' ? notif.messageBn : notif.messageEn}
                              </p>
                            </div>
                          ))}
                        {notifications.filter((n) => n.userId === currentUser.id).length === 0 && (
                          <div className="p-6 text-center text-xs text-slate-400">
                            {language === 'bn' ? 'কোনো নোটিফিকেশন নেই' : 'No notifications yet'}
                          </div>
                        )}
                      </div>
                    </div>
                  )}
                </div>

                {/* User Avatar & Dropdown */}
                <div className="relative">
                  <button
                    onClick={() => {
                      setUserDropdownOpen(!userDropdownOpen);
                      setNotifDropdownOpen(false);
                    }}
                    className="flex items-center gap-1.5 p-1 rounded-full hover:ring-2 hover:ring-sky-500 transition focus:outline-none"
                  >
                    <img
                      src={currentUser.avatar}
                      alt={currentUser.name}
                      className="w-8 h-8 rounded-full object-cover border border-slate-300 dark:border-slate-700"
                    />
                    <ChevronDown className="w-3 h-3 text-slate-500 hidden sm:block" />
                  </button>

                  {userDropdownOpen && (
                    <div className="absolute right-0 mt-2 w-56 bg-white dark:bg-slate-800 rounded-xl shadow-2xl border border-slate-200 dark:border-slate-700 py-2 z-50 animate-in fade-in">
                      <div className="px-4 py-2 border-b border-slate-100 dark:border-slate-700">
                        <div className="text-xs font-bold text-slate-900 dark:text-slate-100 truncate">
                          {currentUser.name}
                        </div>
                        <div className="text-[10px] text-slate-400 flex items-center gap-1 mt-0.5">
                          <span>@{currentUser.username}</span>
                          <span className="capitalize px-1.5 py-0.2 rounded bg-slate-100 dark:bg-slate-700 text-slate-700 dark:text-slate-300 text-[9px] font-bold">
                            {currentUser.role}
                          </span>
                        </div>
                      </div>

                      {/* Role Specific links */}
                      {isAdmin && (
                        <button
                          onClick={() => {
                            onNavigate('admin');
                            setUserDropdownOpen(false);
                          }}
                          className="w-full text-left px-4 py-2 text-xs font-semibold text-amber-600 dark:text-amber-400 hover:bg-amber-50 dark:hover:bg-slate-700 flex items-center gap-2"
                        >
                          <ShieldCheck className="w-4 h-4" />
                          <span>{t('adminPanel')}</span>
                        </button>
                      )}

                      <button
                        onClick={() => {
                          onNavigate('dashboard');
                          setUserDropdownOpen(false);
                        }}
                        className="w-full text-left px-4 py-2 text-xs text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-700 flex items-center gap-2"
                      >
                        <UserIcon className="w-4 h-4 text-sky-500" />
                        <span>{currentUser.role === 'seller' ? t('sellerDashboard') : t('buyerDashboard')}</span>
                      </button>

                      <button
                        onClick={() => {
                          onNavigate('orders');
                          setUserDropdownOpen(false);
                        }}
                        className="w-full text-left px-4 py-2 text-xs text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-700 flex items-center gap-2"
                      >
                        <ShoppingBag className="w-4 h-4 text-emerald-500" />
                        <span>{t('myOrders')}</span>
                      </button>

                      <button
                        onClick={() => {
                          onNavigate('messages');
                          setUserDropdownOpen(false);
                        }}
                        className="w-full text-left px-4 py-2 text-xs text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-700 flex items-center gap-2"
                      >
                        <span>💬</span>
                        <span>{t('messages')}</span>
                      </button>

                      <div className="border-t border-slate-100 dark:border-slate-700 my-1"></div>

                      <button
                        onClick={() => {
                          logout();
                          setUserDropdownOpen(false);
                        }}
                        className="w-full text-left px-4 py-2 text-xs text-rose-600 hover:bg-rose-50 dark:hover:bg-slate-700 flex items-center gap-2"
                      >
                        <LogOut className="w-4 h-4" />
                        <span>{t('logout')}</span>
                      </button>
                    </div>
                  )}
                </div>
              </>
            ) : (
              <div className="flex items-center gap-2">
                <button
                  onClick={() => onOpenAuth('login')}
                  className="px-3 py-1.5 text-xs font-semibold text-slate-700 dark:text-slate-200 hover:text-sky-600 dark:hover:text-sky-400 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition"
                >
                  {t('login')}
                </button>
                <button
                  onClick={() => onOpenAuth('register')}
                  className="px-3.5 py-1.5 bg-sky-600 hover:bg-sky-700 text-white text-xs font-semibold rounded-lg shadow-sm transition"
                >
                  {t('register')}
                </button>
              </div>
            )}

            {/* Mobile Hamburger */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="md:hidden p-2 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>

        {/* Mobile Navigation Drawer */}
        {mobileMenuOpen && (
          <div className="md:hidden py-3 border-t border-slate-200 dark:border-slate-800 space-y-2">
            <form onSubmit={handleSearchSubmit} className="mb-3">
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder={t('searchPlaceholder')}
                className="w-full px-3 py-2 bg-slate-100 dark:bg-slate-800 rounded-lg text-xs"
              />
            </form>
            <div className="grid grid-cols-2 gap-2 text-xs">
              <button
                onClick={() => {
                  onNavigate('home');
                  setMobileMenuOpen(false);
                }}
                className="p-2 text-left rounded bg-slate-50 dark:bg-slate-800"
              >
                🏠 {t('home')}
              </button>
              <button
                onClick={() => {
                  onNavigate('browse');
                  setMobileMenuOpen(false);
                }}
                className="p-2 text-left rounded bg-slate-50 dark:bg-slate-800"
              >
                🔍 {t('browseServices')}
              </button>
              {currentUser && (
                <>
                  <button
                    onClick={() => {
                      onNavigate('dashboard');
                      setMobileMenuOpen(false);
                    }}
                    className="p-2 text-left rounded bg-slate-50 dark:bg-slate-800"
                  >
                    📊 {t('dashboard')}
                  </button>
                  <button
                    onClick={() => {
                      onNavigate('orders');
                      setMobileMenuOpen(false);
                    }}
                    className="p-2 text-left rounded bg-slate-50 dark:bg-slate-800"
                  >
                    📦 {t('myOrders')}
                  </button>
                </>
              )}
            </div>
          </div>
        )}
      </div>
    </header>
  );
};
