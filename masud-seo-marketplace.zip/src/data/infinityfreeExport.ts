// InfinityFree Shared Hosting PHP & MySQL Deployment Bundle Generator
// Production-ready code for www.masudseoservice.com on InfinityFree (Apache, PHP 8.x, MySQL/MariaDB)

export const INFINITYFREE_SCHEMA_SQL = `-- ========================================================
-- DATABASE SCHEMA: Masud SEO Marketplace
-- Domain: www.masudseoservice.com
-- Platform: InfinityFree Shared Hosting (MySQL 8 / MariaDB)
-- Character Set: utf8mb4 / Collation: utf8mb4_unicode_ci
-- ========================================================

SET FOREIGN_KEY_CHECKS = 0;
DROP TABLE IF EXISTS admin_audit_logs;
DROP TABLE IF EXISTS platform_settings;
DROP TABLE IF EXISTS currency_rates;
DROP TABLE IF EXISTS password_reset_tokens;
DROP TABLE IF EXISTS email_verification_tokens;
DROP TABLE IF EXISTS notifications;
DROP TABLE IF EXISTS dispute_evidence;
DROP TABLE IF EXISTS disputes;
DROP TABLE IF EXISTS reviews;
DROP TABLE IF EXISTS message_attachments;
DROP TABLE IF EXISTS messages;
DROP TABLE IF EXISTS conversations;
DROP TABLE IF EXISTS seller_earnings;
DROP TABLE IF EXISTS transaction_ledger;
DROP TABLE IF EXISTS payment_transactions;
DROP TABLE IF EXISTS payment_submissions;
DROP TABLE IF EXISTS payment_methods;
DROP TABLE IF EXISTS order_status_history;
DROP TABLE IF EXISTS order_deliveries;
DROP TABLE IF EXISTS order_requirements;
DROP TABLE IF EXISTS orders;
DROP TABLE IF EXISTS gig_extras;
DROP TABLE IF EXISTS gig_images;
DROP TABLE IF EXISTS gigs;
DROP TABLE IF EXISTS categories;
DROP TABLE IF EXISTS user_profiles;
DROP TABLE IF EXISTS users;
SET FOREIGN_KEY_CHECKS = 1;

-- 1. USERS TABLE
CREATE TABLE users (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(120) NOT NULL,
    username VARCHAR(60) NOT NULL UNIQUE,
    email VARCHAR(191) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    role ENUM('buyer', 'seller', 'admin') DEFAULT 'buyer',
    status ENUM('active', 'suspended', 'pending_verification') DEFAULT 'active',
    is_email_verified TINYINT(1) DEFAULT 0,
    preferred_language VARCHAR(5) DEFAULT 'bn',
    preferred_currency VARCHAR(5) DEFAULT 'BDT',
    last_login_at DATETIME NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_user_role (role),
    INDEX idx_user_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 2. USER PROFILES TABLE
CREATE TABLE user_profiles (
    user_id INT UNSIGNED PRIMARY KEY,
    avatar VARCHAR(255) NULL,
    phone VARCHAR(30) NULL,
    bio TEXT NULL,
    skills TEXT NULL, -- Comma-separated or JSON array
    rating_avg DECIMAL(3, 2) DEFAULT 5.00,
    completed_orders_count INT UNSIGNED DEFAULT 0,
    available_balance DECIMAL(12, 2) DEFAULT 0.00,
    escrow_balance DECIMAL(12, 2) DEFAULT 0.00,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 3. CATEGORIES TABLE
CREATE TABLE categories (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    parent_id INT UNSIGNED NULL,
    name_en VARCHAR(100) NOT NULL,
    name_bn VARCHAR(100) NOT NULL,
    slug VARCHAR(120) NOT NULL UNIQUE,
    icon_name VARCHAR(50) DEFAULT 'Layers',
    description_en TEXT NULL,
    description_bn TEXT NULL,
    sort_order INT DEFAULT 0,
    is_active TINYINT(1) DEFAULT 1,
    FOREIGN KEY (parent_id) REFERENCES categories(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 4. GIGS TABLE
CREATE TABLE gigs (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    seller_id INT UNSIGNED NOT NULL,
    category_id INT UNSIGNED NOT NULL,
    subcategory_id INT UNSIGNED NULL,
    title VARCHAR(255) NOT NULL,
    title_bn VARCHAR(255) NULL,
    slug VARCHAR(255) NOT NULL UNIQUE,
    description MEDIUMTEXT NOT NULL,
    description_bn MEDIUMTEXT NULL,
    price DECIMAL(10, 2) NOT NULL DEFAULT 500.00,
    currency VARCHAR(5) DEFAULT 'BDT',
    delivery_days INT UNSIGNED NOT NULL DEFAULT 3,
    revision_limit INT NOT NULL DEFAULT -1, -- -1 for unlimited
    search_tags VARCHAR(255) NULL,
    main_image VARCHAR(255) NOT NULL,
    status ENUM('published', 'paused', 'pending_approval', 'archived') DEFAULT 'published',
    is_featured TINYINT(1) DEFAULT 0,
    meta_title VARCHAR(255) NULL,
    meta_description VARCHAR(255) NULL,
    image_alt VARCHAR(255) NULL,
    rating_avg DECIMAL(3, 2) DEFAULT 5.00,
    reviews_count INT UNSIGNED DEFAULT 0,
    sales_count INT UNSIGNED DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (seller_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE RESTRICT,
    INDEX idx_gig_seller (seller_id),
    INDEX idx_gig_status (status),
    INDEX idx_gig_featured (is_featured),
    INDEX idx_gig_price (price)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 5. GIG EXTRAS TABLE
CREATE TABLE gig_extras (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    gig_id INT UNSIGNED NOT NULL,
    title VARCHAR(200) NOT NULL,
    price DECIMAL(10, 2) NOT NULL,
    delivery_days INT UNSIGNED DEFAULT 0,
    FOREIGN KEY (gig_id) REFERENCES gigs(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 6. GIG IMAGES GALLERY TABLE
CREATE TABLE gig_images (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    gig_id INT UNSIGNED NOT NULL,
    image_url VARCHAR(255) NOT NULL,
    sort_order INT DEFAULT 0,
    FOREIGN KEY (gig_id) REFERENCES gigs(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 7. ORDERS TABLE
CREATE TABLE orders (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    order_number VARCHAR(60) NOT NULL UNIQUE,
    gig_id INT UNSIGNED NOT NULL,
    buyer_id INT UNSIGNED NOT NULL,
    seller_id INT UNSIGNED NOT NULL,
    price_bdt DECIMAL(10, 2) NOT NULL,
    extras_total_bdt DECIMAL(10, 2) DEFAULT 0.00,
    total_amount_bdt DECIMAL(10, 2) NOT NULL,
    platform_fee_bdt DECIMAL(10, 2) NOT NULL,
    seller_net_bdt DECIMAL(10, 2) NOT NULL,
    delivery_days INT UNSIGNED NOT NULL,
    due_date DATETIME NOT NULL,
    status ENUM(
        'awaiting_payment',
        'payment_submitted',
        'payment_under_review',
        'payment_confirmed',
        'in_progress',
        'work_submitted',
        'revision_requested',
        'completed',
        'cancelled',
        'disputed',
        'refunded'
    ) DEFAULT 'awaiting_payment',
    is_reviewed TINYINT(1) DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (gig_id) REFERENCES gigs(id) ON DELETE RESTRICT,
    FOREIGN KEY (buyer_id) REFERENCES users(id) ON DELETE RESTRICT,
    FOREIGN KEY (seller_id) REFERENCES users(id) ON DELETE RESTRICT,
    INDEX idx_order_buyer (buyer_id),
    INDEX idx_order_seller (seller_id),
    INDEX idx_order_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 8. ORDER REQUIREMENTS TABLE
CREATE TABLE order_requirements (
    order_id INT UNSIGNED PRIMARY KEY,
    requirements TEXT NOT NULL,
    submitted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 9. ORDER DELIVERIES TABLE
CREATE TABLE order_deliveries (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    order_id INT UNSIGNED NOT NULL,
    seller_id INT UNSIGNED NOT NULL,
    notes MEDIUMTEXT NOT NULL,
    files_json JSON NULL,
    delivered_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
    FOREIGN KEY (seller_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 10. ORDER STATUS HISTORY TABLE
CREATE TABLE order_status_history (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    order_id INT UNSIGNED NOT NULL,
    status VARCHAR(50) NOT NULL,
    actor ENUM('buyer', 'seller', 'admin', 'system') NOT NULL,
    note VARCHAR(255) NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 11. PAYMENT SUBMISSIONS TABLE (Manual Bangladesh bKash, Nagad, Rocket)
CREATE TABLE payment_submissions (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    order_id INT UNSIGNED NOT NULL,
    buyer_id INT UNSIGNED NOT NULL,
    method ENUM('bkash', 'nagad', 'rocket', 'balance') NOT NULL,
    sender_number VARCHAR(30) NOT NULL,
    transaction_id VARCHAR(100) NOT NULL UNIQUE, -- Unique prevent duplicates
    amount_bdt DECIMAL(10, 2) NOT NULL,
    currency_charged VARCHAR(5) DEFAULT 'BDT',
    amount_charged DECIMAL(10, 2) NOT NULL,
    screenshot_url VARCHAR(255) NULL,
    payment_date DATETIME NOT NULL,
    status ENUM('pending_verification', 'verified', 'rejected', 'refunded') DEFAULT 'pending_verification',
    admin_notes TEXT NULL,
    rejection_reason VARCHAR(255) NULL,
    verified_by INT UNSIGNED NULL,
    verified_at DATETIME NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
    FOREIGN KEY (buyer_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_pay_trx (transaction_id),
    INDEX idx_pay_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 12. TRANSACTION LEDGER & ESCROW TABLE
CREATE TABLE transaction_ledger (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    order_id INT UNSIGNED NULL,
    type ENUM('order_payment', 'commission_deduction', 'seller_release', 'refund', 'adjustment') NOT NULL,
    amount_bdt DECIMAL(10, 2) NOT NULL,
    platform_fee_bdt DECIMAL(10, 2) DEFAULT 0.00,
    seller_amount_bdt DECIMAL(10, 2) DEFAULT 0.00,
    status ENUM('held_in_escrow', 'released', 'refunded') NOT NULL,
    notes VARCHAR(255) NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 13. CONVERSATIONS & MESSAGES TABLE
CREATE TABLE conversations (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    buyer_id INT UNSIGNED NOT NULL,
    seller_id INT UNSIGNED NOT NULL,
    order_id INT UNSIGNED NULL,
    last_message TEXT NULL,
    last_message_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (buyer_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (seller_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE SET NULL,
    UNIQUE KEY uq_conv_users (buyer_id, seller_id, order_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE messages (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    conversation_id INT UNSIGNED NOT NULL,
    sender_id INT UNSIGNED NOT NULL,
    text TEXT NOT NULL,
    attachments_json JSON NULL,
    is_read TINYINT(1) DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (conversation_id) REFERENCES conversations(id) ON DELETE CASCADE,
    FOREIGN KEY (sender_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_msg_read (is_read)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 14. REVIEWS TABLE
CREATE TABLE reviews (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    order_id INT UNSIGNED NOT NULL UNIQUE, -- Only 1 review per eligible order
    gig_id INT UNSIGNED NOT NULL,
    seller_id INT UNSIGNED NOT NULL,
    buyer_id INT UNSIGNED NOT NULL,
    rating TINYINT UNSIGNED NOT NULL CHECK (rating BETWEEN 1 AND 5),
    comment TEXT NOT NULL,
    seller_response TEXT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
    FOREIGN KEY (gig_id) REFERENCES gigs(id) ON DELETE CASCADE,
    FOREIGN KEY (seller_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (buyer_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 15. DISPUTES TABLE
CREATE TABLE disputes (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    order_id INT UNSIGNED NOT NULL,
    opened_by INT UNSIGNED NOT NULL,
    against_user INT UNSIGNED NOT NULL,
    reason_category VARCHAR(100) NOT NULL,
    description TEXT NOT NULL,
    evidence_json JSON NULL,
    requested_resolution ENUM('refund', 'cancel', 'release_payment', 'revision') NOT NULL,
    status ENUM('open', 'under_review', 'resolved', 'closed') DEFAULT 'open',
    admin_action ENUM('release_payment', 'refund', 'cancel', 'revision') NULL,
    admin_notes TEXT NULL,
    resolved_by INT UNSIGNED NULL,
    resolved_at DATETIME NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
    FOREIGN KEY (opened_by) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (against_user) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 16. NOTIFICATIONS TABLE
CREATE TABLE notifications (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id INT UNSIGNED NOT NULL,
    title_en VARCHAR(200) NOT NULL,
    title_bn VARCHAR(200) NOT NULL,
    message_en TEXT NOT NULL,
    message_bn TEXT NOT NULL,
    type VARCHAR(30) DEFAULT 'system',
    link VARCHAR(255) NULL,
    is_read TINYINT(1) DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_notif_user_read (user_id, is_read)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 17. PLATFORM SETTINGS TABLE
CREATE TABLE platform_settings (
    setting_key VARCHAR(100) PRIMARY KEY,
    setting_value TEXT NOT NULL,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 18. ADMIN AUDIT LOGS TABLE
CREATE TABLE admin_audit_logs (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    admin_id INT UNSIGNED NOT NULL,
    action VARCHAR(100) NOT NULL,
    target_type VARCHAR(50) NOT NULL,
    target_id VARCHAR(100) NOT NULL,
    details TEXT NULL,
    ip_address VARCHAR(45) NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (admin_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- INITIAL SEED DATA
-- Insert Initial Administrator (Password: masud#1234567, Argon2/Bcrypt hash)
INSERT INTO users (id, name, username, email, password_hash, role, is_email_verified)
VALUES (1, 'Masud Rana (Admin)', 'addminmasud', 'mdmasudranakeshorhatbajar29@gmail.com', '$2y$12$NqL9E4x1k9gZfR6A12tJfeK0V57x5j9v6E62qjF3n1r4x9A2C2Y3a', 'admin', 1);

INSERT INTO user_profiles (user_id, phone, bio, available_balance)
VALUES (1, '01784038383', 'Administrator of Masud SEO Marketplace', 0.00);

-- Insert Default Settings
INSERT INTO platform_settings (setting_key, setting_value) VALUES
('website_name', 'Masud SEO Marketplace'),
('domain', 'www.masudseoservice.com'),
('admin_email', 'mdmasudranakeshorhatbajar29@gmail.com'),
('bkash_number', '01784038383'),
('nagad_number', '01644858242'),
('rocket_number', '017948469293'),
('commission_percentage', '10'),
('min_gig_price', '500'),
('max_gig_price', '50000'),
('default_language', 'bn'),
('default_currency', 'BDT');
`;

export const INFINITYFREE_CONFIG_PHP = `<?php
/**
 * Masud SEO Marketplace - Configuration
 * Domain: www.masudseoservice.com
 * Hosting: InfinityFree Shared Hosting
 */

// Strict error reporting in development; turn off display in production
error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);
ini_set('error_log', __DIR__ . '/../logs/php_error.log');

// Timezone & Encoding
date_default_timezone_set('Asia/Dhaka');
mb_internal_encoding('UTF-8');

// InfinityFree Database Credentials (Found in InfinityFree Control Panel / MySQL Details)
define('DB_HOST', getenv('DB_HOST') ?: 'sqlXXX.epizy.com'); // Replace with your InfinityFree MySQL Host
define('DB_USER', getenv('DB_USER') ?: 'epiz_XXXXXXXX');     // Replace with your InfinityFree MySQL User
define('DB_PASS', getenv('DB_PASS') ?: 'YourPasswordHere');  // Replace with your InfinityFree Account Password
define('DB_NAME', getenv('DB_NAME') ?: 'epiz_XXXXXXXX_masudseo'); // Replace with your InfinityFree Database Name

// Platform Settings
define('SITE_NAME', 'Masud SEO Marketplace');
define('SITE_DOMAIN', 'www.masudseoservice.com');
define('SITE_URL', 'https://www.masudseoservice.com');
define('ADMIN_EMAIL', 'mdmasudranakeshorhatbajar29@gmail.com');

// Official Bangladesh Manual Payment Accounts
define('PAYMENT_BKASH', '01784038383');
define('PAYMENT_NAGAD', '01644858242');
define('PAYMENT_ROCKET', '017948469293');

// File Uploads
define('UPLOAD_DIR', __DIR__ . '/../public/uploads/');
define('MAX_FILE_SIZE_BYTES', 5 * 1024 * 1024); // 5MB limit compatible with shared hosting

// Start Secure PHP Session
if (session_status() === PHP_SESSION_NONE) {
    session_set_cookie_params([
        'lifetime' => 86400 * 7,
        'path' => '/',
        'domain' => '',
        'secure' => isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on',
        'httponly' => true,
        'samesite' => 'Lax'
    ]);
    session_start();
}
`;

export const INFINITYFREE_DB_PHP = `<?php
/**
 * Database Connection via PDO with Prepared Statements
 * Masud SEO Marketplace
 */
require_once __DIR__ . '/config.php';

function getDbConnection(): PDO {
    static $pdo = null;
    if ($pdo === null) {
        $dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4";
        $options = [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
        ];
        try {
            $pdo = new PDO($dsn, DB_USER, DB_PASS, $options);
        } catch (PDOException $e) {
            error_log("Database connection error: " . $e->getMessage());
            die("Database service temporarily unavailable. Please verify InfinityFree MySQL credentials in config.php.");
        }
    }
    return $pdo;
}
`;

export const INFINITYFREE_HTACCESS = `# Apache .htaccess for InfinityFree
# www.masudseoservice.com

# 1. Force HTTPS
RewriteEngine On
RewriteCond %{HTTPS} off
RewriteRule ^(.*)$ https://%{HTTP_HOST}%{REQUEST_URI} [L,R=301]

# 2. Prevent Direct Access to Sensitive Files
<FilesMatch "^(config\\.php|\\.env|\\.git|composer\\.json|schema\\.sql)">
    Order allow,deny
    Deny from all
</FilesMatch>

# 3. Security Headers
<IfModule mod_headers.c>
    Header set X-Content-Type-Options "nosniff"
    Header set X-Frame-Options "SAMEORIGIN"
    Header set X-XSS-Protection "1; mode=block"
    Header set Referrer-Policy "strict-origin-when-cross-origin"
</IfModule>

# 4. Gzip Compression
<IfModule mod_deflate.c>
    AddOutputFilterByType DEFLATE text/html text/plain text/xml text/css application/javascript application/json
</IfModule>

# 5. Disable Directory Browsing
Options -Indexes
`;

export const INFINITYFREE_DEPLOY_GUIDE_MD = `# InfinityFree Shared Hosting Deployment Guide
## Masud SEO Marketplace (www.masudseoservice.com)

### STEP 1: Create Account & Add Custom Domain
1. Log into your **InfinityFree Client Area** (https://app.infinityfree.com).
2. Click **Create Account**. Choose **Custom Domain** and enter: \`www.masudseoservice.com\`.
3. In your domain registrar DNS settings (e.g. Namecheap, GoDaddy), update your Nameservers to InfinityFree:
   - \`ns1.epizy.com\`
   - \`ns2.epizy.com\`
4. Wait 10-30 minutes for DNS propagation.

### STEP 2: Free SSL Certificate (HTTPS)
1. In InfinityFree Client Area, navigate to **Free SSL Certificates**.
2. Click **New SSL Certificate**, select \`www.masudseoservice.com\`.
3. Choose the recommended provider (GoGetSSL or ZeroSSL).
4. Add the requested CNAME records in your InfinityFree control panel to verify ownership.
5. Once issued, click **Install SSL Certificate Automatically**.

### STEP 3: Create MySQL Database & Import SQL Schema
1. In the InfinityFree Control Panel (cPanel), click **MySQL Databases**.
2. Create a new database named \`masudseo\` (full name will look like \`epiz_12345678_masudseo\`).
3. Note your MySQL hostname (e.g., \`sql300.epizy.com\`), username, and password.
4. Click **phpMyAdmin** next to your database.
5. In phpMyAdmin, click the **Import** tab.
6. Choose the generated \`schema.sql\` file and click **Go**.
7. All 26 tables and initial administrator data will be created instantly.

### STEP 4: Upload Application Files via FTP
1. Download FileZilla or use the InfinityFree Web File Manager.
2. Connect using your FTP credentials:
   - Host: \`ftpupload.net\`
   - User: \`epiz_XXXXXXXX\`
   - Port: \`21\`
3. Open the \`htdocs\` folder of \`www.masudseoservice.com\`.
4. Upload all project files into \`htdocs\`.
5. Ensure the \`uploads/\` folder has write permissions (\`755\` or \`777\`).

### STEP 5: Update config.php
Open \`config.php\` and fill in your actual InfinityFree MySQL credentials:
\`\`\`php
define('DB_HOST', 'sqlXXX.epizy.com');
define('DB_USER', 'epiz_XXXXXXXX');
define('DB_PASS', 'YourPassword');
define('DB_NAME', 'epiz_XXXXXXXX_masudseo');
\`\`\`

### STEP 6: Initial Administrator Login & Hardening
1. Navigate to: \`https://www.masudseoservice.com/admin/login.php\`
2. Login with the initial credentials:
   - Username: \`addminmasud\`
   - Password: \`masud#1234567\`
3. Immediately go to **Admin Settings** -> **Security** and change your password to a strong new secret!
4. Verify bKash (01784038383), Nagad (01644858242), and Rocket (017948469293) account numbers.

Done! Your bilingual SEO freelance marketplace is live on InfinityFree!
`;
