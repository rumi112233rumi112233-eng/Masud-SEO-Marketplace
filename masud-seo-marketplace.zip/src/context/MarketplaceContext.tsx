import React, { createContext, useContext, useEffect, useState } from 'react';
import {
  AdminAuditLog,
  Category,
  Dispute,
  Gig,
  GigExtra,
  LedgerEntry,
  Message,
  Notification,
  Order,
  OrderStatus,
  PaymentMethod,
  PaymentSubmission,
  PlatformSettings,
  Review,
} from '../types';
import { useAuth } from './AuthContext';

export const INITIAL_CATEGORIES: Category[] = [
  {
    id: 'cat-backlinks',
    nameEn: 'Backlinks & Link Building',
    nameBn: 'ব্যাকলিংক ও লিংক বিল্ডিং',
    slug: 'backlinks',
    iconName: 'Link2',
    descriptionEn: 'High DA guest posts, contextual links, PBNs, edu/gov backlinks, and tier-2 link pyramids.',
    descriptionBn: 'উচ্চ ডিএ গেস্ট পোস্ট, প্রাসঙ্গিক ব্যাকলিংক, এডু ও গভ ব্যাকলিংক এবং লিংক পিরামিড।',
    subcategories: [
      { id: 'sub-guest-posts', nameEn: 'Guest Posts', nameBn: 'গেস্ট পোস্ট', slug: 'guest-posts' },
      { id: 'sub-contextual', nameEn: 'Contextual Backlinks', nameBn: 'কনটেক্সটুয়াল ব্যাকলিংক', slug: 'contextual' },
      { id: 'sub-edu-gov', nameEn: 'Edu & Gov Links', nameBn: 'এডু ও গভ লিংক', slug: 'edu-gov' },
      { id: 'sub-web20', nameEn: 'Web 2.0 Submissions', nameBn: 'ওয়েব ২.০ সাবমিশন', slug: 'web20' },
    ],
  },
  {
    id: 'cat-technical',
    nameEn: 'Technical & On-Page SEO',
    nameBn: 'টেকনিক্যাল ও অন-পেজ এসইও',
    slug: 'technical-seo',
    iconName: 'Code',
    descriptionEn: 'Full website audits, schema markup, XML sitemaps, robots.txt, canonicalization, and indexing.',
    descriptionBn: 'সম্পূর্ণ ওয়েবসাইট অডিট, স্কিমা মার্কআপ, এক্সএমএল সাইটম্যাপ, রোবটস ও ইনডেক্সিং সমাধান।',
    subcategories: [
      { id: 'sub-audit', nameEn: 'Full SEO Audit', nameBn: 'ফুল এসইও অডিট', slug: 'audit' },
      { id: 'sub-onpage', nameEn: 'On-Page Optimization', nameBn: 'অন-পেজ অপটিমাইজেশন', slug: 'onpage' },
      { id: 'sub-schema', nameEn: 'Schema & Rich Snippets', nameBn: 'স্কিমা ও রিচ স্নsnippet', slug: 'schema' },
    ],
  },
  {
    id: 'cat-speed',
    nameEn: 'Speed & Core Web Vitals',
    nameBn: 'ওয়েবসাইট স্পিড ও কোর ওয়েব ভাইটালস',
    slug: 'speed-optimization',
    iconName: 'Zap',
    descriptionEn: 'WordPress speed acceleration, caching, database cleanup, image compression, 90+ PageSpeed.',
    descriptionBn: 'ওয়ার্ডপ্রেস স্পিড অপটিমাইজেশন, ক্যাশিং, ইমেজ কম্প্রেস ও গুগল পেজস্পিড ৯০+ স্কোর।',
    subcategories: [
      { id: 'sub-wp-speed', nameEn: 'WordPress Speed Up', nameBn: 'ওয়ার্ডপ্রেস গতি বৃদ্ধি', slug: 'wp-speed' },
      { id: 'sub-core-vitals', nameEn: 'Core Web Vitals Fix', nameBn: 'কোর ওয়েব ভাইটালস ফিক্স', slug: 'core-vitals' },
    ],
  },
  {
    id: 'cat-content',
    nameEn: 'SEO Content & Copywriting',
    nameBn: 'এসইও কনটেন্ট ও কপিরাইটিং',
    slug: 'content-writing',
    iconName: 'FileText',
    descriptionEn: 'Plagiarism-free SEO articles, pillar posts, product reviews, and keyword-targeted copywriting.',
    descriptionBn: 'প্লেজিয়ারিজম-মুক্ত এসইও আর্টিকেল, পিলার কনটেন্ট ও প্রোডাক্ট রিভিউ লিখন।',
    subcategories: [
      { id: 'sub-blog-posts', nameEn: 'SEO Blog Posts', nameBn: 'এসইও ব্লগ পোস্ট', slug: 'blog-posts' },
      { id: 'sub-keyword-research', nameEn: 'Keyword Research', nameBn: 'কি-ওয়ার্ড রিসার্চ', slug: 'keyword-research' },
    ],
  },
  {
    id: 'cat-local',
    nameEn: 'Local SEO & Google Maps',
    nameBn: 'লোকাল এসইও ও গুগল ম্যাপস',
    slug: 'local-seo',
    iconName: 'MapPin',
    descriptionEn: 'Google Business Profile ranking, NAP local citations, geo-tagged photos, and map pins.',
    descriptionBn: 'গুগল বিজনেস প্রোফাইল র‍্যাংকিং, লোকাল সাইটেশন ও জিও-ট্যাগ ম্যাপ পিন।',
    subcategories: [
      { id: 'sub-gmb', nameEn: 'Google Business Profile', nameBn: 'গুগল বিজনেস প্রোফাইল', slug: 'gmb' },
      { id: 'sub-citations', nameEn: 'Local Citations', nameBn: 'লোকাল সাইটেশন', slug: 'citations' },
    ],
  },
];

export const INITIAL_GIGS: Gig[] = [
  {
    id: 'gig-1',
    sellerId: 'user-seller-1',
    sellerName: 'Tanvir Hossain',
    sellerAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80',
    sellerRating: 4.9,
    sellerCompletedOrders: 142,
    title: 'I will provide 50 High DA Dofollow Contextual Backlinks to Boost Google Ranking',
    titleBn: 'আমি ৫০টি হাই ডিএ ডুফলো প্রাসঙ্গিক ব্যাকলিংক তৈরি করে গুগল র‍্যাংকিং বৃদ্ধি করব',
    slug: '50-high-da-dofollow-backlinks',
    categoryId: 'cat-backlinks',
    subcategoryId: 'sub-contextual',
    description: 'Looking to safely skyrocket your organic search rankings? I build 100% white-hat, contextual, dofollow backlinks from aged high-authority websites (DA 50 to 80+). Every link is placed naturally inside niche-relevant 500+ word spun-free articles with low spam scores.\n\nWhat you get:\n• 50 permanent contextual dofollow links\n• DA 50+ guaranteed domains\n• Anchor text diversification\n• Full detailed Excel delivery report with live URLs & metrics\n• 100% Google Penguin & Helpful Content safe.',
    descriptionBn: 'আপনার ওয়েবসাইটের অর্গানিক সার্চ র‍্যাংকিং নিরাপদ উপায়ে বাড়াতে চান? আমি তৈরি করব ১০০% হোয়াইট-হ্যাট, হাই-অথরিটি (DA 50-80+) ওয়েবসাইট থেকে ডুফলো ব্যাকলিংক। প্রতিটি লিংক প্রাসঙ্গিক আর্টিকেলের ভেতর ন্যাচারালভাবে বসানো হবে।\n\nআপনি পাবেন:\n• ৫০টি স্থায়ী কনটেক্সচুয়াল ডুফলো লিংক\n• ডিএ ৫০+ নিশ্চিত ডোমেইন\n• লাইভ ইউআরএল সহ বিস্তারিত এক্সেল রিপোর্ট\n• গুগল অ্যালগরিদম ফ্রেন্ডলি ও নিরাপদ।',
    searchTags: ['backlinks', 'seo', 'dofollow', 'link building', 'google ranking'],
    price: 1500, // 1500 BDT
    deliveryDays: 5,
    revisionLimit: -1, // Unlimited
    includedWork: [
      '50 High DA Contextual Backlinks',
      'DA 50 to 85+ Guaranteed',
      'Anchor Text Diversity',
      'Detailed Excel Report with Live Links',
      'Tier 2 Indexing Ping Included',
    ],
    extras: [
      { id: 'extra-1', title: 'Express 2-Day Fast Delivery', price: 600, deliveryDays: 2 },
      { id: 'extra-2', title: 'Add 3 Premium DA 70+ Guest Posts', price: 1200, deliveryDays: 1 },
      { id: 'extra-3', title: 'Full Competitor Backlink Gap Analysis', price: 500, deliveryDays: 0 },
    ],
    faqs: [
      { question: 'Are these backlinks safe for new websites?', answer: 'Yes! All links are built with a gradual drip-feed technique that looks 100% natural to search engine crawlers.' },
      { question: 'What details do you need from me?', answer: 'Please send your target Website URL, 1 to 5 Target Keywords, and preferred anchor text instructions.' },
      { question: 'Do you provide a full work report?', answer: 'Yes, you will receive a downloadable Excel/Google Sheets report with live URLs, DA scores, and anchor texts.' },
    ],
    mainImage: 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=800&auto=format&fit=crop&q=80',
    galleryImages: [
      'https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=800&auto=format&fit=crop&q=80',
      'https://images.unsplash.com/photo-1504868584819-f8e8b4b6d7e3?w=800&auto=format&fit=crop&q=80',
    ],
    status: 'published',
    isFeatured: true,
    metaTitle: '50 High DA Dofollow Contextual Backlinks - Masud SEO Marketplace',
    metaDescription: 'Boost your website search visibility with 50 authoritative dofollow backlinks. Fast delivery, detailed Excel report, 100% safe white hat SEO.',
    imageAlt: 'High DA Backlinks Link Building Graphic',
    rating: 4.9,
    reviewsCount: 38,
    salesCount: 84,
    createdAt: '2026-03-01T10:00:00Z',
    updatedAt: '2026-03-15T12:00:00Z',
  },
  {
    id: 'gig-2',
    sellerId: 'user-seller-1',
    sellerName: 'Tanvir Hossain',
    sellerAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80',
    sellerRating: 4.9,
    sellerCompletedOrders: 142,
    title: 'I will Fix WordPress Speed & Core Web Vitals to Score 95+ on Google PageSpeed',
    titleBn: 'আমি ওয়ার্ডপ্রেস ওয়েবসাইটের স্পিড ও কোর ওয়েব ভাইটালস ফিক্স করে ৯৫+ পেজস্পিড এনে দেব',
    slug: 'fix-wordpress-speed-core-web-vitals',
    categoryId: 'cat-speed',
    subcategoryId: 'sub-wp-speed',
    description: 'Is your slow loading website losing buyers and dropping search ranks? A 1-second delay reduces conversions by 7%. I will optimize your WordPress site and achieve green 90-100 scores on Google PageSpeed Insights & GTmetrix.\n\nIncluded actions:\n• Image compression & Next-Gen WebP conversion\n• HTML/CSS/JS minification and deferring render-blocking scripts\n• Advanced caching configuration & CDN setup\n• Database cleanup and font optimization\n• LCP, FID/INP, and CLS core web vitals optimization.',
    descriptionBn: 'আপনার ধীরগতির ওয়েবসাইট কি গুগল র‍্যাংকিং ও কাস্টমার হারাচ্ছে? আমি আপনার ওয়ার্ডপ্রেস সাইটটি সম্পূর্ণ অপটিমাইজ করে গুগল পেজস্পিড ইনসাইটসে সবুজ ৯০-১০০ স্কোর নিশ্চিত করব।\n\nসুবিধাসমূহ:\n• ইমেজ সাইজ অপটিমাইজেশন ও WebP ফরম্যাট\n• CSS/JS মিনিফাই ও রেন্ডার ব্লকিং সমাধান\n• ক্যাশিং ও সিডিএন সেটআপ\n• কোর ওয়েব ভাইটালস (LCP, CLS, INP) সমাধান।',
    searchTags: ['wordpress speed', 'pagespeed', 'core web vitals', 'gtmetrix', 'cache'],
    price: 1200,
    deliveryDays: 3,
    revisionLimit: 3,
    includedWork: [
      'Google PageSpeed Score 90+ (Mobile & Desktop)',
      'Database Optimization & Redundant Table Cleanup',
      'Lossless Image Compression to WebP',
      'Render-Blocking JS/CSS Deferral',
      'Before & After GTmetrix PDF Benchmark Report',
    ],
    extras: [
      { id: 'extra-wp-1', title: 'WooCommerce Checkout Speed Tuning', price: 500, deliveryDays: 1 },
      { id: 'extra-wp-2', title: 'Cloudflare Pro CDN Configuration', price: 400, deliveryDays: 0 },
    ],
    faqs: [
      { question: 'Will my site design or functionality break?', answer: 'Never! We test in staging or backup first. Zero broken layout guaranteed.' },
      { question: 'Do you require WordPress admin login?', answer: 'Yes, temporary administrator access is needed to install optimizations and configure caching.' },
    ],
    mainImage: 'https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=800&auto=format&fit=crop&q=80',
    galleryImages: [],
    status: 'published',
    isFeatured: true,
    metaTitle: 'WordPress Speed & Core Web Vitals Optimization - Masud SEO',
    metaDescription: 'Accelerate WordPress loading speed to 95+ score on PageSpeed Insights and pass Core Web Vitals.',
    imageAlt: 'Website Speed Optimization Dashboard',
    rating: 5.0,
    reviewsCount: 29,
    salesCount: 46,
    createdAt: '2026-03-05T10:00:00Z',
    updatedAt: '2026-03-20T10:00:00Z',
  },
  {
    id: 'gig-3',
    sellerId: 'user-seller-1',
    sellerName: 'Tanvir Hossain',
    sellerAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80',
    sellerRating: 4.9,
    sellerCompletedOrders: 142,
    title: 'I will Build 100 Local SEO Citations & Google Map Pack Optimization',
    titleBn: 'আমি ১০০টি লোকাল সাইটেশন এবং গুগল ম্যাপ প্যাক অপটিমাইজেশন সার্ভিস প্রদান করব',
    slug: '100-local-seo-citations-google-maps',
    categoryId: 'cat-local',
    subcategoryId: 'sub-citations',
    description: 'Get your local business found on Google Maps top 3 pack! I manually build 100 high DA local directory citations with consistent NAP (Name, Address, Phone Number). Perfect for local businesses in Bangladesh, USA, UK, Canada, Australia, and worldwide.\n\n• 100% Manual submission on high PR directories (Yelp, YellowPages, Bing Places, etc.)\n• Geo-tagged photos & Google Map embeds\n• Free duplicate citation check\n• Full report with login details for every directory created.',
    descriptionBn: 'আপনার লোকাল ব্যবসাকে গুগল ম্যাপের টপ ৩ প্যাকে নিয়ে আসুন! আমি সম্পূর্ণ ম্যানুয়ালি ১০০টি হাই ডিএ লোকাল ডিরেক্টরি সাইটেশন তৈরি করব নিখুঁত NAP (নাম, ঠিকানা, ফোন) সমন্বয়ে।\n\n• ১০০% ম্যানুয়াল সাবমিশন\n• গুগল ম্যাপ এম্বেড ও জিও ট্যাগিং\n• ইউজারনেম ও পাসওয়ার্ড সহ পূর্ণাঙ্গ রিপোর্ট।',
    searchTags: ['local seo', 'citations', 'google maps', 'gmb', 'nap'],
    price: 1800,
    deliveryDays: 4,
    revisionLimit: -1,
    includedWork: [
      '100 High Domain Authority Citations',
      'Consistent NAP Details',
      'Geo-Tagged Business Photos',
      'Map Embeds on Web 2.0',
      'Excel Report with Login Credentials',
    ],
    extras: [
      { id: 'extra-local-1', title: 'Add 15,000 Google Map Driving Direction Points', price: 800, deliveryDays: 2 },
    ],
    faqs: [
      { question: 'Do I get the login accounts for each directory?', answer: 'Yes! The final spreadsheet includes every username and password so you own all listings.' },
    ],
    mainImage: 'https://images.unsplash.com/photo-1524661135-423995f22d0b?w=800&auto=format&fit=crop&q=80',
    galleryImages: [],
    status: 'published',
    isFeatured: true,
    metaTitle: '100 Local SEO Citations & Google Maps Optimization',
    metaDescription: 'Rank in Google 3-Pack with 100 manual local directory citations and map embeds.',
    imageAlt: 'Google Maps Local SEO Citations',
    rating: 4.8,
    reviewsCount: 19,
    salesCount: 31,
    createdAt: '2026-03-10T10:00:00Z',
    updatedAt: '2026-03-22T10:00:00Z',
  },
  {
    id: 'gig-4',
    sellerId: 'user-seller-1',
    sellerName: 'Tanvir Hossain',
    sellerAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80',
    sellerRating: 4.9,
    sellerCompletedOrders: 142,
    title: 'I will Perform In-Depth Technical SEO Audit with Actionable 40+ Page Roadmap',
    titleBn: 'আমি আপনার ওয়েবসাইটের নিখুঁত টেকনিক্যাল এসইও অডিট ও অ্যাকশনেবল রোডম্যাপ তৈরি করব',
    slug: 'technical-seo-audit-roadmap',
    categoryId: 'cat-technical',
    subcategoryId: 'sub-audit',
    description: 'Find out why your website is not ranking on Google Page 1. I will perform a comprehensive deep crawl using Screaming Frog, Ahrefs, and Semrush. You will receive an easy-to-understand PDF action roadmap identifying 404 broken links, canonical conflicts, duplicate meta tags, redirect chains, mobile usability errors, and indexation traps.',
    descriptionBn: 'আপনার ওয়েবসাইট কেন গুগলের প্রথম পেজে আসছে না তার কারণ জানুন। স্ক্রিমিং ফ্রগ, আহরেফস এবং সেমরাশ ব্যবহার করে নিখুঁত টেকনিক্যাল অডিট করব এবং সংশোধনের সুনির্দিষ্ট গাইডলাইন সমৃদ্ধ পিডিএফ রিপোর্ট দেব।',
    searchTags: ['seo audit', 'technical seo', 'screaming frog', 'ahrefs', 'indexing'],
    price: 1000,
    deliveryDays: 2,
    revisionLimit: 2,
    includedWork: [
      'Full Site Crawl Report (Up to 5,000 URLs)',
      'Schema Markup & Structured Data Audit',
      'Indexation & Robots.txt Verification',
      'Actionable Step-by-Step Priority Fix Sheet',
    ],
    extras: [],
    faqs: [],
    mainImage: 'https://images.unsplash.com/photo-1504868584819-f8e8b4b6d7e3?w=800&auto=format&fit=crop&q=80',
    galleryImages: [],
    status: 'published',
    isFeatured: false,
    metaTitle: 'Comprehensive Technical SEO Audit Report',
    metaDescription: 'Find and fix hidden crawl errors, broken tags, and ranking blockers with an expert SEO audit.',
    imageAlt: 'Technical SEO Audit Report Analytics',
    rating: 4.9,
    reviewsCount: 14,
    salesCount: 22,
    createdAt: '2026-03-12T10:00:00Z',
    updatedAt: '2026-03-24T10:00:00Z',
  },
];

export const INITIAL_SETTINGS: PlatformSettings = {
  websiteName: 'Masud SEO Marketplace',
  domain: 'www.masudseoservice.com',
  contactEmail: 'contact@masudseoservice.com',
  adminAlertEmail: 'mdmasudranakeshorhatbajar29@gmail.com',
  contactPhone: '+8801784038383',
  bkashNumber: '01784038383',
  nagadNumber: '01644858242',
  rocketNumber: '017948469293',
  commissionPercentage: 10, // 10% marketplace commission
  minGigPriceBDT: 300,
  maxGigPriceBDT: 50000,
  requireGigApproval: false,
  maintenanceMode: false,
  defaultLanguage: 'bn',
  defaultCurrency: 'BDT',
};

const INITIAL_ORDERS: Order[] = [
  {
    id: 'ord-101',
    orderNumber: 'MSD-2026-8941',
    gigId: 'gig-1',
    gigTitle: 'I will provide 50 High DA Dofollow Contextual Backlinks to Boost Google Ranking',
    gigImage: 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=800&auto=format&fit=crop&q=80',
    buyerId: 'user-buyer-1',
    buyerName: 'Shafiul Islam',
    buyerAvatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&auto=format&fit=crop&q=80',
    sellerId: 'user-seller-1',
    sellerName: 'Tanvir Hossain',
    sellerAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80',
    priceBDT: 1500,
    selectedExtras: [{ id: 'extra-1', title: 'Express 2-Day Fast Delivery', price: 600, deliveryDays: 2 }],
    totalAmountBDT: 2100,
    platformFeeBDT: 210, // 10%
    sellerNetBDT: 1890,
    status: 'in_progress',
    requirements: 'Target Website: https://shafiulecommerce.com\nKeywords: "buy organic honey bangladesh", "pure mustard oil"\nAnchor preference: 60% brand, 40% exact keyword.',
    deliveryDays: 2,
    dueDate: new Date(Date.now() + 2 * 24 * 60 * 60 * 1000).toISOString(),
    paymentSubmission: {
      id: 'pay-sub-1',
      orderId: 'ord-101',
      buyerId: 'user-buyer-1',
      buyerName: 'Shafiul Islam',
      method: 'bkash',
      senderNumber: '01899887766',
      transactionId: 'BK9J8A7K6L',
      amountBDT: 2100,
      currencyCharged: 'BDT',
      amountCharged: 2100,
      paymentDate: '2026-03-25T14:30:00Z',
      status: 'verified',
      verifiedAt: '2026-03-25T14:45:00Z',
      verifiedBy: 'addminmasud',
      adminNotes: 'Transaction verified in bKash statement.',
      createdAt: '2026-03-25T14:30:00Z',
    },
    deliveries: [],
    revisionRequests: [],
    statusHistory: [
      { status: 'awaiting_payment', timestamp: '2026-03-25T14:20:00Z', actor: 'buyer' },
      { status: 'payment_submitted', timestamp: '2026-03-25T14:30:00Z', actor: 'buyer', note: 'bKash TrxID: BK9J8A7K6L' },
      { status: 'payment_confirmed', timestamp: '2026-03-25T14:45:00Z', actor: 'admin', note: 'Payment verified by Admin Masud' },
      { status: 'in_progress', timestamp: '2026-03-25T14:46:00Z', actor: 'system', note: 'Seller started working.' },
    ],
    createdAt: '2026-03-25T14:20:00Z',
    updatedAt: '2026-03-25T14:46:00Z',
  },
];

const GIGS_KEY = 'masud_seo_gigs';
const ORDERS_KEY = 'masud_seo_orders';
const SETTINGS_KEY = 'masud_seo_settings';
const NOTIFICATIONS_KEY = 'masud_seo_notifications';
const MESSAGES_KEY = 'masud_seo_messages';
const DISPUTES_KEY = 'masud_seo_disputes';
const REVIEWS_KEY = 'masud_seo_reviews';
const LEDGER_KEY = 'masud_seo_ledger';
const AUDIT_KEY = 'masud_seo_audit';

interface MarketplaceContextType {
  categories: Category[];
  gigs: Gig[];
  orders: Order[];
  settings: PlatformSettings;
  notifications: Notification[];
  messages: Message[];
  disputes: Dispute[];
  reviews: Review[];
  ledger: LedgerEntry[];
  auditLogs: AdminAuditLog[];
  // Gig actions
  createGig: (gigData: Partial<Gig>) => Gig;
  updateGig: (id: string, gigData: Partial<Gig>) => void;
  deleteGig: (id: string) => void;
  toggleGigStatus: (id: string, newStatus: 'published' | 'paused') => void;
  // Order actions
  createOrder: (gigId: string, selectedExtras: GigExtra[], requirements: string) => Order;
  submitOrderPayment: (
    orderId: string,
    method: PaymentMethod,
    senderNumber: string,
    transactionId: string,
    amountBDT: number,
    screenshotUrl?: string
  ) => { success: boolean; message: string };
  // Admin payment verification
  verifyOrderPayment: (orderId: string, adminNotes?: string) => void;
  rejectOrderPayment: (orderId: string, reason: string) => void;
  // Seller delivery & buyer approval
  deliverOrderWork: (orderId: string, notes: string, workFiles: { name: string; url: string; size?: string }[]) => void;
  requestOrderRevision: (orderId: string, revisionNote: string) => void;
  acceptOrderDelivery: (orderId: string) => void;
  // Review actions
  submitReview: (orderId: string, rating: number, comment: string) => { success: boolean; message: string };
  // Dispute actions
  openDispute: (orderId: string, reasonCategory: string, description: string, requestedResolution: 'refund' | 'cancel' | 'release_payment' | 'revision') => void;
  resolveDispute: (disputeId: string, action: 'release_payment' | 'refund' | 'cancel' | 'revision', notes: string) => void;
  // Messaging actions
  sendMessage: (recipientId: string, text: string, orderId?: string, attachment?: { name: string; url: string }) => void;
  markMessagesRead: (partnerId: string) => void;
  // Settings & admin
  updateSettings: (newSettings: Partial<PlatformSettings>) => void;
  markNotificationRead: (id: string) => void;
  markAllNotificationsRead: () => void;
}

const MarketplaceContext = createContext<MarketplaceContextType | undefined>(undefined);

export const MarketplaceProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { currentUser, updateProfile } = useAuth();

  const [categories] = useState<Category[]>(INITIAL_CATEGORIES);

  const [gigs, setGigs] = useState<Gig[]>(() => {
    const saved = localStorage.getItem(GIGS_KEY);
    return saved ? JSON.parse(saved) : INITIAL_GIGS;
  });

  const [orders, setOrders] = useState<Order[]>(() => {
    const saved = localStorage.getItem(ORDERS_KEY);
    return saved ? JSON.parse(saved) : INITIAL_ORDERS;
  });

  const [settings, setSettings] = useState<PlatformSettings>(() => {
    const saved = localStorage.getItem(SETTINGS_KEY);
    return saved ? JSON.parse(saved) : INITIAL_SETTINGS;
  });

  const [notifications, setNotifications] = useState<Notification[]>(() => {
    const saved = localStorage.getItem(NOTIFICATIONS_KEY);
    return saved
      ? JSON.parse(saved)
      : [
          {
            id: 'notif-1',
            userId: 'user-buyer-1',
            titleEn: 'Order Payment Verified!',
            titleBn: 'অর্ডার পেমেন্ট সফলভাবে যাচাই হয়েছে!',
            messageEn: 'Your bKash payment for order MSD-2026-8941 was verified. Seller is working.',
            messageBn: 'অর্ডার MSD-2026-8941 এর জন্য আপনার বিকাশ পেমেন্ট অনুমোদিত হয়েছে। সেলার কাজ শুরু করেছেন।',
            type: 'payment',
            link: '/orders',
            isRead: false,
            createdAt: new Date().toISOString(),
          },
        ];
  });

  const [messages, setMessages] = useState<Message[]>(() => {
    const saved = localStorage.getItem(MESSAGES_KEY);
    return saved
      ? JSON.parse(saved)
      : [
          {
            id: 'msg-1',
            conversationId: 'conv-seller-buyer',
            senderId: 'user-seller-1',
            senderName: 'Tanvir Hossain',
            senderAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80',
            senderRole: 'seller',
            text: 'Hello Shafiul! I have received your target keywords and started building the first batch of high DA contextual backlinks.',
            orderId: 'ord-101',
            isRead: true,
            createdAt: '2026-03-25T15:00:00Z',
          },
        ];
  });

  const [disputes, setDisputes] = useState<Dispute[]>(() => {
    const saved = localStorage.getItem(DISPUTES_KEY);
    return saved ? JSON.parse(saved) : [];
  });

  const [reviews, setReviews] = useState<Review[]>(() => {
    const saved = localStorage.getItem(REVIEWS_KEY);
    return saved
      ? JSON.parse(saved)
      : [
          {
            id: 'rev-1',
            orderId: 'ord-old-1',
            gigId: 'gig-1',
            sellerId: 'user-seller-1',
            buyerId: 'user-buyer-1',
            buyerName: 'Shafiul Islam',
            buyerAvatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&auto=format&fit=crop&q=80',
            rating: 5,
            comment: 'Fantastic service! The backlinks increased my organic impressions by 45% in just 3 weeks. Genuine DA 55+ sites. Will order again!',
            createdAt: '2026-03-18T10:00:00Z',
          },
        ];
  });

  const [ledger, setLedger] = useState<LedgerEntry[]>(() => {
    const saved = localStorage.getItem(LEDGER_KEY);
    return saved
      ? JSON.parse(saved)
      : [
          {
            id: 'led-1',
            orderId: 'ord-101',
            type: 'order_payment',
            amountBDT: 2100,
            platformFeeBDT: 210,
            sellerAmountBDT: 1890,
            status: 'held_in_escrow',
            notes: 'Payment confirmed via bKash. Funds held safely in escrow pending delivery.',
            createdAt: '2026-03-25T14:45:00Z',
          },
        ];
  });

  const [auditLogs, setAuditLogs] = useState<AdminAuditLog[]>(() => {
    const saved = localStorage.getItem(AUDIT_KEY);
    return saved
      ? JSON.parse(saved)
      : [
          {
            id: 'aud-1',
            adminId: 'user-admin-1',
            adminUsername: 'addminmasud',
            action: 'VERIFY_PAYMENT',
            targetType: 'payment',
            targetId: 'BK9J8A7K6L',
            details: 'Verified bKash manual payment ৳2,100 for order MSD-2026-8941',
            createdAt: '2026-03-25T14:45:00Z',
          },
        ];
  });

  // Persist states
  useEffect(() => localStorage.setItem(GIGS_KEY, JSON.stringify(gigs)), [gigs]);
  useEffect(() => localStorage.setItem(ORDERS_KEY, JSON.stringify(orders)), [orders]);
  useEffect(() => localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings)), [settings]);
  useEffect(() => localStorage.setItem(NOTIFICATIONS_KEY, JSON.stringify(notifications)), [notifications]);
  useEffect(() => localStorage.setItem(MESSAGES_KEY, JSON.stringify(messages)), [messages]);
  useEffect(() => localStorage.setItem(DISPUTES_KEY, JSON.stringify(disputes)), [disputes]);
  useEffect(() => localStorage.setItem(REVIEWS_KEY, JSON.stringify(reviews)), [reviews]);
  useEffect(() => localStorage.setItem(LEDGER_KEY, JSON.stringify(ledger)), [ledger]);
  useEffect(() => localStorage.setItem(AUDIT_KEY, JSON.stringify(auditLogs)), [auditLogs]);

  // Push notifications helper
  const notifyUser = (
    userId: string,
    titleEn: string,
    titleBn: string,
    messageEn: string,
    messageBn: string,
    type: Notification['type'] = 'system',
    link?: string
  ) => {
    const newNotif: Notification = {
      id: `notif-${Date.now()}`,
      userId,
      titleEn,
      titleBn,
      messageEn,
      messageBn,
      type,
      link,
      isRead: false,
      createdAt: new Date().toISOString(),
    };
    setNotifications((prev) => [newNotif, ...prev]);
  };

  const addAudit = (action: string, targetType: AdminAuditLog['targetType'], targetId: string, details: string) => {
    const log: AdminAuditLog = {
      id: `aud-${Date.now()}`,
      adminId: currentUser?.id || 'admin',
      adminUsername: currentUser?.username || 'addminmasud',
      action,
      targetType,
      targetId,
      details,
      createdAt: new Date().toISOString(),
    };
    setAuditLogs((prev) => [log, ...prev]);
  };

  // 1. Gig CRUD
  const createGig = (gigData: Partial<Gig>): Gig => {
    const newGig: Gig = {
      id: `gig-${Date.now()}`,
      sellerId: currentUser?.id || 'user-seller-1',
      sellerName: currentUser?.name || 'Seller',
      sellerAvatar: currentUser?.avatar || 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150',
      sellerRating: currentUser?.rating || 5.0,
      sellerCompletedOrders: currentUser?.completedOrdersCount || 0,
      title: gigData.title || 'I will provide professional SEO service',
      titleBn: gigData.titleBn || '',
      slug: (gigData.title || 'seo-service')
        .toLowerCase()
        .replace(/[^a-z0-9]+/g, '-')
        .replace(/(^-|-$)+/g, '') + `-${Date.now().toString().slice(-4)}`,
      categoryId: gigData.categoryId || 'cat-backlinks',
      subcategoryId: gigData.subcategoryId,
      description: gigData.description || '',
      descriptionBn: gigData.descriptionBn,
      searchTags: gigData.searchTags || ['seo', 'backlinks'],
      price: Math.max(Number(gigData.price) || 500, settings.minGigPriceBDT),
      deliveryDays: Number(gigData.deliveryDays) || 3,
      revisionLimit: Number(gigData.revisionLimit) ?? -1,
      includedWork: gigData.includedWork || ['High Quality Manual Execution', 'Detailed Report'],
      extras: gigData.extras || [],
      faqs: gigData.faqs || [],
      mainImage: gigData.mainImage || 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=800',
      galleryImages: gigData.galleryImages || [],
      status: settings.requireGigApproval ? 'pending_approval' : 'published',
      isFeatured: false,
      metaTitle: gigData.metaTitle || gigData.title,
      metaDescription: gigData.metaDescription || gigData.description?.slice(0, 150),
      imageAlt: gigData.imageAlt || gigData.title,
      rating: 5.0,
      reviewsCount: 0,
      salesCount: 0,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    setGigs((prev) => [newGig, ...prev]);

    notifyUser(
      newGig.sellerId,
      'Gig Published Successfully',
      'আপনার গিগ সফলভাবে তৈরি হয়েছে',
      `Your service "${newGig.title}" is now live on the marketplace.`,
      `আপনার সার্ভিস "${newGig.title}" এখন মার্কেটপ্লেসে লাইভ।`,
      'system'
    );

    return newGig;
  };

  const updateGig = (id: string, gigData: Partial<Gig>) => {
    setGigs((prev) =>
      prev.map((g) => (g.id === id ? { ...g, ...gigData, updatedAt: new Date().toISOString() } : g))
    );
  };

  const deleteGig = (id: string) => {
    // Soft delete to protect financial/order history
    setGigs((prev) => prev.map((g) => (g.id === id ? { ...g, status: 'archived' } : g)));
  };

  const toggleGigStatus = (id: string, newStatus: 'published' | 'paused') => {
    setGigs((prev) => prev.map((g) => (g.id === id ? { ...g, status: newStatus } : g)));
  };

  // 2. Orders Lifecycle
  const createOrder = (gigId: string, selectedExtras: GigExtra[], requirements: string): Order => {
    const gig = gigs.find((g) => g.id === gigId);
    if (!gig) throw new Error('Gig not found');

    const extrasTotal = selectedExtras.reduce((sum, ext) => sum + ext.price, 0);
    const totalAmountBDT = gig.price + extrasTotal;
    const platformFeeBDT = Math.round((totalAmountBDT * settings.commissionPercentage) / 100);
    const sellerNetBDT = totalAmountBDT - platformFeeBDT;

    const extraDays = selectedExtras.reduce((sum, ext) => sum + ext.deliveryDays, 0);
    const totalDays = gig.deliveryDays + extraDays;
    const dueDate = new Date(Date.now() + totalDays * 24 * 60 * 60 * 1000).toISOString();

    const orderNumber = `MSD-${new Date().getFullYear()}-${Math.floor(1000 + Math.random() * 9000)}`;

    const newOrder: Order = {
      id: `ord-${Date.now()}`,
      orderNumber,
      gigId: gig.id,
      gigTitle: gig.title,
      gigImage: gig.mainImage,
      buyerId: currentUser?.id || 'guest',
      buyerName: currentUser?.name || 'Buyer',
      buyerAvatar: currentUser?.avatar || 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150',
      sellerId: gig.sellerId,
      sellerName: gig.sellerName,
      sellerAvatar: gig.sellerAvatar,
      priceBDT: gig.price,
      selectedExtras,
      totalAmountBDT,
      platformFeeBDT,
      sellerNetBDT,
      status: 'awaiting_payment',
      requirements,
      deliveryDays: totalDays,
      dueDate,
      deliveries: [],
      revisionRequests: [],
      statusHistory: [
        {
          status: 'awaiting_payment',
          timestamp: new Date().toISOString(),
          actor: 'buyer',
          note: `Order created. Payable: ৳${totalAmountBDT}`,
        },
      ],
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    setOrders((prev) => [newOrder, ...prev]);

    // Send notifications to buyer and seller
    notifyUser(
      newOrder.buyerId,
      `Order ${orderNumber} Created`,
      `অর্ডার ${orderNumber} তৈরি হয়েছে`,
      `Please submit your bKash, Nagad, or Rocket TrxID to start your order.`,
      `কাজ শুরুর জন্য অনুগ্রহ করে বিকাশ, নগদ বা রকেট TrxID সাবমিট করুন।`,
      'order',
      '/orders'
    );

    notifyUser(
      newOrder.sellerId,
      `New Pending Order Received: ${orderNumber}`,
      `নতুন অর্ডার এসেছে: ${orderNumber}`,
      `A buyer placed an order for "${gig.title}". Work will begin once payment is verified.`,
      `"${gig.title}" এর জন্য একটি নতুন অর্ডার এসেছে। পেমেন্ট যাচাই হওয়ার পর কাজ শুরু হবে।`,
      'order',
      '/orders'
    );

    return newOrder;
  };

  // 3. Submit Payment with duplicate TrxID prevention
  const submitOrderPayment = (
    orderId: string,
    method: PaymentMethod,
    senderNumber: string,
    transactionId: string,
    amountBDT: number,
    screenshotUrl?: string
  ): { success: boolean; message: string } => {
    const cleanTrxId = transactionId.trim().toUpperCase();
    const cleanSender = senderNumber.trim();

    if (!cleanTrxId || !cleanSender) {
      return { success: false, message: 'Please enter both sender mobile number and transaction ID.' };
    }

    // Check duplicate TrxID across all past submissions
    const isDuplicate = orders.some((ord) => {
      return (
        ord.paymentSubmission?.transactionId.toUpperCase() === cleanTrxId &&
        ord.id !== orderId &&
        ord.paymentSubmission.status !== 'rejected'
      );
    });

    if (isDuplicate) {
      return {
        success: false,
        message: 'This Transaction ID (TrxID) has already been submitted for another order. Please check your SMS.',
      };
    }

    const submission: PaymentSubmission = {
      id: `pay-${Date.now()}`,
      orderId,
      buyerId: currentUser?.id || 'buyer',
      buyerName: currentUser?.name || 'Buyer',
      method,
      senderNumber: cleanSender,
      transactionId: cleanTrxId,
      amountBDT,
      currencyCharged: 'BDT',
      amountCharged: amountBDT,
      screenshotUrl,
      paymentDate: new Date().toISOString(),
      status: 'pending_verification',
      createdAt: new Date().toISOString(),
    };

    setOrders((prev) =>
      prev.map((ord) => {
        if (ord.id === orderId) {
          return {
            ...ord,
            status: 'payment_submitted',
            paymentSubmission: submission,
            statusHistory: [
              ...ord.statusHistory,
              {
                status: 'payment_submitted',
                timestamp: new Date().toISOString(),
                actor: 'buyer',
                note: `Submitted ${method.toUpperCase()} TrxID: ${cleanTrxId} from ${cleanSender}`,
              },
            ],
            updatedAt: new Date().toISOString(),
          };
        }
        return ord;
      })
    );

    // Notify Administrator (mdmasudranakeshorhatbajar29@gmail.com)
    notifyUser(
      'user-admin-1',
      `Payment Verification Required: TrxID ${cleanTrxId}`,
      `পেমেন্ট যাচাই প্রয়োজন: TrxID ${cleanTrxId}`,
      `Buyer submitted ৳${amountBDT} via ${method.toUpperCase()} for order. Please verify in statement.`,
      `বায়ার ৳${amountBDT} (${method.toUpperCase()}) পাঠিয়েছেন। ওয়ালেট ব্যালেন্স মিলিয়ে অনুমোদন করুন।`,
      'payment',
      '/admin/payments'
    );

    return {
      success: true,
      message: 'Transaction ID submitted successfully! Our admin team is verifying your payment.',
    };
  };

  // 4. Admin Payment Verification
  const verifyOrderPayment = (orderId: string, adminNotes: string = 'Payment verified in wallet statement.') => {
    const order = orders.find((o) => o.id === orderId);
    if (!order || !order.paymentSubmission) return;

    setOrders((prev) =>
      prev.map((ord) => {
        if (ord.id === orderId && ord.paymentSubmission) {
          const verifiedSub: PaymentSubmission = {
            ...ord.paymentSubmission,
            status: 'verified',
            adminNotes,
            verifiedAt: new Date().toISOString(),
            verifiedBy: currentUser?.username || 'addminmasud',
          };

          return {
            ...ord,
            status: 'in_progress', // Escrow confirmed & work starts
            paymentSubmission: verifiedSub,
            statusHistory: [
              ...ord.statusHistory,
              {
                status: 'payment_confirmed',
                timestamp: new Date().toISOString(),
                actor: 'admin',
                note: `Payment confirmed by Admin: ${adminNotes}`,
              },
              {
                status: 'in_progress',
                timestamp: new Date().toISOString(),
                actor: 'system',
                note: 'Order active. Seller can now work on requirements.',
              },
            ],
            updatedAt: new Date().toISOString(),
          };
        }
        return ord;
      })
    );

    // Record in Escrow Ledger
    const ledgerEntry: LedgerEntry = {
      id: `led-${Date.now()}`,
      orderId: order.id,
      type: 'order_payment',
      amountBDT: order.totalAmountBDT,
      platformFeeBDT: order.platformFeeBDT,
      sellerAmountBDT: order.sellerNetBDT,
      status: 'held_in_escrow',
      notes: `Payment ৳${order.totalAmountBDT} confirmed for ${order.orderNumber}. ৳${order.sellerNetBDT} placed in Escrow protection.`,
      createdAt: new Date().toISOString(),
    };
    setLedger((prev) => [ledgerEntry, ...prev]);

    // Admin Audit Log
    addAudit(
      'VERIFY_PAYMENT',
      'payment',
      order.paymentSubmission.transactionId,
      `Verified payment ৳${order.totalAmountBDT} for order ${order.orderNumber}`
    );

    // Notify Buyer and Seller
    notifyUser(
      order.buyerId,
      `Payment Approved for Order ${order.orderNumber}`,
      `অর্ডার ${order.orderNumber} এর পেমেন্ট অনুমোদিত হয়েছে`,
      `Your payment of ৳${order.totalAmountBDT} has been verified and safely placed in escrow. The seller has started your work!`,
      `আপনার ৳${order.totalAmountBDT} পেমেন্ট যাচাই করে এসক্রোতে রাখা হয়েছে। সেলার কাজ শুরু করেছেন!`,
      'payment',
      '/orders'
    );

    notifyUser(
      order.sellerId,
      `Payment Confirmed: Start Order ${order.orderNumber}`,
      `পেমেন্ট নিশ্চিত হয়েছে: কাজ শুরু করুন (${order.orderNumber})`,
      `Buyer payment of ৳${order.totalAmountBDT} is verified in escrow. Please review instructions and deliver before the deadline.`,
      `বায়ারের পেমেন্ট এসক্রোতে এসে গেছে। রিকোয়ারমেন্টস দেখে নির্ধারিত সময়ের মধ্যে কাজ জমা দিন।`,
      'order',
      '/orders'
    );
  };

  const rejectOrderPayment = (orderId: string, reason: string) => {
    const order = orders.find((o) => o.id === orderId);
    if (!order || !order.paymentSubmission) return;

    setOrders((prev) =>
      prev.map((ord) => {
        if (ord.id === orderId && ord.paymentSubmission) {
          const rejectedSub: PaymentSubmission = {
            ...ord.paymentSubmission,
            status: 'rejected',
            rejectionReason: reason,
          };

          return {
            ...ord,
            status: 'awaiting_payment',
            paymentSubmission: rejectedSub,
            statusHistory: [
              ...ord.statusHistory,
              {
                status: 'awaiting_payment',
                timestamp: new Date().toISOString(),
                actor: 'admin',
                note: `Payment rejected by admin. Reason: ${reason}`,
              },
            ],
            updatedAt: new Date().toISOString(),
          };
        }
        return ord;
      })
    );

    addAudit(
      'REJECT_PAYMENT',
      'payment',
      order.paymentSubmission.transactionId,
      `Rejected TrxID ${order.paymentSubmission.transactionId} for order ${order.orderNumber}. Reason: ${reason}`
    );

    notifyUser(
      order.buyerId,
      `Payment Verification Failed: Order ${order.orderNumber}`,
      `পেমেন্ট যাচাই ব্যর্থ হয়েছে: অর্ডার ${order.orderNumber}`,
      `Your transaction ID was rejected by admin: "${reason}". Please check your bKash/Nagad/Rocket SMS and resubmit.`,
      `আপনার TrxID অ্যাডমিন কর্তৃক প্রত্যাখ্যাত হয়েছে: "${reason}"। সঠিক তথ্য দিয়ে পুনরায় জমা দিন।`,
      'payment',
      '/orders'
    );
  };

  // 5. Work Delivery
  const deliverOrderWork = (
    orderId: string,
    notes: string,
    workFiles: { name: string; url: string; size?: string }[]
  ) => {
    const order = orders.find((o) => o.id === orderId);
    if (!order) return;

    const delivery = {
      id: `del-${Date.now()}`,
      orderId,
      sellerId: order.sellerId,
      notes,
      workFiles,
      deliveredAt: new Date().toISOString(),
    };

    setOrders((prev) =>
      prev.map((ord) => {
        if (ord.id === orderId) {
          return {
            ...ord,
            status: 'work_submitted',
            deliveries: [delivery, ...ord.deliveries],
            statusHistory: [
              ...ord.statusHistory,
              {
                status: 'work_submitted',
                timestamp: new Date().toISOString(),
                actor: 'seller',
                note: `Work delivered: ${notes.slice(0, 100)}...`,
              },
            ],
            updatedAt: new Date().toISOString(),
          };
        }
        return ord;
      })
    );

    notifyUser(
      order.buyerId,
      `Work Delivered for Order ${order.orderNumber}`,
      `অর্ডার ${order.orderNumber} এর কাজ ডেলিভারি হয়েছে`,
      `Seller ${order.sellerName} submitted your completed work. Please inspect and approve or request revision.`,
      `সেলার ${order.sellerName} কাজ জমা দিয়েছেন। কাজ দেখে অনুমোদন করুন অথবা রিভিশন চান।`,
      'order',
      '/orders'
    );
  };

  // 6. Revision
  const requestOrderRevision = (orderId: string, revisionNote: string) => {
    const order = orders.find((o) => o.id === orderId);
    if (!order) return;

    setOrders((prev) =>
      prev.map((ord) => {
        if (ord.id === orderId) {
          return {
            ...ord,
            status: 'revision_requested',
            revisionRequests: [...ord.revisionRequests, { note: revisionNote, requestedAt: new Date().toISOString() }],
            statusHistory: [
              ...ord.statusHistory,
              {
                status: 'revision_requested',
                timestamp: new Date().toISOString(),
                actor: 'buyer',
                note: `Revision requested: ${revisionNote}`,
              },
            ],
            updatedAt: new Date().toISOString(),
          };
        }
        return ord;
      })
    );

    notifyUser(
      order.sellerId,
      `Revision Requested: Order ${order.orderNumber}`,
      `রিভিশন প্রয়োজন: অর্ডার ${order.orderNumber}`,
      `Buyer requested a revision on order ${order.orderNumber}: "${revisionNote}"`,
      `বায়ার কাজ সংশোধনের অনুরোধ করেছেন: "${revisionNote}"`,
      'order',
      '/orders'
    );
  };

  // 7. Accept Order Delivery (Releases Escrow to Seller)
  const acceptOrderDelivery = (orderId: string) => {
    const order = orders.find((o) => o.id === orderId);
    if (!order) return;

    setOrders((prev) =>
      prev.map((ord) => {
        if (ord.id === orderId) {
          return {
            ...ord,
            status: 'completed',
            statusHistory: [
              ...ord.statusHistory,
              {
                status: 'completed',
                timestamp: new Date().toISOString(),
                actor: 'buyer',
                note: 'Buyer approved delivered work. Order marked completed.',
              },
            ],
            updatedAt: new Date().toISOString(),
          };
        }
        return ord;
      })
    );

    // Release Escrow in ledger
    const releaseEntry: LedgerEntry = {
      id: `led-${Date.now()}`,
      orderId: order.id,
      type: 'seller_release',
      amountBDT: order.totalAmountBDT,
      platformFeeBDT: order.platformFeeBDT,
      sellerAmountBDT: order.sellerNetBDT,
      status: 'released',
      notes: `Escrow released. ৳${order.sellerNetBDT} credited to seller account. Platform revenue: ৳${order.platformFeeBDT}`,
      createdAt: new Date().toISOString(),
    };
    setLedger((prev) => [releaseEntry, ...prev]);

    // Update seller completed orders count & sales
    setGigs((prev) =>
      prev.map((g) => (g.id === order.gigId ? { ...g, salesCount: g.salesCount + 1 } : g))
    );

    notifyUser(
      order.sellerId,
      `Order ${order.orderNumber} Completed! ৳${order.sellerNetBDT} Released`,
      `অর্ডার ${order.orderNumber} সম্পন্ন! ৳${order.sellerNetBDT} একাউন্টে যোগ হয়েছে`,
      `Buyer approved your work! Funds of ৳${order.sellerNetBDT} have been released to your balance.`,
      `বায়ার কাজ গ্রহণ করেছেন! ৳${order.sellerNetBDT} আপনার ব্যালেন্সে যোগ হয়েছে।`,
      'order',
      '/orders'
    );
  };

  // 8. Reviews
  const submitReview = (orderId: string, rating: number, comment: string): { success: boolean; message: string } => {
    const order = orders.find((o) => o.id === orderId);
    if (!order) return { success: false, message: 'Order not found' };
    if (order.status !== 'completed') return { success: false, message: 'Only completed orders can be reviewed.' };
    if (order.isReviewed) return { success: false, message: 'You have already reviewed this order.' };

    const newReview: Review = {
      id: `rev-${Date.now()}`,
      orderId,
      gigId: order.gigId,
      sellerId: order.sellerId,
      buyerId: order.buyerId,
      buyerName: order.buyerName,
      buyerAvatar: order.buyerAvatar,
      rating: Math.max(1, Math.min(5, rating)),
      comment,
      createdAt: new Date().toISOString(),
    };

    setReviews((prev) => [newReview, ...prev]);

    setOrders((prev) =>
      prev.map((ord) => (ord.id === orderId ? { ...ord, isReviewed: true } : ord))
    );

    // Recalculate gig rating
    const gigReviews = [...reviews.filter((r) => r.gigId === order.gigId), newReview];
    const avgRating = Number(
      (gigReviews.reduce((sum, r) => sum + r.rating, 0) / gigReviews.length).toFixed(1)
    );

    setGigs((prev) =>
      prev.map((g) =>
        g.id === order.gigId
          ? { ...g, rating: avgRating, reviewsCount: gigReviews.length }
          : g
      )
    );

    notifyUser(
      order.sellerId,
      `New Verified ${rating}-Star Review Received!`,
      `নতুন ভেরিফাইড ${rating}-স্টার রিভিউ পেয়েছেন!`,
      `Buyer ${order.buyerName} rated your service: "${comment.slice(0, 80)}..."`,
      `বায়ার ${order.buyerName} রিভিউ দিয়েছেন: "${comment.slice(0, 80)}..."`,
      'system'
    );

    return { success: true, message: 'Thank you! Your verified review has been published.' };
  };

  // 9. Disputes
  const openDispute = (
    orderId: string,
    reasonCategory: string,
    description: string,
    requestedResolution: 'refund' | 'cancel' | 'release_payment' | 'revision'
  ) => {
    const order = orders.find((o) => o.id === orderId);
    if (!order) return;

    const newDispute: Dispute = {
      id: `disp-${Date.now()}`,
      orderId,
      orderNumber: order.orderNumber,
      openedById: currentUser?.id || 'user',
      openedByName: currentUser?.name || 'User',
      openedByRole: (currentUser?.role as 'buyer' | 'seller') || 'buyer',
      againstId: currentUser?.id === order.buyerId ? order.sellerId : order.buyerId,
      againstName: currentUser?.id === order.buyerId ? order.sellerName : order.buyerName,
      reasonCategory,
      description,
      evidenceFiles: [],
      requestedResolution,
      status: 'open',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    setDisputes((prev) => [newDispute, ...prev]);

    setOrders((prev) =>
      prev.map((ord) =>
        ord.id === orderId
          ? {
              ...ord,
              status: 'disputed',
              disputeId: newDispute.id,
              statusHistory: [
                ...ord.statusHistory,
                {
                  status: 'disputed',
                  timestamp: new Date().toISOString(),
                  actor: (currentUser?.role as any) || 'buyer',
                  note: `Dispute opened: ${reasonCategory}`,
                },
              ],
            }
          : ord
      )
    );

    notifyUser(
      'user-admin-1',
      `New Dispute Opened: Order ${order.orderNumber}`,
      `নতুন বিরোধ (Dispute) জমা হয়েছে: অর্ডার ${order.orderNumber}`,
      `A dispute was filed by ${currentUser?.name} for "${reasonCategory}". Administrative intervention required.`,
      `${currentUser?.name} অর্ডার সংক্রান্ত অভিযোগ দায়ের করেছেন: "${reasonCategory}"। অ্যাডমিন রিভিউ আবশ্যক।`,
      'dispute',
      '/admin/disputes'
    );
  };

  const resolveDispute = (
    disputeId: string,
    action: 'release_payment' | 'refund' | 'cancel' | 'revision',
    notes: string
  ) => {
    const disp = disputes.find((d) => d.id === disputeId);
    if (!disp) return;

    const targetOrder = orders.find((o) => o.id === disp.orderId);

    setDisputes((prev) =>
      prev.map((d) =>
        d.id === disputeId
          ? {
              ...d,
              status: 'resolved',
              adminDecision: {
                action,
                notes,
                decidedBy: currentUser?.username || 'addminmasud',
                decidedAt: new Date().toISOString(),
              },
              updatedAt: new Date().toISOString(),
            }
          : d
      )
    );

    if (targetOrder) {
      let nextStatus: OrderStatus = 'completed';
      if (action === 'refund' || action === 'cancel') {
        nextStatus = action === 'refund' ? 'refunded' : 'cancelled';
      } else if (action === 'revision') {
        nextStatus = 'revision_requested';
      }

      setOrders((prev) =>
        prev.map((ord) =>
          ord.id === disp.orderId
            ? {
                ...ord,
                status: nextStatus,
                statusHistory: [
                  ...ord.statusHistory,
                  {
                    status: nextStatus,
                    timestamp: new Date().toISOString(),
                    actor: 'admin',
                    note: `Dispute resolved by Admin. Action: ${action}. Notes: ${notes}`,
                  },
                ],
              }
            : ord
        )
      );

      addAudit('RESOLVE_DISPUTE', 'dispute', disputeId, `Resolved dispute with action ${action}: ${notes}`);
    }
  };

  // 10. Messages
  const sendMessage = (
    recipientId: string,
    text: string,
    orderId?: string,
    attachment?: { name: string; url: string }
  ) => {
    if (!currentUser || !text.trim()) return;

    const conversationId = `conv-${[currentUser.id, recipientId].sort().join('-')}`;
    const newMsg: Message = {
      id: `msg-${Date.now()}`,
      conversationId,
      senderId: currentUser.id,
      senderName: currentUser.name,
      senderAvatar: currentUser.avatar,
      senderRole: currentUser.role,
      text: text.trim(),
      attachments: attachment ? [attachment] : undefined,
      orderId,
      isRead: false,
      createdAt: new Date().toISOString(),
    };

    setMessages((prev) => [...prev, newMsg]);

    notifyUser(
      recipientId,
      `New Message from ${currentUser.name}`,
      `${currentUser.name} থেকে নতুন মেসেজ এসেছে`,
      text.slice(0, 100),
      text.slice(0, 100),
      'message',
      '/messages'
    );
  };

  const markMessagesRead = (partnerId: string) => {
    if (!currentUser) return;
    setMessages((prev) =>
      prev.map((m) =>
        m.senderId === partnerId && m.senderId !== currentUser.id ? { ...m, isRead: true } : m
      )
    );
  };

  // 11. Settings & Notifications
  const updateSettings = (newSettings: Partial<PlatformSettings>) => {
    setSettings((prev) => ({ ...prev, ...newSettings }));
    addAudit('UPDATE_SETTINGS', 'settings', 'global', 'Updated website platform settings');
  };

  const markNotificationRead = (id: string) => {
    setNotifications((prev) => prev.map((n) => (n.id === id ? { ...n, isRead: true } : n)));
  };

  const markAllNotificationsRead = () => {
    if (!currentUser) return;
    setNotifications((prev) =>
      prev.map((n) => (n.userId === currentUser.id ? { ...n, isRead: true } : n))
    );
  };

  return (
    <MarketplaceContext.Provider
      value={{
        categories,
        gigs,
        orders,
        settings,
        notifications,
        messages,
        disputes,
        reviews,
        ledger,
        auditLogs,
        createGig,
        updateGig,
        deleteGig,
        toggleGigStatus,
        createOrder,
        submitOrderPayment,
        verifyOrderPayment,
        rejectOrderPayment,
        deliverOrderWork,
        requestOrderRevision,
        acceptOrderDelivery,
        submitReview,
        openDispute,
        resolveDispute,
        sendMessage,
        markMessagesRead,
        updateSettings,
        markNotificationRead,
        markAllNotificationsRead,
      }}
    >
      {children}
    </MarketplaceContext.Provider>
  );
};

export const useMarketplace = () => {
  const context = useContext(MarketplaceContext);
  if (!context) {
    throw new Error('useMarketplace must be used within a MarketplaceProvider');
  }
  return context;
};
