import React, { createContext, useContext, useEffect, useState } from 'react';
import { User, UserRole } from '../types';

interface AuthContextType {
  currentUser: User | null;
  users: User[];
  login: (identifier: string, password: string) => { success: boolean; message: string };
  register: (name: string, username: string, email: string, password: string, role: UserRole) => { success: boolean; message: string };
  logout: () => void;
  updateProfile: (updatedData: Partial<User>) => void;
  changePassword: (oldPass: string, newPass: string) => { success: boolean; message: string };
  switchUserRole: (newRole: UserRole) => void;
  quickLoginAs: (role: 'admin' | 'seller' | 'buyer') => void;
  hasRole: (role: UserRole) => boolean;
  isAdmin: boolean;
  isSeller: boolean;
  isBuyer: boolean;
  mustChangeAdminPasswordNotice: boolean;
  dismissAdminPasswordNotice: () => void;
}

const INITIAL_USERS: User[] = [
  {
    id: 'user-admin-1',
    name: 'Masud Rana (Admin)',
    username: 'addminmasud',
    email: 'mdmasudranakeshorhatbajar29@gmail.com',
    role: 'admin',
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
    bio: 'Founder & Platform Administrator of Masud SEO Marketplace. Certified SEO & Digital Marketing Architect.',
    isVerified: true,
    phone: '01784038383',
    preferredLanguage: 'bn',
    preferredCurrency: 'BDT',
    createdAt: '2026-01-01T00:00:00.000Z',
    completedOrdersCount: 0,
    balance: 14500, // platform balance
  },
  {
    id: 'user-seller-1',
    name: 'Tanvir Hossain',
    username: 'tanvir_seo',
    email: 'tanvir.seo@gmail.com',
    role: 'seller',
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80',
    bio: 'Google Certified SEO Specialist with 7+ years ranking websites. Expert in High DA Guest Posts & WordPress Speed.',
    skills: ['Backlinks', 'Guest Posting', 'Technical SEO', 'Keyword Research', 'Core Web Vitals'],
    isVerified: true,
    phone: '01711223344',
    preferredLanguage: 'bn',
    preferredCurrency: 'BDT',
    createdAt: '2026-02-15T00:00:00.000Z',
    rating: 4.9,
    completedOrdersCount: 142,
    balance: 8500, // available
    pendingBalance: 3200, // in escrow
  },
  {
    id: 'user-buyer-1',
    name: 'Shafiul Islam',
    username: 'shafiul_biz',
    email: 'shafiul.ecommerce@gmail.com',
    role: 'buyer',
    avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&auto=format&fit=crop&q=80',
    bio: 'E-commerce business owner building organic traffic for fashion and tech stores in Bangladesh.',
    isVerified: true,
    phone: '01899887766',
    preferredLanguage: 'bn',
    preferredCurrency: 'BDT',
    createdAt: '2026-03-10T00:00:00.000Z',
    completedOrdersCount: 18,
    balance: 0,
  },
];

// Hash simulation helper (mirrors PHP password_hash concept)
function pseudoHash(str: string): string {
  let hash = 0;
  for (let i = 0; i < str.length; i++) {
    hash = (hash << 5) - hash + str.charCodeAt(i);
    hash |= 0;
  }
  return `sha256_${Math.abs(hash).toString(16)}`;
}

const PASSWORD_STORE_KEY = 'masud_seo_passwords';
const USERS_STORE_KEY = 'masud_seo_users';
const CURRENT_USER_KEY = 'masud_seo_current_user';

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [users, setUsers] = useState<User[]>(() => {
    const saved = localStorage.getItem(USERS_STORE_KEY);
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch {
        return INITIAL_USERS;
      }
    }
    return INITIAL_USERS;
  });

  const [currentUser, setCurrentUser] = useState<User | null>(() => {
    const saved = localStorage.getItem(CURRENT_USER_KEY);
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch {
        return null;
      }
    }
    // Default to buyer for realistic experience, or user-buyer-1
    return INITIAL_USERS[2]; // Buyer logged in by default for instant testing
  });

  const [mustChangeAdminPasswordNotice, setMustChangeAdminPasswordNotice] = useState<boolean>(() => {
    return localStorage.getItem('masud_admin_pwd_changed') !== 'true';
  });

  // Initialize password hashes in local storage securely if not present
  useEffect(() => {
    let passwords = JSON.parse(localStorage.getItem(PASSWORD_STORE_KEY) || '{}');
    if (!passwords['addminmasud']) {
      passwords['addminmasud'] = pseudoHash('masud#1234567');
      passwords['tanvir_seo'] = pseudoHash('seller123');
      passwords['shafiul_biz'] = pseudoHash('buyer123');
      localStorage.setItem(PASSWORD_STORE_KEY, JSON.stringify(passwords));
    }
  }, []);

  useEffect(() => {
    localStorage.setItem(USERS_STORE_KEY, JSON.stringify(users));
  }, [users]);

  useEffect(() => {
    if (currentUser) {
      localStorage.setItem(CURRENT_USER_KEY, JSON.stringify(currentUser));
    } else {
      localStorage.removeItem(CURRENT_USER_KEY);
    }
  }, [currentUser]);

  const login = (identifier: string, pass: string): { success: boolean; message: string } => {
    const trimmedId = identifier.trim().toLowerCase();
    const passwords = JSON.parse(localStorage.getItem(PASSWORD_STORE_KEY) || '{}');

    const user = users.find(
      (u) => u.username.toLowerCase() === trimmedId || u.email.toLowerCase() === trimmedId
    );

    if (!user) {
      return { success: false, message: 'User not found with this username or email.' };
    }

    const storedHash = passwords[user.username];
    if (storedHash && storedHash !== pseudoHash(pass)) {
      return { success: false, message: 'Invalid password. Please check your credentials.' };
    }

    setCurrentUser(user);
    return { success: true, message: 'Login successful! Welcome back.' };
  };

  const register = (
    name: string,
    username: string,
    email: string,
    password: string,
    role: UserRole
  ): { success: boolean; message: string } => {
    const cleanUsername = username.trim().toLowerCase().replace(/[^a-z0-9_]/g, '');
    const cleanEmail = email.trim().toLowerCase();

    if (!cleanUsername || !cleanEmail || !name.trim() || !password) {
      return { success: false, message: 'All fields are required.' };
    }

    if (password.length < 6) {
      return { success: false, message: 'Password must be at least 6 characters long.' };
    }

    if (users.some((u) => u.username.toLowerCase() === cleanUsername)) {
      return { success: false, message: 'Username is already taken.' };
    }

    if (users.some((u) => u.email.toLowerCase() === cleanEmail)) {
      return { success: false, message: 'Email address is already registered.' };
    }

    // Role cannot be registered directly as admin
    const assignedRole: UserRole = role === 'admin' ? 'buyer' : role;

    const newUser: User = {
      id: `user-${Date.now()}`,
      name: name.trim(),
      username: cleanUsername,
      email: cleanEmail,
      role: assignedRole,
      avatar: `https://api.dicebear.com/7.x/bottts/svg?seed=${cleanUsername}`,
      isVerified: true,
      preferredLanguage: 'bn',
      preferredCurrency: 'BDT',
      createdAt: new Date().toISOString(),
      balance: 0,
      completedOrdersCount: 0,
    };

    // Store password hash
    const passwords = JSON.parse(localStorage.getItem(PASSWORD_STORE_KEY) || '{}');
    passwords[cleanUsername] = pseudoHash(password);
    localStorage.setItem(PASSWORD_STORE_KEY, JSON.stringify(passwords));

    const updated = [...users, newUser];
    setUsers(updated);
    setCurrentUser(newUser);

    return { success: true, message: 'Account created successfully!' };
  };

  const logout = () => {
    setCurrentUser(null);
  };

  const updateProfile = (updatedData: Partial<User>) => {
    if (!currentUser) return;
    const updatedUser = { ...currentUser, ...updatedData };
    setCurrentUser(updatedUser);
    setUsers((prev) => prev.map((u) => (u.id === updatedUser.id ? updatedUser : u)));
  };

  const changePassword = (oldPass: string, newPass: string): { success: boolean; message: string } => {
    if (!currentUser) return { success: false, message: 'Not logged in' };
    const passwords = JSON.parse(localStorage.getItem(PASSWORD_STORE_KEY) || '{}');

    if (passwords[currentUser.username] !== pseudoHash(oldPass)) {
      return { success: false, message: 'Current password is incorrect.' };
    }

    if (newPass.length < 6) {
      return { success: false, message: 'New password must be at least 6 characters.' };
    }

    passwords[currentUser.username] = pseudoHash(newPass);
    localStorage.setItem(PASSWORD_STORE_KEY, JSON.stringify(passwords));

    if (currentUser.role === 'admin') {
      localStorage.setItem('masud_admin_pwd_changed', 'true');
      setMustChangeAdminPasswordNotice(false);
    }

    return { success: true, message: 'Password updated successfully!' };
  };

  const switchUserRole = (newRole: UserRole) => {
    if (!currentUser) return;
    const updated = { ...currentUser, role: newRole };
    setCurrentUser(updated);
    setUsers((prev) => prev.map((u) => (u.id === updated.id ? updated : u)));
  };

  const quickLoginAs = (role: 'admin' | 'seller' | 'buyer') => {
    const target = users.find((u) => u.role === role);
    if (target) {
      setCurrentUser(target);
    }
  };

  const hasRole = (role: UserRole) => currentUser?.role === role;
  const isAdmin = currentUser?.role === 'admin';
  const isSeller = currentUser?.role === 'seller';
  const isBuyer = currentUser?.role === 'buyer';

  const dismissAdminPasswordNotice = () => {
    setMustChangeAdminPasswordNotice(false);
  };

  return (
    <AuthContext.Provider
      value={{
        currentUser,
        users,
        login,
        register,
        logout,
        updateProfile,
        changePassword,
        switchUserRole,
        quickLoginAs,
        hasRole,
        isAdmin,
        isSeller,
        isBuyer,
        mustChangeAdminPasswordNotice,
        dismissAdminPasswordNotice,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
