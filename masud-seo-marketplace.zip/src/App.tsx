import React, { useEffect, useState } from 'react';
import { AuthModal } from './components/auth/AuthModal';
import { AdminPanelView } from './components/admin/AdminPanelView';
import { UserDashboardView } from './components/dashboards/UserDashboardView';
import { InfinityFreeModal } from './components/deployment/InfinityFreeModal';
import { BrowseServicesView } from './components/gigs/BrowseServicesView';
import { CreateEditGigModal } from './components/gigs/CreateEditGigModal';
import { GigDetailsView } from './components/gigs/GigDetailsView';
import { HomeView } from './components/home/HomeView';
import { Footer } from './components/layout/Footer';
import { Navbar } from './components/layout/Navbar';
import { MessagesView } from './components/messages/MessagesView';
import { OrderDetailsView } from './components/orders/OrderDetailsView';
import { OrderCheckoutModal, PaymentModal } from './components/orders/OrderModals';
import { StaticPagesModal } from './components/static/StaticPagesModal';
import { AuthProvider, useAuth } from './context/AuthContext';
import { MarketplaceProvider, useMarketplace } from './context/MarketplaceContext';
import { LanguageProvider, useLanguage } from './i18n/LanguageContext';
import { Gig, GigExtra, Order } from './types';

function MainApp() {
  const { language, t } = useLanguage();
  const { currentUser, isAdmin } = useAuth();
  const { gigs, orders } = useMarketplace();

  // Navigation state
  const [currentView, setCurrentView] = useState<string>('home');
  const [viewParams, setViewParams] = useState<any>({});

  // Active items
  const [selectedGig, setSelectedGig] = useState<Gig | null>(null);
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);

  // Modals state
  const [authModalOpen, setAuthModalOpen] = useState(false);
  const [authMode, setAuthMode] = useState<'login' | 'register' | 'admin'>('login');

  const [createGigModalOpen, setCreateGigModalOpen] = useState(false);
  const [gigToEdit, setGigToEdit] = useState<Gig | null>(null);

  const [checkoutModalOpen, setCheckoutModalOpen] = useState(false);
  const [checkoutGig, setCheckoutGig] = useState<Gig | null>(null);
  const [checkoutExtras, setCheckoutExtras] = useState<GigExtra[]>([]);

  const [paymentModalOpen, setPaymentModalOpen] = useState(false);
  const [paymentOrder, setPaymentOrder] = useState<Order | null>(null);

  const [deployModalOpen, setDeployModalOpen] = useState(false);
  const [staticPage, setStaticPage] = useState<'help' | 'contact' | 'privacy' | 'terms' | 'refund' | null>(null);

  // Offline detection
  const [isOnline, setIsOnline] = useState(navigator.onLine);

  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    // Register PWA service worker if available
    if ('serviceWorker' in navigator && process.env.NODE_ENV === 'production') {
      navigator.serviceWorker.register('/sw.js').catch(() => {});
    }

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  // Navigation dispatcher
  const handleNavigate = (view: string, param?: any) => {
    setCurrentView(view);
    setViewParams(param || {});
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleOpenAuth = (mode: 'login' | 'register' | 'admin') => {
    setAuthMode(mode);
    setAuthModalOpen(true);
  };

  const handleSelectGig = (gig: Gig) => {
    setSelectedGig(gig);
    setCurrentView('gig-details');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleStartOrder = (gig: Gig, extras: GigExtra[]) => {
    setCheckoutGig(gig);
    setCheckoutExtras(extras);
    setCheckoutModalOpen(true);
  };

  const handleProceedToPayment = (order: Order) => {
    setPaymentOrder(order);
    setPaymentModalOpen(true);
  };

  const handleViewOrder = (order: Order) => {
    setSelectedOrder(order);
    setCurrentView('order-details');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleOpenChat = (partnerId: string, orderId?: string) => {
    handleNavigate('messages', { partnerId, orderId });
  };

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 transition-colors">
      {/* Offline Status Alert if connection dropped */}
      {!isOnline && (
        <div className="bg-amber-600 text-white text-xs font-semibold py-2 px-4 text-center">
          ⚠️ {t('offlineNotice')}
        </div>
      )}

      {/* Main Navbar */}
      <Navbar
        onNavigate={handleNavigate}
        currentView={currentView}
        onOpenAuth={handleOpenAuth}
        onOpenCreateGig={() => {
          setGigToEdit(null);
          setCreateGigModalOpen(true);
        }}
        onOpenDeploy={() => setDeployModalOpen(true)}
      />

      {/* Main View Body */}
      <main className="flex-1">
        {/* 1. HOME VIEW */}
        {currentView === 'home' && (
          <HomeView
            onNavigateToBrowse={(catId) => handleNavigate('browse', { categoryId: catId })}
            onSelectGig={handleSelectGig}
            onOpenCreateGig={() => {
              setGigToEdit(null);
              setCreateGigModalOpen(true);
            }}
            onOpenDeploy={() => setDeployModalOpen(true)}
          />
        )}

        {/* 2. BROWSE SERVICES VIEW */}
        {currentView === 'browse' && (
          <BrowseServicesView
            initialCategoryId={viewParams?.categoryId}
            initialQuery={viewParams?.query}
            onSelectGig={handleSelectGig}
          />
        )}

        {/* 3. GIG DETAILS VIEW */}
        {currentView === 'gig-details' && selectedGig && (
          <GigDetailsView
            gig={selectedGig}
            onBack={() => handleNavigate('browse')}
            onOrderNow={handleStartOrder}
            onContactSeller={(sellerId) => handleOpenChat(sellerId)}
          />
        )}

        {/* 4. USER DASHBOARD (BUYER & SELLER) */}
        {currentView === 'dashboard' && (
          <UserDashboardView
            onOpenCreateGig={() => {
              setGigToEdit(null);
              setCreateGigModalOpen(true);
            }}
            onEditGig={(gig) => {
              setGigToEdit(gig);
              setCreateGigModalOpen(true);
            }}
            onViewOrder={handleViewOrder}
            onBrowseServices={() => handleNavigate('browse')}
          />
        )}

        {/* 5. ORDERS LIST VIEW */}
        {currentView === 'orders' && (
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 animate-in fade-in">
            <UserDashboardView
              onOpenCreateGig={() => {
                setGigToEdit(null);
                setCreateGigModalOpen(true);
              }}
              onEditGig={(gig) => {
                setGigToEdit(gig);
                setCreateGigModalOpen(true);
              }}
              onViewOrder={handleViewOrder}
              onBrowseServices={() => handleNavigate('browse')}
            />
          </div>
        )}

        {/* 6. ORDER DETAILS & LIFECYCLE TRACKER */}
        {currentView === 'order-details' && selectedOrder && (
          <OrderDetailsView
            order={selectedOrder}
            onBack={() => handleNavigate('dashboard')}
            onOpenPaymentModal={(ord) => {
              setPaymentOrder(ord);
              setPaymentModalOpen(true);
            }}
            onOpenChat={handleOpenChat}
          />
        )}

        {/* 7. PRIVATE MESSAGES */}
        {currentView === 'messages' && (
          <MessagesView
            initialPartnerId={viewParams?.partnerId}
            initialOrderId={viewParams?.orderId}
            onBack={() => handleNavigate('dashboard')}
            onViewOrder={(ordId) => {
              const target = orders.find((o) => o.id === ordId || o.orderNumber === ordId);
              if (target) handleViewOrder(target);
            }}
          />
        )}

        {/* 8. ADMIN CONSOLE */}
        {currentView === 'admin' && (
          <AdminPanelView
            onOpenDeployModal={() => setDeployModalOpen(true)}
            onViewOrder={handleViewOrder}
          />
        )}
      </main>

      {/* Global Modals */}
      <AuthModal
        initialMode={authMode}
        isOpen={authModalOpen}
        onClose={() => setAuthModalOpen(false)}
        onSuccess={() => {}}
      />

      {checkoutGig && (
        <OrderCheckoutModal
          gig={checkoutGig}
          selectedExtras={checkoutExtras}
          isOpen={checkoutModalOpen}
          onClose={() => setCheckoutModalOpen(false)}
          onProceedToPayment={handleProceedToPayment}
        />
      )}

      {paymentOrder && (
        <PaymentModal
          order={paymentOrder}
          isOpen={paymentModalOpen}
          onClose={() => setPaymentModalOpen(false)}
          onSuccess={() => {
            handleViewOrder(paymentOrder);
          }}
        />
      )}

      <CreateEditGigModal
        gigToEdit={gigToEdit}
        isOpen={createGigModalOpen}
        onClose={() => setCreateGigModalOpen(false)}
        onSuccess={(saved) => {
          setSelectedGig(saved);
          handleNavigate('gig-details');
        }}
      />

      <InfinityFreeModal
        isOpen={deployModalOpen}
        onClose={() => setDeployModalOpen(false)}
      />

      <StaticPagesModal
        page={staticPage}
        onClose={() => setStaticPage(null)}
      />

      {/* Main Footer */}
      <Footer
        onNavigate={handleNavigate}
        onOpenStaticModal={(page) => setStaticPage(page)}
        onOpenDeploy={() => setDeployModalOpen(true)}
      />
    </div>
  );
}

export default function App() {
  return (
    <LanguageProvider>
      <AuthProvider>
        <MarketplaceProvider>
          <MainApp />
        </MarketplaceProvider>
      </AuthProvider>
    </LanguageProvider>
  );
}
