import React, { createContext, useContext, useEffect, useState } from 'react';
import { CurrencyCode, LanguageCode } from '../types';
import { CURRENCY_SYMBOLS, EXCHANGE_RATES, translations } from './translations';

interface LanguageContextType {
  language: LanguageCode;
  setLanguage: (lang: LanguageCode) => void;
  currency: CurrencyCode;
  setCurrency: (curr: CurrencyCode) => void;
  t: (key: keyof typeof translations.en, params?: Record<string, string | number>) => string;
  formatPrice: (amountBDT: number) => string;
  theme: 'light' | 'dark';
  toggleTheme: () => void;
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export const LanguageProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [language, setLanguageState] = useState<LanguageCode>(() => {
    const saved = localStorage.getItem('masud_seo_lang');
    return (saved === 'en' || saved === 'bn') ? saved : 'bn';
  });

  const [currency, setCurrencyState] = useState<CurrencyCode>(() => {
    const saved = localStorage.getItem('masud_seo_currency');
    return (saved === 'BDT' || saved === 'USD' || saved === 'EUR' || saved === 'GBP') ? saved : 'BDT';
  });

  const [theme, setThemeState] = useState<'light' | 'dark'>(() => {
    const saved = localStorage.getItem('masud_seo_theme');
    if (saved === 'dark' || saved === 'light') return saved;
    return window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
  });

  useEffect(() => {
    localStorage.setItem('masud_seo_lang', language);
    document.documentElement.lang = language;
  }, [language]);

  useEffect(() => {
    localStorage.setItem('masud_seo_currency', currency);
  }, [currency]);

  useEffect(() => {
    localStorage.setItem('masud_seo_theme', theme);
    if (theme === 'dark') {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [theme]);

  const toggleTheme = () => {
    setThemeState((prev) => (prev === 'light' ? 'dark' : 'light'));
  };

  const setLanguage = (lang: LanguageCode) => {
    setLanguageState(lang);
  };

  const setCurrency = (curr: CurrencyCode) => {
    setCurrencyState(curr);
  };

  const t = (key: keyof typeof translations.en, params?: Record<string, string | number>): string => {
    const langDict = translations[language] || translations.en;
    let text = (langDict as Record<string, string>)[key] || (translations.en as Record<string, string>)[key] || key;

    if (params) {
      Object.entries(params).forEach(([pKey, pVal]) => {
        text = text.replace(new RegExp(`\\{${pKey}\\}`, 'g'), String(pVal));
      });
    }

    return text;
  };

  const formatPrice = (amountBDT: number): string => {
    const rate = EXCHANGE_RATES[currency] || 1;
    const converted = amountBDT * rate;
    const symbol = CURRENCY_SYMBOLS[currency] || '৳';

    if (currency === 'BDT') {
      return `${symbol}${Math.round(converted).toLocaleString('en-IN')}`;
    }

    return `${symbol}${converted.toFixed(2)}`;
  };

  return (
    <LanguageContext.Provider
      value={{
        language,
        setLanguage,
        currency,
        setCurrency,
        t,
        formatPrice,
        theme,
        toggleTheme,
      }}
    >
      {children}
    </LanguageContext.Provider>
  );
};

export const useLanguage = () => {
  const context = useContext(LanguageContext);
  if (!context) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
};
